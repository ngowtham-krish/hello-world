from strait.modeldb.helper.preprocessing import Preprocessing 
from strait.modeldb.helper.metrics import Metrics
from strait.modeldb.helper.schema import Schema
from strait.modeldb.helper.model import Model
from strait.modeldb.helper.results import Results

class Logger(object):

    def __init__(self,model_key=None, active=None, new=True):
        self.dbSchema = None
        self.model_key = model_key
        self.new = new
        self.active = active

    def preprocessing(self, **kwargs):
        return Preprocessing(self.model_key, self.active)

    def metrics(self, **kwargs):
        return Metrics(self.model_key, self.active)

    def model(self, **kwargs):
        return Model(self.model_key, self.active)

    def dataset(self, **kwargs):
        return Schema(self.model_key, self.active)
    
    def results(self, **kwargs):
        return Results(self.model_key, self.active)