from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class ModelsSchema(Document):
    model_key       = StringField(max_length=200, required=True)
    run_name        = StringField()
    model_name      = StringField()
    catalog_key     = StringField()
    algorithm       = StringField()
    schema          = ListField()
    preprocessing   = DictField()
    model           = DictField()
    meta_info       = DictField()
    results         = ListField()
    metrics         = DictField()
    is_published    = BooleanField(default=False)
    is_active       = BooleanField(default=True)
    drift           = StringField()
    active_endpoints= ListField()
    host            = StringField(default="localhost")
    endpoint        = StringField(default="/api/v2/scoring/<model_key>")
    tar_path        = StringField()
    created_at      = DateTimeField(default=datetime.now())
    updated_at      = DateTimeField(default=datetime.now())
    created_by      = StringField()
    updated_by      = StringField()
    owners          = ListField()
    deleted         = BooleanField(default= False)
    base_path       = StringField()
    meta            = {'collection': 'models'}




