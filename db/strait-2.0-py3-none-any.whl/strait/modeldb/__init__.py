
from random import choices
from string import ascii_lowercase, digits
from strait.modeldb.logger import Logger
from strait.modeldb.active_run import ActiveRun
from strait.modeldb.helper.dbSchema import ModelDBSchema
from json import loads

class ModelDB:
    def __init__(self, model_key=None):
        self.model_key = model_key
        self.new = True
        if self.model_key is None:
            self.model_key = ''.join(choices(ascii_lowercase +
                                digits, k = 15)) 
        else:
            self.new = False
        self.active = ActiveRun(self.model_key)
        self.logger = Logger(self.model_key, self.active, self.new)
        self.schema = ModelDBSchema(self.model_key)

    def preprocessing(self, **kwargs):
        kwargs['active'] = self.active
        # print(kwargs['active'].model)
        return self.logger.preprocessing()

    def metrics(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.metrics()

    def sklearn(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.model()

    def meta_info(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.dataset()
    
    def results(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.results()

    def save(self):
        preprocessing = self.active.preprocessing
        dataset = self.active.dataset
        models = self.active.model
        meta_info = self.active.meta_info
        metrics = self.active.metrics
        results = self.active.results
        records = []
        for model in models:
            metric = None
            if model["algorithm"] in metrics.keys():
                metric = metrics[model["algorithm"]]
                result = results[model["algorithm"]] if model["algorithm"] in results else []
            record = self.schema.create(preprocessing=preprocessing, results= result, meta_info=meta_info, metrics= metric, schema=dataset, model=model)
            records.append(record)
        return records

    def publish(self, catalog_key, model_name):
        return self.schema.publish(catalog_key, model_name)
    
    def update_endpoint(self, catalog_key, host, endpoint):
        return self.schema.update_endpoint(catalog_key=catalog_key, host=host, endpoint=endpoint)

    def get_model(self, catalog_key):
        return self.schema.get(catalog_key=catalog_key)

    def get_swagger(self, catalog_key):
        data = self.schema.get(catalog_key=catalog_key)
        data_dict = loads(data)
        path = data_dict[0]["base_path"] + "/swagger.json"
        swagger_json = None
        with open(path, "r") as file_open:
            swagger_json = loads(file_open.read())
        return {"status": "success", "data": swagger_json }
    
    def unpublish(self, catalog_key):
        return self.schema.unpublish(catalog_key)

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "Success" if exc_type is None else "Failed"
        # data = self.save()
        self.active = None
        self.logger = None
        self.schema = None
        self.model_key = None
        return exc_type is None


# class Training:
#     def __init__(self):
#         self.model = None
    
#     def train(self):
#         count = 0
#         with Model() as b:
#             self.model = b
#             while count < 10:
#                 b.log_model(e=count)
#                 count = count + 1


# a = Training()
# a.train()
# print(a.model.c)

# a = Training()
# a.train()
# print(a.model.c)

# a = Training()
# a.train()
# print(a.model.c)