from strait.modeldb import ModelDB


with ModelDB(model_key="") as mdb:

    ''' 
    # Preprocessing

        ### Feature Handling
            * Impute
            * Rescaling
            * Encoding

            ## Impute
                type: Impute with mean, median, mode, constant value
                value: number / string
                column: column name
                example:
                    mdb.preprocessing().impute(column="age",type="mean", value=30.2)
                    mdb.preprocessing().impute(column="sex",type="constant value", value="male")

            ## Rescaling
                type: Scale with minmaxscaling, standard scaling
                model: fitted model
                column: column name
                example:
                    a = model.fit(df['age'])
                    b = model.fit(df['sex'])
                    mdb.preprocessing().scaling(column="age",type="minmaxscaling", model=a)
                    mdb.preprocessing().scaling(column="sex",type="standard scaling", model=b)

            ## Encoding
                type: Encode with dummy encoding, 0/1 flag
                model: fitted model # if dummy encoding
                replace: object # if 0/1 flag
                column: column name
                encoded: boolean
                dropone: boolean
                data: column name #if dropone == true
                example:
                    a = model.fit(df['region'])
                    b = model.fit(df['sex'])
                    mdb.preprocessing().encoding(column="region",type="dummy encoding", model=a, dropone=True, encoder=True, data="column name")
                    mdb.preprocessing().encoding(column="sex",type="0/1 flag", data={"male": 0, "female": 1})

        ### Feature Reduction

            * PCA
            * Correlation with Target

            ## PCA
                model: fitted model
                example:
                    mdb.preprocessing().feature_reduction(type= "pca", model=a)
            ## Correlation with Target
                columns_to_keep: ['age','smoker']
                example:
                    mdb.preprocessing().feature_reduction(type= "correlation", columns_to_keep=["age", "smoker"])
    
    # Model

        * scikit-learn

        ## scikit-learn
        model: fitted model
        example:
            mdb.sklearn().model(model=a)
    
    # Dataset 
        dataset_key: # if input
        dataframe: # if predicted
        example:
            mdb.dataset().input(dataset_key)
            mdb.dataset().predicted(dataframe)
        
    # Metrics
        metrics: entire object {"r2_score": 0.2, ...etc}
        example:
            mdb.metrics(metrics={"r2_score": 0.2, ...etc})
    
    # Run
        run: entire object 
        run_definition: entire object
        example:
            mdb.experiment_details(run_definition={}, run={})
    '''

    pass



