
from random import choices
from string import ascii_lowercase, digits
from strait.modeldb.logger import Logger
from strait.modeldb.active_run import ActiveRun
from strait.modeldb.helper.dbSchema import ModelDBSchema
class ModelDB:
    def __init__(self, model_key=None):
        self.model_key = model_key
        self.new = True
        if self.model_key is None:
            self.model_key = ''.join(choices(ascii_lowercase +
                                digits, k = 15)) 
        else:
            self.new = False
        self.active = ActiveRun(self.model_key)
        self.logger = Logger(self.model_key, self.active, self.new)
        self.schema = ModelDBSchema(self.model_key)

    def preprocessing(self, **kwargs):
        kwargs['active'] = self.active
        # print(kwargs['active'].model)
        return self.logger.preprocessing()

    def metrics(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.metrics()

    def sklearn(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.model()

    def meta_info(self, **kwargs):
        kwargs['active'] = self.active
        return self.logger.dataset()

    def save(self):
        preprocessing = self.active.preprocessing
        dataset = self.active.dataset
        models = self.active.model
        meta_info = self.active.meta_info
        records = []
        for model in models:
            metric = None
            if model["algorithm"] in metrics.keys():
                metric = metrics[model["algorithm"]]
            record = self.schema.create(preprocessing=preprocessing, meta=meta_info, metrics= metric, schema=dataset, model=model)
            records.append(record)
        return records


    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        status = "Success" if exc_type is None else "Failed"
        data = self.save()
        self.active = None
        self.logger = None
        self.schema = None
        self.model_key = None
        return exc_type is None, data


# class Training:
#     def __init__(self):
#         self.model = None
    
#     def train(self):
#         count = 0
#         with Model() as b:
#             self.model = b
#             while count < 10:
#                 b.log_model(e=count)
#                 count = count + 1


# a = Training()
# a.train()
# print(a.model.c)

# a = Training()
# a.train()
# print(a.model.c)

# a = Training()
# a.train()
# print(a.model.c)