
class ActiveRun(object):

    # Temporary Memory Object
    def __init__(self, model_key):
        self.model_key = None
        self.preprocessing = {
            "feature_handling": {
                "impute": [],
                "scaling": [],
                "encoding": []
            },
            "feature_reduction": {}
        }
        self.metrics = {}
        self.dataset = []
        self.meta_info= {}
        self.model = []
        self.run = {}
        self.results = {}
