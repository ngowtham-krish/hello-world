swagger_scikit = {
    "swagger": "2.0",
    "info": {
      "description": "Scoring Node Predict API",
      "version": "1.0.0",
      "title": "Strait - Scoring Node",
      "license": {
        "name": "Apache 2.0",
        "url": "http://www.apache.org/licenses/LICENSE-2.0.html"
      }
    },
    "host": "localhost",
    "basePath": "/api/v2/scoring/<model_key>",
    "schemes": [
      "http"
    ],
    "paths": {
      "/online/predict": {
        "post": {
          "tags": [
            "Online Predict"
          ],
          "summary": "Predict Published Model in Online Mode",
          "description": "",
          "operationId": "onlinePredict",
          "consumes": [
            "multipart/form-data"
          ],
          "produces": [
            "application/json"
          ],
          "parameters": [
            {
              "name": "type",
              "in": "formData",
              "description": "Type of Input",
              "required": True,
              "type": "string",
              "enum": [
                "json"
              ]
            },
            {
              "name": "data",
              "in": "formData",
              "description": "Array of JSON String",
              "required": True,
              "type": "string"
            }
          ],
          "responses": {
            "200": {
              "description": "successful operation",
              "schema": {
                "$ref": "#/definitions/ApiResponse"
              }
            },
            "405": {
              "description": "Invalid input"
            }
          }
        }
      },
      "/batch/predict": {
        "post": {
          "tags": [
            "Predict"
          ],
          "summary": "Predict Published Model in Batch Mode",
          "description": "",
          "operationId": "batchPredict",
          "consumes": [
            "multipart/form-data"
          ],
          "produces": [
            "application/json"
          ],
          "parameters": [
            {
              "name": "type",
              "in": "formData",
              "description": "Type of Input",
              "required": True,
              "type": "string",
              "enum": [
                "excel",
                "csv"
              ]
            },
            {
              "name": "data",
              "in": "formData",
              "description": "file to upload",
              "required": True,
              "type": "file"
            }
          ],
          "responses": {
            "200": {
              "description": "successful operation",
              "schema": {
                "$ref": "#/definitions/ApiResponse"
              }
            },
            "405": {
              "description": "Invalid input"
            }
          }
        }
      }
    },
    "definitions": {
      "ApiResponse": {
        "type": "object",
        "properties": {
          "status": {
            "type": "string"
          },
          "data": {
            "type": "string"
          },
          "message": {
            "type": "string"
          }
        }
      }
    }
  }

swagger_timeseries = {
    "swagger": "2.0",
    "info": {
      "description": "Scoring Node Predict API",
      "version": "1.0.0",
      "title": "Strait - Scoring Node",
      "license": {
        "name": "Apache 2.0",
        "url": "http://www.apache.org/licenses/LICENSE-2.0.html"
      }
    },
    "host": "localhost",
    "basePath": "/api/v2/scoring/<model_key>",
    "schemes": [
      "http"
    ],
    "paths": {
      "/online/detect_anomaly": {
        "post": {
          "tags": [
            "Online Anomaly Detection"
          ],
          "summary": "Detect Anomaly for Time Series with Online Mode",
          "description": "",
          "operationId": "onlineAnomalyDetect",
          "consumes": [
            "multipart/form-data"
          ],
          "produces": [
            "application/json"
          ],
          "parameters": [
            {
              "name": "type",
              "in": "formData",
              "description": "Type of Input",
              "required": True,
              "type": "string",
              "enum": [
                "json"
              ]
            },
            {
              "name": "data",
              "in": "formData",
              "description": "Array of JSON String",
              "required": True,
              "type": "string"
            }
          ],
          "responses": {
            "200": {
              "description": "successful operation",
              "schema": {
                "$ref": "#/definitions/ApiResponse"
              }
            },
            "405": {
              "description": "Invalid input"
            }
          }
        }
      },
      "/batch/detect_anomaly": {
        "post": {
          "tags": [
            "Batch Mode Anomaly Detection"
          ],
          "summary": "Detect Anomaly for Time Series with Batch Mode",
          "description": "",
          "operationId": "batchAnomalyDetect",
          "consumes": [
            "multipart/form-data"
          ],
          "produces": [
            "application/json"
          ],
          "parameters": [
            {
              "name": "type",
              "in": "formData",
              "description": "Type of Input",
              "required": True,
              "type": "string",
              "enum": [
                "excel",
                "csv"
              ]
            },
            {
              "name": "data",
              "in": "formData",
              "description": "file to upload",
              "required": True,
              "type": "file"
            }
          ],
          "responses": {
            "200": {
              "description": "successful operation",
              "schema": {
                "$ref": "#/definitions/ApiResponse"
              }
            },
            "405": {
              "description": "Invalid input"
            }
          }
        }
      }
    },
    "definitions": {
      "ApiResponse": {
        "type": "object",
        "properties": {
          "status": {
            "type": "string"
          },
          "data": {
            "type": "string"
          },
          "message": {
            "type": "string"
          }
        }
      }
    }
  }


from copy import deepcopy

def get_template(model_key, experiment_type=None):
  if experiment_type == "Timeseries":
    tmpl = deepcopy(swagger_timeseries)
    tmpl["basePath"] = tmpl["basePath"].replace("<model_key>", model_key)
  else:
    tmpl = deepcopy(swagger_scikit)
    tmpl["basePath"] = tmpl["basePath"].replace("<model_key>", model_key)
  return tmpl

# get_template("ABC")