from strait.modeldb.model.schema import ModelsSchema
import tarfile
from os import environ, path, makedirs
from json import dump, dumps, loads
from datetime import datetime
from strait.modeldb.helper.utils import dump_preprocessing, dump_model
from strait.modeldb.helper.swagger_tmpl import get_template
from random import randint
drift_list = ["good", "bad", "average"]

class ModelDBSchema:

    def __init__(self, model_key=None):
        self.model_key = model_key
        self.modelSchema = ModelsSchema
        self.base_folder = environ.get("MODELDB_PATH", None)

    
    def create(self, **kwargs):
        drift = drift_list[randint(0, 2)]
        self.model_path = self.base_folder + kwargs["model"]["algorithm"] + "_" +self.model_key  
        if not path.exists(self.model_path):
            makedirs(self.model_path)
        flows = {
            "flow_key": kwargs["model"]["algorithm"] + "_" +self.model_key,
        }
        preprocessing = None
        if 'preprocessing' in kwargs:
            # preprocessing = kwargs["preprocessing"]
            preprocessing = dump_preprocessing(preprocessing=kwargs["preprocessing"], model_path=self.model_path)
            flows["preprocessing"] = preprocessing

        schema = None
        if 'schema' in kwargs:
            schema = kwargs["schema"]
            flows["schema"] = schema
        
        model = None
        algorithm = None
        if 'model' in kwargs:
            model = kwargs["model"]
            algorithm = kwargs["model"]["algorithm"]
            model = dump_model(model=kwargs["model"], model_path=self.model_path, meta_info = kwargs['meta_info'])
            flows["model"] = model
        
        metrics = None
        if 'metrics' in kwargs:
            metrics = kwargs["metrics"]
            flows["metrics"] = metrics
        
        results = None
        if 'results' in kwargs:
            results = kwargs["results"]
            flows["results"] = results
        
        run_name = None
        if 'run_name' in kwargs:
            run_name = kwargs["run_name"]
            flows["run_name"] = run_name
        model_key = algorithm + "_" + self.model_key 

        meta_info = None
        catalog_key = None
        if 'meta_info' in kwargs:
            meta_info = kwargs['meta_info']
            catalog_key = meta_info["catalog_key"]
            flows["meta_info"] = meta_info
        flow_name = "/flow.json"
        tar_name = "/"+algorithm + ".tar.gz"
        swagger_json = "/swagger.json"
        path_dir = self.model_path
        flow_path = path_dir + flow_name
        tar_path = path_dir + tar_name
        swagger_path = path_dir + swagger_json
        # flows = dumps(flows, default=str)
        swagger_tmpl_str = get_template(model_key, experiment_type=meta_info["experiment_type"])
        with open(flow_path, 'w', encoding='utf-8') as json:
            dump(flows, json)
        
        with open(swagger_path, 'w', encoding='utf-8') as swagger:
            dump(swagger_tmpl_str, swagger)
        self.make_tarfile(tar_path, path_dir)
        sav = self.modelSchema(run_name=run_name, results=results, drift= drift, base_path=self.model_path, catalog_key=catalog_key, meta_info=meta_info, tar_path = path_dir+ ".tar.tz" ,model_key= model_key, algorithm=algorithm, metrics=metrics, preprocessing=preprocessing, model=model, schema=schema).save()
        a = sav.to_json()
   
        return a
    def make_tarfile(self, output_filename, source_dir):
        with tarfile.open(output_filename, "w:gz") as tar:
            tar.add(source_dir, arcname=path.basename(source_dir))

    def update(self, **kwargs):
        pass

    def update_endpoint(self, **kwargs):
        catalog_key = kwargs["catalog_key"]
        obj = self.get(catalog_key)
        obj = loads(obj)
        if len(obj) > 0:
            path = obj[0]["base_path"] + "/swagger.json"
            json_string = None
            with open(path, "r") as file_open:
                json_string  = loads(file_open.read())
            host = kwargs["host"] or json_string["host"]
            endpoint = kwargs["endpoint"] or json_string["basePath"]
            json_string["host"] = host
            json_string["basePath"] = endpoint
            with open(path, "w") as file_write:
                dump(json_string, file_write)
            d = self.modelSchema.objects(catalog_key=catalog_key,model_key= self.model_key).modify(new= True,
                            set__host = host, set__endpoint=endpoint)
            return {"status": "success", "message": "Endpoint Successfully updated"}
        return {"status": "error", "message": "Model Key invalid"} 

    def get(self, catalog_key):
        return self.modelSchema.objects(catalog_key=catalog_key,model_key= self.model_key).to_json()

    def delete(self):
        pass

    def publish(self, catalog_key=None, model_name=None, id=None):
        sav = self.modelSchema.objects(catalog_key=catalog_key,model_key= self.model_key).modify(new= True,
                            set__model_name = model_name,
                            set__is_published = True)
        return {"status": "success", "message": "Successfully Published"}
    
    def unpublish(self, catalog_key, id):
        sav = self.modelSchema.objects(catalog_key=catalog_key, model_key= self.model_key).modify(new= True,
                            set__is_published = False)
        return {"status": "success", "message": "Successfully Unpublished"}