
from joblib import dump
from os import environ, path, makedirs

class Preprocessing(object):

    def __init__(self, model_key, active):
        self.active = active
        self.model_key = model_key
        if model_key is None:
            raise ValueError("Model Key is required")
        self.model_path = environ.get("MODELDB_PATH", None)

    def impute(self, **kwargs):
        data = {
            "column": kwargs["column"],
            "type": kwargs["type"],
            "value": kwargs["value"]
        }
        self.active.preprocessing["feature_handling"]["impute"].append(data)
        return data


    def scaling(self, **kwargs):
        # model_path = self.model_path + self.model_key + "/preprocessing"
        # if not path.exists(model_path):
        #     makedirs(model_path)
        file_name = kwargs["column"] +"_" + kwargs["type"] + ".pkl"
        # model_path = model_path + "/" + file_name
        # dump(kwargs["model"], model_path)
        data = {
            "column": kwargs["column"],
            "type": kwargs["type"],
            "file_name": file_name,
            "pkl_file": kwargs["model"]
        }
        self.active.preprocessing["feature_handling"]["scaling"].append(data)
        return data

    def encoding(self, **kwargs):
        # model_path = self.model_path + self.model_key + "/preprocessing"
        # if not path.exists(model_path):
        #     makedirs(model_path)
        data = {
            "column": kwargs["column"],
            "type": kwargs["type"],
            "data": kwargs["data"],
            "encoded": kwargs["encoded"] if 'encoded' in kwargs else True
        }
        if kwargs['type'] == 'dummy encoding':
            file_name = kwargs["column"] +"_" + kwargs["type"] + ".pkl"
            # model_path = model_path + "/" +file_name
            # dump(kwargs["model"], model_path)
            data["pkl_file"] = kwargs["model"]
            data["file_name"] = file_name
            data["dropone"] = kwargs["dropone"] if 'dropone' in kwargs else False
        elif kwargs['type'] == '0/1 flag':
            pass
        self.active.preprocessing["feature_handling"]["encoding"].append(data)
        return data

    def feature_reduction(self, **kwargs):
        if kwargs['type'] == 'pca':
            # model_path = self.model_path + self.model_key + "/preprocessing"
            # if not path.exists(model_path):
            #     makedirs(model_path)
            file_name = "pca.pkl"
            # dump(kwargs["model"], model_path)
            self.active.preprocessing["feature_reduction"] = {
                "type": kwargs["type"],
                "pkl_file": kwargs["model"],
                "file_name":file_name
            }
        elif kwargs['type'] == 'correlation':
            self.active.preprocessing["feature_reduction"] = {
                "type": kwargs["type"],
                "columns_to_keep": kwargs["columns_to_keep"]
            }
        return self.active.preprocessing["feature_reduction"]


