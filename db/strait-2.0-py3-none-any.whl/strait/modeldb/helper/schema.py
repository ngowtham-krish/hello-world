from strait.core.model.schema import ColumnInfoSchema
from json import loads
class Schema(object):

    def __init__(self, model_key=None, active=None):
        self.active = active

    def input(self, **kwargs):
        columnInfo = ColumnInfoSchema.objects(catalog_key=kwargs["catalog_key"], project_key=kwargs["project_key"], dataset_key=kwargs["dataset_key"]).to_json()
        columnInfo = loads(columnInfo)
        d_types = []
        if len(columnInfo) > 0:
            for columns in columnInfo:
                d_types.append(columns["metadata"]["datatypes"])
            self.active.dataset = d_types
            self.active.meta_info = kwargs
        return self.active.meta_info

        