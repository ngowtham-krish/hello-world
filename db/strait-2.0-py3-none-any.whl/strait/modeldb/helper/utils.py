from os import environ
from joblib import dump
from copy import deepcopy
from pandas import DataFrame

def dump_preprocessing(**kwargs):
    base_path = environ.get("MODELDB_PATH", None)
    preprocessing = deepcopy(kwargs["preprocessing"])
    model_key = kwargs["model_path"]
    folder_path = model_key + "/"

    def feature_handling(data):
        encoding_data = data["encoding"]
        scaling_data = data["scaling"]
        def encoding(encode):
            for enc in range(len(encode)):
                if "type" in encode[enc] and encode[enc]["type"] == "dummy encoding":
                    model = encode[enc]["pkl_file"]
                    tmp_path = folder_path + encode[enc]["file_name"]
                    deepcopied = deepcopy(model)
                    dump(deepcopied, tmp_path)
                    encode[enc]["pkl_file"] = tmp_path
            return encode
        
        def scaling(scale):
            for sca in range(len(scale)):
                if "file_name" in scale[sca]:
                    model = scale[sca]["pkl_file"]
                    tmp_path = folder_path + scale[sca]["file_name"]
                    deepcopied = deepcopy(model)
                    dump(deepcopied, tmp_path)
                    scale[sca]["pkl_file"] = tmp_path
            return scale
        data["encoding"] = encoding(encoding_data)
        data["scaling"]  = scaling(scaling_data)
        return data

    def feature_reduction(data):
        if data and "file_name" in data:
            model = data["pkl_file"]
            tmp_path = folder_path + data["file_name"]
            deepcopied = deepcopy(model)
            dump(deepcopied, tmp_path)
            dump(model, tmp_path)
            data["pkl_file"] = tmp_path
            return data
        else:
            return {}
    preprocessing["feature_handling"] = feature_handling(preprocessing["feature_handling"])
    preprocessing["feature_reduction"] = feature_reduction(preprocessing["feature_reduction"])
    return preprocessing

def dump_model(**kwargs):
    base_path = kwargs["model_path"]
    model = kwargs["model"]
    folder_path = base_path + "/"
    tmp_path = folder_path + model["file_name"]
    if 'df' in model:
        model["df"].to_csv(tmp_path)
        del model["df"]
    else:
        dump(model["pkl_file"],tmp_path)
    model["pkl_file"] = tmp_path
    return model

