
class Metrics(object):

    def __init__(self, model_key=None, active = None):
        self.model_key = model_key
        self.active = active


    def metrics(self, **kwargs):
        metrics = self.active.metrics
        metrics[kwargs["algorithm"]] =  kwargs['metrics']
        self.active.metrics = metrics
        return self.active.metrics
        # print(preprocessing)
