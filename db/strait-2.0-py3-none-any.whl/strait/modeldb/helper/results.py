
class Results:

    def __init__(self, model_key=None, active = None):
        self.model_key = model_key
        self.active = active
    
    def save(self, **kwargs):
        results = self.active.results
        if kwargs["algorithm"] in results:
            results[kwargs["algorithm"]].append(kwargs['results'])
        else:
            results[kwargs["algorithm"]] = []
            results[kwargs["algorithm"]].append(kwargs['results'])
        self.active.results = results
        return self.active.results