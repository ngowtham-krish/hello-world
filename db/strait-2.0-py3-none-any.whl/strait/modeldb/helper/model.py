
from joblib import dump
from os import environ, path, makedirs
from pandas import DataFrame, Series
class Model(object):

    def __init__(self, model_key=None, active=None):
        self.active = active
        self.model_key = model_key
        if model_key is None:
            raise ValueError("Model Key is required")
        self.model_path = environ.get("MODELDB_PATH", None)

    def model(self, **kwargs):
        model = kwargs["model"]
        if "algorithm_name" in kwargs:
            alg_name = kwargs["algorithm_name"]
        else:
            alg_name = type(model).__name__
        data = {
            "algorithm": alg_name,
        }
        if self.active.meta_info["experiment_type"] == "Timeseries":
            data["df"] = kwargs["model"]
            data["file_name"] = alg_name + ".csv"
        else:
            data["pkl_file"] = kwargs["model"]
            data["file_name"] = alg_name + ".pkl"
        self.active.model.append(data)