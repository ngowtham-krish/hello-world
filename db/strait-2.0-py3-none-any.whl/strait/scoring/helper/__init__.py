import joblib

class Model(object):

    def __init__(self, df, pkl):
        self.model = joblib.load(pkl)
        self.dataframe = df

    
    def predict(self):
        
        return self.model.predict(self.dataframe)
    
    def predict_proba(self):
        proba_0 = self.model.predict_proba(self.dataframe)[:,0]
        proba_1 = self.model.predict_proba(self.dataframe)[:,1]
        return proba_0, proba_1