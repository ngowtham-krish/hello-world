# from strait.core.model.schema import ModelsSchema
import sys, os, json, random
from string import ascii_lowercase, digits
from strait.scoring.preprocessing import process, drop_reject_variables, drop_target_variable
from strait.scoring.helper import Model
from strait.scoring.model.schema.scoring_schema import ScoringSchema
from pandas import read_excel
from strait.modeldb.model.schema.models_schema import ModelsSchema
from datetime import datetime
class Predict(object):

    def __init__(self, model_id= None, catalog_key=None, input_data=None):
        self.model_id = model_id
        self.catalog_key = catalog_key
        self.schema = ModelsSchema
        self.result = None
        self.input = input_data
        self.model_path = os.environ.get("MODELDB_PATH") + model_id
        self.scoringSchema = ScoringSchema
        self.__predict()
        
    def __predict(self):
        data = self.schema.objects(model_key = self.model_id).to_json()
        # print("Data Returned ", data)
        data = json.loads(data)
        if len(data) > 0:
            model_path = data[0]["base_path"]
            with open(model_path + '/flow.json', 'r') as model:
                # model = model.read()
                m = json.load(model)
                # print("Flow Json ",m)
                if m["flow_key"] == self.model_id:
                    input_data = self.input
                    # print("Input ", input_data)
                    feature_info = m["meta_info"]["features"]
                    df = drop_reject_variables(input_data, feature_info["ignore"])
                    # print("after ignore", df)
                    
                    preprocessing = m["preprocessing"]
                    dataframe = process(data_frame = df, operations=preprocessing)
                    if m["meta_info"]["experiment_subtype"] != "Clustering":
                        dataframe = drop_target_variable(dataframe, feature_info["target"])
                    model = m["model"]["pkl_file"]
                    predict = Model(dataframe, model).predict()
                    # print("Predict", predict)
                    self.input[feature_info["target"]["variable_name"]] = predict

                    try:
                        if m["meta_info"]["experiment_subtype"] == "Classification":
                            probality_0, probality_1 = Model(dataframe, model).predict_proba()
                            print("Proba ",  probality_0, probality_1)
                            self.input["Confidence_0"] = probality_0
                            self.input["Confidence_1"] = probality_1
                    except Exception as e:
                        print ("Cannot predict Probality using {algorithm}, because {error}".format(algorithm=m["model"]["algorithm"], error = str(e)))
                    # result = self.input[feature_info["target"]["variable_name"]]
                    self.result = self.input
                    copied = self.result.copy()
                    rows = copied.shape[0]
                    filename = ''.join(random.choices(ascii_lowercase +
                                digits, k = 20)) + ".csv"
                    model_path = self.model_path + "/predictions/"
                    if not os.path.exists(model_path):
                        os.makedirs(model_path)
                    obj = self.scoringSchema.objects(model_key= self.model_id, catalog_key =  self.catalog_key)
                    if (obj.count() == 0):
                        copied.to_csv(model_path + filename)
                        predicts = {
                            "rows": rows,
                            "path": model_path + filename,
                            "date": datetime.now()
                        }
                        schema_cursor = self.scoringSchema(model_key = self.model_id, catalog_key = self.catalog_key, predictions= [predicts])
                        schema_cursor.save()
                    else:
                        copied.to_csv(model_path + filename)
                        obj1 = self.scoringSchema.objects(model_key= self.model_id, catalog_key =  self.catalog_key).get()
                        predicts = {
                            "rows": rows,
                            "path": model_path + filename,
                            "date": str(datetime.now())
                        }
                        obj1.predictions.append(predicts)
                        obj1.updated_at = datetime.now()
                        obj1.save()
                else:
                    self.result = {"status": "error", "message": "model_key is invalid"}
        else:
            self.result = {"status": "error", "message": "model_key is invalid"}

