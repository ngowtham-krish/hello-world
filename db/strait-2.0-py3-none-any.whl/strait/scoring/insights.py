# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 10:32:46 2020

@author: saurabhm
Measures - LineTotal, Quantity

Dimensions hierarchy (High to low):
dimension group - Geography - Zone-Sales Zone-Region-Branch
dimension group - Brand - U_Brand-U_GProp-U_GSEM-ItmsGrpNam

Query : LineTotal
Insights : Insights will be generated based on all the dimensions

Query : LineTotal by Sales Zone
Insights : Insights will be generated for LineTotal based on geographical dimensions, only dimensions lower in hierarchy will be considered
eg., for this case insights will be generated for LineTotal based on Sales Zone, Region and Branch

Query : Quantity by U_GSEM
Insights : Insights will be generated for Quantity based on brand/product related dimensions, only dimensions lower in hierarchy will be considered
eg., for this case insights will be generated for Quantity based on U_GSEM and ItmsGrpNam

Calling the function:
    narration = Insights(qmeasure=['LineTotal'],qdimension='Zone',qdimensionvalue=['Chennai','South']).get_insights()
    inputs:
    qmeasure  =  list of measures passed in query from the user
    qdimension = dimension name passed in query from the user..if dimension is not present in query then pass None
    qdimensionvalue = list of elements passed in query from user
    eg., compare LineTotal for Chennai and South zones
"""
class Insights(object):
    def __init__(self, file_path, qmeasure,qdimension,qdimensionvalue, artifact):
        import pandas as pd
        self.forecast_filename = file_path
        #read the json with top performers from scoring node
        self.config = pd.read_json(artifact)
        #read the consolidated forecast data from scoring node
        self.forecast_ds = pd.read_csv(self.forecast_filename)
        self.date = 'DocDate'
        self.qdimension = qdimension
        self.qdimensionvalue = qdimensionvalue
        self.measures = qmeasure
        self.geographies = ['Zone','Sales Zone','Region','Branch']
        self.brands = ['U_Brand','U_GProp','U_GSEM','ItmsGrpNam']
        self.dimensions = self.geographies + self.brands
        self.narration = []
        self.low_days = []
        self.high_days = []
    def get_insights(self):
        def overall_insights(measure):
            import pandas as pd
            import numpy as np
            forecast_ds = self.forecast_ds
            overall = forecast_ds.loc[np.where((forecast_ds['measure']==measure)&(forecast_ds['dimension']=='all')&(forecast_ds['dimension_value']=='all'))]
            overall['ds'] = pd.to_datetime(overall['ds'])
            overall['diff'] = overall['yactual'] - overall['yhat']
            overall['high'] = np.where((overall['yactual']>overall['yhat_upper']),'yes','no')
            overall['low'] = np.where((overall['yactual']<overall['yhat_lower']),'yes','no')
            overall = overall.sort_values(by='diff', ascending=False)
            low_anomaly = overall[overall['low']=='yes']
            low_anomaly_ds = low_anomaly['ds']
            low_anomaly_ds = low_anomaly_ds.sort_values(ascending=True)
            low_anomaly['ds'] = low_anomaly['ds'].dt.strftime('%B %Y').astype('str')
            low_anomaly['percent_change'] = (low_anomaly['diff']/low_anomaly['yactual'])*100
            low_anomaly = low_anomaly.reset_index().drop('index',axis=1)
            high_anomaly = overall[overall['high']=='yes']
            high_anomaly_ds = high_anomaly['ds']
            high_anomaly_ds = high_anomaly_ds.sort_values(ascending=True)
            high_anomaly['ds'] = high_anomaly['ds'].dt.strftime('%B %Y').astype('str')
            high_anomaly['percent_change'] = (high_anomaly['diff']/high_anomaly['yactual'])*100
            high_anomaly = high_anomaly.reset_index().drop('index',axis=1)
            if len(low_anomaly_ds)>0:
                low_days = ','.join(map(str, low_anomaly_ds.dt.strftime('%B %Y').astype('str')))
                self.narration.append("During the month of "+str(low_days +" there has been significant fall in "+str(measure)))
                if low_anomaly.loc[0,'percent_change']<0:
                    self.narration.append("Maximum fall of "+str(int(round(np.abs(low_anomaly.loc[0,'percent_change'])))) +"% from expected value of "+str(measure)+" was reported in "+str(low_anomaly.loc[0,'ds']))
            if len(high_anomaly_ds)>0:
                high_days = ','.join(map(str, high_anomaly_ds.dt.strftime('%B %Y').astype('str')))
                self.narration.append("During the month of "+str(high_days +" there has been significant rise in "+str(measure)))
                if high_anomaly.loc[0,'percent_change']>0:
                    self.narration.append("Maximum rise of "+str(int(round(np.abs(high_anomaly.loc[0,'percent_change'])))) +"% from expected value of "+str(measure)+" was reported in "+str(high_anomaly.loc[0,'ds']))
            self.low_days = low_anomaly_ds
            self.high_days = high_anomaly_ds
        def drill_down_insights(measure,dimension,dimension_value):
            import numpy as np
            import pandas as pd
            low_anomaly_ds = self.low_days
            high_anomaly_ds = self.high_days
            list_of_elements = self.config.loc[dimension,measure]
            if dimension_value==None:
                if len(list_of_elements)>5:
                    list_of_elements = list_of_elements[0:5]
            else:
                list_of_elements=dimension_value
            dt = pd.DataFrame(columns={self.date,dimension,'yactual','yhat','yhat_upper','yhat_lower'})
            k=0
            for i in list_of_elements:  
                forecast_ds = self.forecast_ds
                a = forecast_ds.loc[np.where((forecast_ds['measure']==measure)&(forecast_ds['dimension']==dimension)&(forecast_ds['dimension_value']==i))]
                a['ds'] = pd.to_datetime(a['ds'])
                a['yhat'] [a['yhat']<0] = 0
                for low in low_anomaly_ds:
                    if a[a['ds']==low].shape[0]>0:
                        dt.loc[k,self.date] = low
                        dt.loc[k,dimension] = i
                        dt.loc[k,'yactual'] = float(a[a['ds']==low]['yactual'].values)
                        dt.loc[k,'yhat'] = float(a[a['ds']==low]['yhat'].values)
                        dt.loc[k,'yhat_lower'] = float(a[a['ds']==low]['yhat_lower'].values)
                        dt.loc[k,'yhat_upper'] = float(a[a['ds']==low]['yhat_upper'].values)
                        k = k+1
                for high in high_anomaly_ds:
                    if a[a['ds']==high].shape[0]>0:
                        dt.loc[k,self.date] = high
                        dt.loc[k,dimension] = i
                        dt.loc[k,'yactual'] = float(a[a['ds']==high]['yactual'].values)
                        dt.loc[k,'yhat'] = float(a[a['ds']==high]['yhat'].values)
                        dt.loc[k,'yhat_lower'] = float(a[a['ds']==high]['yhat_lower'].values)
                        dt.loc[k,'yhat_upper'] = float(a[a['ds']==high]['yhat_upper'].values)
                        k = k+1
            dt[self.date] = pd.to_datetime(dt[self.date])
            dt[self.date] = dt[self.date].dt.strftime('%B %Y').astype('str')
            dt['yactual'] = np.where((dt['yactual']<=0),0.0000000001,dt['yactual'])
            dt['percent_change'] = ((dt['yactual']-dt['yhat'])/dt['yactual'])*100
            dt['high_anomaly'] = np.where((dt['yactual']>dt['yhat_upper']),'yes','no')
            dt['low_anomaly'] = np.where((dt['yactual']<dt['yhat_lower']),'yes','no')  
            low_anomaly_temp = dt[dt['low_anomaly']=='yes'].reset_index().drop('index',axis=1)
            high_anomaly_temp = dt[dt['high_anomaly']=='yes'].reset_index().drop('index',axis=1)
            if low_anomaly_temp.shape[0]>0:
                temp = low_anomaly_temp[low_anomaly_temp[self.date].isin(self.low_days.dt.strftime('%B %Y').astype('str'))]
                for month in temp[self.date].unique():
                    t = ','.join(map(str, list(temp[temp[self.date]==month][dimension])))
                    self.narration.append('The fall in '+str(measure)+' during the month of '+str(month)+' happened because of fall in '+str(measure)+' for '+str(dimension)+' '+str(t))
            if high_anomaly_temp.shape[0]>0:
                temp = high_anomaly_temp[high_anomaly_temp[self.date].isin(self.high_days.dt.strftime('%B %Y').astype('str'))]
                for month in temp[self.date].unique():
                    t = ','.join(map(str, list(temp[temp[self.date]==month][dimension])))
                    self.narration.append('The spike in '+str(measure)+' during the month of '+str(month)+' happened because of spike in '+str(measure)+' for '+str(dimension)+' '+str(t))
        if self.measures!=None and self.qdimension==None and self.qdimensionvalue==None:
            for measure in self.measures:
                overall_insights(measure)
                for dimension in self.dimensions:
                    drill_down_insights(measure,dimension,None)
        elif self.measures!=None and self.qdimension!=None and self.qdimensionvalue==None:
            dimension_group = ''
            if self.qdimension in self.brands:
                dimension_group = self.brands
                dimension_list = dimension_group[dimension_group.index(self.qdimension):len(dimension_group)]
            else:
                dimension_group = self.geographies
                dimension_list = dimension_group[dimension_group.index(self.qdimension):len(dimension_group)]
            for measure in self.measures:
                overall_insights(measure)
                for dimension in dimension_list:
                    drill_down_insights(measure,dimension,None)
        elif self.measures!=None and self.qdimension!=None and self.qdimensionvalue!=None:
            for measure in self.measures:
                overall_insights(measure)
                drill_down_insights(measure,self.qdimension,self.qdimensionvalue)
        return self.narration
