from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class ScoringSchema(Document):
    model_key       = StringField(max_length=200, required=True)
    catalog_key     = StringField()
    predictions     = ListField()
    created_at      = DateTimeField(default=datetime.now())
    updated_at      = DateTimeField(default=datetime.now())
    created_by      = StringField()
    updated_by      = StringField()
    owners          = ListField()
    deleted         = BooleanField(default= False)
    meta            = {'collection': 'predictions'}




