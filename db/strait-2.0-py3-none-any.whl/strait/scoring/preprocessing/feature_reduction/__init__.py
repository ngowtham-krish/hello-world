from strait.scoring.preprocessing.feature_reduction.PCA import PCA

class FeatureReduction(object):

    def __init__(self, data_frame, operation):
        self.dataframe = data_frame

    def to_dataframe(self):
        return self.dataframe