
from strait.scoring.preprocessing.feature_handling import FeatureHandling
from strait.scoring.preprocessing.feature_reduction import FeatureReduction
from pandas import DataFrame

def process(**kwargs):
    # try:
    if not isinstance(kwargs["data_frame"], DataFrame) and kwargs["data_frame"].empty:
        raise TypeError("Pandas DataFrame is required or might be DataFrame is Empty")

    if not isinstance(kwargs["operations"], dict):
        raise TypeError("Data should in Dict Format")
    fh_output = FeatureHandling(data_frame=kwargs["data_frame"], operations=kwargs["operations"]["feature_handling"]).to_dataframe()
    fr_output = FeatureReduction(data_frame=fh_output, operation=kwargs["operations"]["feature_reduction"]).to_dataframe()
    return fr_output
    # except Exception as e:
    #     return str(e)


def drop_reject_variables(df, ignore):
    for feature in ignore:
        if feature["variable_name"] in df.columns:
            df = df.drop([feature["variable_name"]], axis=1)
    return df

def drop_target_variable(df, target):
    if target["variable_name"] in df.columns:
        df = df.drop([target["variable_name"]], axis=1)
    return df