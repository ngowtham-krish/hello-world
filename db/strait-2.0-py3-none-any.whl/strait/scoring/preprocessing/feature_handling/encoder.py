from joblib import load

class Encoder(object):

    def __init__(self, data_frame, data):
        self.dataframe = data_frame
        self.output = None
        self.data = data
        if data["type"] == "label encoder":
            self.output = self.label_encoder()
        elif data["type"] == "dummy encoding":
            self.output = self.dummpy_encoding()
        elif data["type"] == "0/1 flag":
            self.output = self.flag
        else:
            self.output = self.dataframe


    def dummpy_encoding(self):
        one_hot_fitted = load(self.data["pkl_file"])
        self.dataframe = one_hot_fitted.transform(self.dataframe)
        if self.data["dropone"]:
            column_to_drop = self.data["data"]
            self.dataframe = self.dataframe.drop(column_to_drop,axis=1)
        return self.dataframe

    def flag(self):
        return self.dataframe

    def label_encoder(self):
        pickle = self.data["pkl_file"]
        column = self.data["column"]
        model = load(pickle)
        self.dataframe[column] = model.transform(self.dataframe[column])

    def get(self):
        return self.dataframe
