from strait.scoring.preprocessing.feature_handling.encoder import Encoder
from strait.scoring.preprocessing.feature_handling.impute import Impute
from strait.scoring.preprocessing.feature_handling.scaling import Scaling
from pandas import DataFrame

class FeatureHandling(object):

    def __init__(self,data_frame, operations):
        self.dataframe = data_frame
        self.operations = operations
        self.final_dataframe = DataFrame()
        self.feature_handling(self.dataframe, self.operations)
    
    def feature_handling(self, dataframe, operations):
        dataframe = self.impute(dataframe, operations["impute"])
        dataframe = self.scaling(dataframe, operations["scaling"])
        dataframe = self.encoder(dataframe, operations["encoding"])
        self.final_dataframe = dataframe

    # @classmethod
    def impute(self, dataframe, operations):
        df = dataframe
        for column in operations:
            print("Impute", column)
            df = Impute(df, column).get()
        return df

    # @classmethod
    def scaling(self, dataframe, operations):
        df = dataframe
        for column in operations:
            print("Scaling", column)
            df = Scaling(df, column).get()
        return df

    # @classmethod
    def encoder(self, dataframe, operations):
        df = dataframe
        for column in operations:
            print("Encoder", column)
            df = Encoder(df, column).get()
        return df

    def to_dataframe(self):
        return self.final_dataframe
