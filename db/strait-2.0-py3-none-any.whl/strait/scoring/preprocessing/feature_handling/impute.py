class Impute(object):

    def __init__(self, data_frame, data):
        self.column = data["column"]
        self.dataframe = data_frame
        self.data = data
        self.output = None
        if data["type"] == "treat as a regular value":
            self.output = self.dataframe
        elif data["type"] == "constant value":
            self.output = self.constant_value(self.dataframe, self.column, self.data["value"])
        elif data["type"] == "mean":
            self.output = self.mean(self.dataframe, self.column, self.data["value"])
        elif data["type"] == "median":
            self.output = self.median(self.dataframe, self.column, self.data["value"])
        elif data["type"] == "mode":
            self.output = self.mode(self.dataframe, self.column, self.data["value"])
        elif data["type"] == "regular_value":
            self.output = self.regular_value(self.dataframe, self.column, self.data["value"])
        else:
            raise NotImplementedError("Not Implemented Error {}".format(data["subtype"]))

    
    def constant_value(self, df, column, value):
        df[column].fillna(value, inplace=True)
        return df
    
    def mean(self, df, column, value):
        df[column].fillna(value, inplace=True)
        return df

    def median(self, df, column, value):
        df[column].fillna(value, inplace=True)
        return df

    def mode(self, df, column, value):
        df[column].fillna(value, inplace=True)
        return df

    def regular_value(self, df, column, value):
        df.loc[df[column].isna(),column] = value
        return df

    def get(self):
        return self.output