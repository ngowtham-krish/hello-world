from sklearn import preprocessing
from joblib import load, dump
class Scaling(object):

    def __init__(self, data_frame, data):
        self.dataframe = data_frame
        self.column = data["column"]
        self.data = data
        self.output = None
        if self.data["type"] == "standard scaling":
            self.output = self.standard_scale(self.dataframe, self.column, self.data)
        elif self.data["type"] == "min max scaling":
            self.output = self.numerical_min_max_scale(self.dataframe, self.column, self.data)
        else:
            self.output = self.dataframe

    def numerical_min_max_scale(self, df, column, data):
        min_max = load(data["pkl_file"])
        self.dataframe[[column]] = min_max.transform(df[[column]])
        return self.dataframe

    def standard_scale(self, df, column, data):
        scalar = load(data["pkl_file"])
        print("Scalar ", scalar)
        self.dataframe[[column]] = scalar.transform(df[[column]])
        return self.dataframe

    def get(self):
        return self.output