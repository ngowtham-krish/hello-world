from strait.modeldb.model.schema.models_schema import ModelsSchema
import sys, os, json
from pandas import read_excel, read_csv, to_datetime, merge, concat
import numpy as np

class Anomaly(object):

    def __init__(self, model_id= None, catalog_key=None, input_data=None):
        self.model_id = model_id
        self.catalog_key = catalog_key
        self.schema = ModelsSchema
        self.result = None
        self.input = input_data
        self.model_path = os.environ.get("MODELDB_PATH") + model_id
    
    def detect(self):
        try:
            data = self.schema.objects(model_key = self.model_id).to_json()
            data = json.loads(data)
            if len(data) > 0:
                # Getting Predicted Data From ModelDB Repository
                source_file_path = data[0]["model"]["pkl_file"]
                #print("Source Path ",source_file_path)
                source_df = read_csv(source_file_path)
                # Getting Target and Timestamp Variable From Run Definition
                feature_variables = data[0]["meta_info"]["rundefinition"]["feature_handling"]["feature_variables"]
                target_variable = [x["variable_name"] for x in feature_variables if x["role"] == "target"]
                timestamp_variable = [x["variable_name"] for x in feature_variables if x["variable_type"] == "Timestamp" or x["variable_type"] == "Date"]
                #Checking whether Input Data Have Target and Timestamp Variable or Not
                if target_variable[0] in self.input.columns and timestamp_variable[0] in self.input.columns:
                    # Converting Timestamp variable to Pandas DateTime Type Both Predicted and Actual
                    self.input[timestamp_variable[0]] = to_datetime(self.input[timestamp_variable[0]], utc=True)
                    source_df["ds"] = to_datetime(source_df["ds"], utc=True)
                    source_df.rename(columns={"ds": timestamp_variable[0]}, inplace=True)
                    #print("source_df", source_df)
                    #print("target_df", self.input)
                    # Filtering Records based on Input Dates
                    filtered_row = source_df[source_df[timestamp_variable[0]].isin(self.input[timestamp_variable[0]].values)]
                    #print("Filters", filtered_row)
                    if filtered_row.shape[0] > 0:
                        merged = merge(self.input, filtered_row, how='right', on=timestamp_variable[0])
                        filtered = merged[[timestamp_variable[0],"yhat", "yhat_lower", "yhat_upper", target_variable[0]]]
                        #print("Filetered 1 ", filtered)
                        filtered["anomaly"] = np.where((filtered['yhat_lower'] > filtered[target_variable[0]]) | (filtered['yhat_upper'] < filtered[target_variable[0]]) , True, False)
                        #print("Filetered 2 ", filtered)
                        final_df = filtered[[timestamp_variable[0], target_variable[0], "yhat", "anomaly"]]
                        #print("Final DF ", final_df)
                        final_df.rename(columns={"yhat": "predicted"}, inplace=True)
                        #print("Renamed 1 ", final_df)
                        return final_df
                    else:
                        return {"status": "failed", "message": "no matching prediction found"}
                else:
                    return {"status": "failed", "message": "Target or Timestamp Variable are missing"}
            else:
                return {"status": "failed", "message": "invalid model key given"}
        except Exception as e:
            return {"status": "failed", "message": str(e)}