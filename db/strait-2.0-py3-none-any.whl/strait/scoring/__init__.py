

class Scoring(object):

    def __init__(self):
        pass


    def upload_tar(self,):
        pass