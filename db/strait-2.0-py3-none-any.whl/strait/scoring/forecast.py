# -*- coding: utf-8 -*-
"""
Created on Wed Apr  8 14:10:46 2020

@author: saurabhm

Measures - LineTotal, Quantity
Dimensions - 'Zone','Sales Zone','Region','Branch','U_Brand','U_GProp','U_GSEM','ItmsGrpNam'

Query: Forecast LineTotal
Response: Dataframe with aggregate forecast for LineTotal

Query: Forecast LineTotal for Chennai Zone
Response: Dataframe with forecast for LineTotal for Zone = Chennai

How to call:
    Forecast().get_forecast(qmeasure='LineTotal',qdimension='Region',qdimension_value='CH05')

"""
class Forecast(object):
    def __init__(self, file_path):
        import pandas as pd
        #fetching forecasted data from scoring node - forecast.csv
        self.forecast_filename = file_path
        self.forecast_ds = pd.read_csv(self.forecast_filename)
        self.forecast = pd.DataFrame()
        self.response = ''
    def get_forecast(self,qmeasure,qdimension,qdimension_value):
        if qmeasure!=None and qdimension==None and qdimension_value==None:
            temp = self.forecast_ds[self.forecast_ds['measure']==qmeasure]
            temp = temp[temp['dimension']=='all']
            temp = temp[temp['dimension_value']=='all']
            temp = temp.reset_index().drop('index',axis=1)
            self.forecast = temp
            if self.forecast.shape[0]==0:
                self.response = 'Forecast not available'
            else:
                self.response = self.forecast
        if qmeasure!=None and qdimension!=None and qdimension_value!=None:
            temp = self.forecast_ds[self.forecast_ds['measure']==qmeasure]
            temp = temp[temp['dimension']==qdimension]
            temp = temp[temp['dimension_value']==qdimension_value]
            temp = temp.reset_index().drop('index',axis=1)
            self.forecast = temp
            if self.forecast.shape[0]==0:
                self.response = 'Forecast not available'
            else:
                self.response = self.forecast
        return self.response
