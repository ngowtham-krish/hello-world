# -*- coding: utf-8 -*-
"""
Created on Wed Apr  8 12:18:53 2020

@author: saurabhm
Measures - LineTotal, Quantity

Query: Causal relation for LineTotal
Response : list of measures which have causal relation with LineTotal or no causal relation
eg., Changes in Quantity causes change in LineTotal
    None of the measures have causal relationship with LineTotal

How to call:
    Causality().get_causality('LineTotal')

"""
class Causality(object):
    def __init__(self, file_path, measures):
        import pandas as pd
        # fetching causality dataset from scoring node
        self.causality_filename = file_path
        self.causality = pd.read_csv(self.causality_filename)
        self.measures = ['LineTotal','Quantity']
        self.alpha = 0.05
        self.narration = []
    def get_causality(self,measure):
        temp = self.causality[self.causality['measure1']==measure]
        temp = temp[temp['ssr_ftest']<self.alpha]
        temp = temp[temp['params_ftest']<self.alpha]
        temp = temp[temp['ssr_chi2test']<self.alpha]
        temp = temp[temp['lrtest']<self.alpha]
        if temp.shape[0]==0:
            self.narration.append('None of the measures have causal relationship with '+str(measure))
        else:
            m = temp['measure2'].unique()
            for x in m:
                self.narration.append('Changes happened in past for '+str(x)+' caused change in '+str(measure))
        return self.narration

# -*- coding: utf-8 -*-
"""
Created on Wed Apr  8 12:57:31 2020

@author: saurabhm
How to train the models:
    Call Train().train()
"""
class Train(object):
    def __init__(self, file_path):
        import pandas as pd
        #read sathya data
        self.filename = file_path
        self.date = 'DocDate'
        self.data = pd.read_csv(self.filename)
        self.measures = ['LineTotal','Quantity']
        self.lags = 4
        self.causality = pd.DataFrame(columns=['measure1','measure2','lag','ssr_ftest','params_ftest','ssr_chi2test','lrtest'])
        agg_obj = {}
        for m in self.measures:
            agg_obj.update({m:'sum'})
        self.data = self.data.groupby(self.date).agg(agg_obj)
        self.data = self.data.reset_index()
        self.data[self.date] = pd.to_datetime(self.data[self.date])
        self.data = self.data.sort_values(by=self.date,ascending=True)
    def train(self):
        df = self.data
        from statsmodels.tsa.stattools import grangercausalitytests
        for m1 in self.measures:
            for m2 in self.measures:
                if m1!=m2:
                    temp = df[[m1,m2]]
                    res = grangercausalitytests(temp,maxlag=4)
                    for lag in range(1,self.lags+1):
                        self.causality = self.causality.append({'measure1':m1,'measure2':m2,'lag':lag,
                                               'ssr_ftest':res[lag][0]['ssr_ftest'][1],
                                               'params_ftest':res[lag][0]['params_ftest'][1],
                                               'ssr_chi2test':res[lag][0]['ssr_chi2test'][1],
                                               'lrtest':res[lag][0]['lrtest'][1]},ignore_index=True)
        self.causality.to_csv('/home/scoring-node/causality.csv',index=False)
