from os import path, environ
from json import loads, dumps
from datetime import datetime
from bson import ObjectId
from strait.pipeline.model.schema import PipelineSchema
import strait.pipeline.dataset as pipelineDataset
import strait.pipeline.helper.pipeline_helper as pipeline_helper
from strait.core.model.schema import DatasetSchema

class Model:

    def __init__(self, catalog_key=None, project_key=None):

        if catalog_key is None: 
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else:   
            self.catalog_key = catalog_key

        if project_key is None: 
            self.project_key = environ.get('PROJECT_KEY',None) 
        else:    
            self.project_key = project_key
        
        self.pipeline_schema = PipelineSchema

    def create(self,**kwargs):
    
        try:
            if self.catalog_key is not None and self.project_key is not None:
                source = []
                target = []
                if 'source' in kwargs.keys() and kwargs['source'] is not None:
                    source = kwargs['source']
                
                if 'target' in kwargs.keys() and kwargs['target'] is not None:
                    target = kwargs['target']

                if 'metadata' in kwargs.keys() and kwargs['metadata'] is not None:
                    metadata    = kwargs['metadata']
                 
                metadata = kwargs['metadata']
                
                source2 = metadata['PDSkey']
               
                dataset_obj = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key).filter(key = source2).to_json()
                dataset_obj = list(loads(dataset_obj))

                pipelinedetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=metadata['_id']).to_json()
                pipelinedetails = list(loads(pipelinedetails))
                
                if len(pipelinedetails)>0:
                    target = pipelinedetails[0]['target']
                else:
                    target = []
               
                target1=dataset_obj[0]['_id']['$oid']

                if target1 not in target:
                    target.append(target1)
                else:
                    return ({'status': 'error', 'message': "Model already exists"})


                request_from = kwargs['request_from']
                pipelineObj  = self.pipeline_schema(id=metadata['_id'],catalog_key=self.catalog_key,project_key=self.project_key,source=source,target=target,metadata=metadata,type=request_from)
                pipelineObj.save()

                try:
                    pipelineObjjj = pipelineDataset.Dataset(self.catalog_key,self.project_key,source2)
                    pipeline_resp = pipelineObjjj.create()
                
                except Exception as e:
                    return ({'status': 'error', 'message': str(e)})

                #updating target dataset details
                datasetdetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=target1).to_json()
                datasetdetails = list(loads(datasetdetails))

                modeldetails  = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id = metadata['_id']).to_json()
                modeldetails =  list(loads(modeldetails))
                
                source = datasetdetails[0]['source']
               
                if len(source)<=0 or modeldetails[0]['_id']['$oid'] not in source:
                    source.append(modeldetails[0]['_id']['$oid'])
                    pipeline_obj = self.pipeline_schema.objects(id = target1,catalog_key = self.catalog_key,project_key=self.project_key, isDeleted=False).modify(
                        new=True,
                        set__source = source,
                        set__updatedAt = datetime.now()
                    )
                    

                #updatong source dataset details
                #get datasetid of source
                pipelineObj2 = self.pipeline_schema.objects(id=metadata['_id'],catalog_key=self.catalog_key,project_key=self.project_key,target=target,metadata=metadata,type=request_from).to_json()
                pipelineObj2 = list(loads(pipelineObj2))
               
                dsid =""
                dsId = dsid.join(pipelineObj2[0]['source'])
              
                
                datasetdetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=ObjectId(dsId)).to_json()
                datasetdetails = list(loads(datasetdetails))

                target = datasetdetails[0]['target']
               
                if len(target)<=0 or modeldetails[0]['_id']['$oid'] not in target : 
                    target.append(modeldetails[0]['_id']['$oid'])
                    pipeline_obj = self.pipeline_schema.objects(id =ObjectId(dsId) ,catalog_key = self.catalog_key,project_key=self.project_key, isDeleted=False).modify(
                        new=True,
                        set__target = target,
                        set__updatedAt = datetime.now()
                    )

                return pipeline_helper.pipeline_response(pipelineObj)
            else:
                return ({'status': 'error', 'message': "Required parameter is missing"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    def delete(self,**kwargs):
            try:
                if 'source' in kwargs.keys() and kwargs['source'] is not None:
                    source =kwargs['source']
               
                if 'delete' in kwargs.keys() and kwargs['delete'] is not None:
                    delete = kwargs['delete']

                source= ""
                source = source.join(kwargs['source'])
                    
                if 'target' in kwargs.keys() and kwargs['target'] is not None:
                    target = kwargs['target']

                if 'metadata' in kwargs.keys() and kwargs['metadata'] is not None:
                    metadata    = kwargs['metadata']
                source2 = metadata['_id']
                pipe = self.pipeline_schema.objects(id = ObjectId(source2),catalog_key = self.catalog_key,project_key = self.project_key).to_json()
                pipe = list(loads(pipe))
                
                pipelinemodeldetails = self.pipeline_schema.objects(catalog_key = self.catalog_key,project_key = self.project_key,isDeleted = False,id = ObjectId(source2)).modify(
                    new = True,
                    set__isDeleted = True,
                    set__updatedAt = datetime.now(),
                    set__source = [],
                    set__target=[]
                )


                #removing model id from predicted dataset source
                pipedetails =  self.pipeline_schema.objects(source = source2,catalog_key = self.catalog_key,project_key = self.project_key).to_json()
                pipedetails = list(loads(pipedetails))
                source1 = metadata['PDSkey']
                for item in pipedetails:
                    pipedata = self.pipeline_schema.objects(source = source2,catalog_key = self.catalog_key,project_key = self.project_key).modify(
                        new = True,
                        set__source = [],
                        set__isDeleted = True,
                        set__updatedAt = datetime.now()
                    )

                #removing modelid from source dataset target
                
                pipeobj1 = self.pipeline_schema.objects(id = source,catalog_key = self.catalog_key,project_key = self.project_key,isDeleted = False).to_json()
                pipeobj1 = list(loads(pipeobj1))
                target1 = pipeobj1[0]['target']
                target1.remove(source2)
                pipeobj = self.pipeline_schema.objects(id = source,catalog_key = self.catalog_key,project_key = self.project_key).modify(
                    new = True,
                    set__target = target1,
                    set__updatedAt = datetime.now()
                    )

                return pipeline_helper.pipeline_response(pipelinemodeldetails)
            except Exception as e:
                return ({'status': 'error', 'message': str(e)})