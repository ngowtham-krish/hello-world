
def pipeline_response(pipeline):
    if(pipeline.id!=None):
        response = {
            'pipelineId':str(pipeline.id),
            'catalogKey': pipeline.catalog_key,
            'projectKey': pipeline.project_key,
            'type' : pipeline.type,
            'deleted' : pipeline.isDeleted,
            'updatedAt' : str(pipeline.updatedAt)
        }

        return ({'status':'success','data':response})
    else:
        return ({'status':'error','message':'Some error occur sending pipeline response'})
