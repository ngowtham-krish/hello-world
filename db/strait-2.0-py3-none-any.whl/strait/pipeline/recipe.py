from os import path, environ
from json import loads, dumps
from datetime import datetime
from strait.pipeline.dataset import Dataset
from strait.pipeline.model.schema import PipelineSchema
from strait.core.model.schema import DatasetSchema, RecipeSchema
import strait.pipeline.helper.pipeline_helper as pipeline_helper

class Recipe:

    def __init__(self, catalog_key=None, project_key=None,dataset_key=None,recipe_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API    
            self.project_key = project_key
        
        if recipe_key is None: # For Notebook or Custom Recipe
            self.recipe_key = environ.get('RECIPE_KEY',None) 
        else: # For API    
            self.recipe_key = recipe_key
        
        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API    
            self.dataset_key = dataset_key
        
        self.pipeline_schema = PipelineSchema

    def create(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
                if 'metadata' in kwargs.keys() and kwargs['metadata'] is not None:
                    metadata    = kwargs['metadata']
                else:
                    # Fetching Recipe Details
                    recipe_obj = RecipeSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,key=self.recipe_key,source_key=self.dataset_key,deleted=False).to_json()
                    recipe_obj = list(loads(recipe_obj))
                    if len(recipe_obj) == 0:
                        return ({'status':'error','message':'recipe key is invalid'})
                    
                    source_key = recipe_obj[0]["source_key"]
                    target_key = recipe_obj[0]["target_key"]
                    
                    # First Source Dataset
                    dataset_obj = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,key=source_key[0],deleted=False).to_json()
                    dataset_obj = list(loads(dataset_obj))
                    source_dataset = str(dataset_obj[0]['_id']['$oid'])
                    
                    # Checking recipe type whether it is join or merge
                    if recipe_obj[0]['recipe_type'] in ['join','merge']:
                        # Second Source Dataset
                        dataset_obj = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,key=source_key[1],deleted=False).to_json()
                        dataset_obj = list(loads(dataset_obj))
                        source_dataset_2 = str(dataset_obj[0]['_id']['$oid'])
                            
                    # Target Dataset
                    datadetails = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,key=target_key,deleted=False).to_json()
                    datadetails = list(loads(datadetails))
                    target_dataset = str(datadetails[0]['_id']['$oid'])
                    
                    # Preparing Metadata of Create Recipe for 
                    recipe_obj[0]['_id'] = str(recipe_obj[0]['_id']['$oid'])
                    recipe_obj[0]['created_at'] = str(recipe_obj[0]['created_at']['$date'])
                    recipe_obj[0]['updated_at'] = str(recipe_obj[0]['updated_at']['$date'])
                    metadata = recipe_obj[0]
                    
                    # Pipeline Schema for recipe
                    pipelinedetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=metadata['_id']).to_json()
                    pipelinedetails = list(loads(pipelinedetails))
                    if len(pipelinedetails)>0:
                        source = pipelinedetails[0]['source']
                        target = pipelinedetails[0]['target']
                    else:
                        source = []
                        target = []

                    source.append(source_dataset)
                    # Checking recipe type whether it is join or merge
                    if recipe_obj[0]['recipe_type'] in ['join','merge']:
                        source.append(source_dataset_2)
                    target.append(target_dataset)

                if 'request_from' in kwargs.keys() and kwargs['request_from'] is not None:
                    request_from = kwargs['request_from']
                else:
                    request_from = 'recipe'
                
                # Saving Recipe Details (Have to check with ranjan)
                pipelineObj = self.pipeline_schema(id=metadata['_id'],catalog_key=self.catalog_key,project_key=self.project_key,source=source,target=target,dataset=recipe_obj[0]["source_key"],metadata=metadata,type=request_from)
                pipelineObj = pipelineObj.save()
                
                # Updating First Source Dataset
                datasetdetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=source_dataset).to_json()
                datasetdetails = list(loads(datasetdetails))
                target = datasetdetails[0]['target']
                target.append(recipe_obj[0]['_id'])
                pipeline_obj = self.pipeline_schema.objects(id = source_dataset,catalog_key = self.catalog_key,project_key=self.project_key, isDeleted=False).modify(
                    new=True,
                    set__target = target,
                    set__updatedAt = datetime.now()
                )
                
                # Checking recipe type whether it is join or merge
                if recipe_obj[0]['recipe_type'] in ['join','merge']:
                    # Updating Second Source Dataset
                    datasetdetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=source_dataset_2).to_json()
                    datasetdetails = list(loads(datasetdetails))
                    target = datasetdetails[0]['target']
                    target.append(recipe_obj[0]['_id'])
                    pipeline_obj = self.pipeline_schema.objects(id = source_dataset_2,catalog_key = self.catalog_key,project_key=self.project_key, isDeleted=False).modify(
                        new=True,
                        set__target = target,
                        set__updatedAt = datetime.now()
                    )
                    
                # Update Target Dataset
                datasetdetails = self.pipeline_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,id=target_dataset).to_json()
                datasetdetails = list(loads(datasetdetails))
                source = datasetdetails[0]['source']
                source.append(recipe_obj[0]['_id'])
                pipeline_obj  = self.pipeline_schema.objects(id = target_dataset,catalog_key = self.catalog_key,project_key=self.project_key, isDeleted=False).modify(
                    new=True,
                    set__source = source,
                    set__updatedAt = datetime.now()
                )
                
                return pipeline_helper.pipeline_response(pipelineObj)
            else:
                return ({'status': 'error', 'message': "Required parameter is missing"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    def update(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
                if 'metadata' in kwargs.keys() and kwargs['metadata'] is not None:
                    metadata = kwargs['metadata']
                else:
                    # Recipe
                    recipe_obj = RecipeSchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key=self.recipe_key, deleted=False).to_json()
                    recipe_obj = list(loads(recipe_obj))
                    if len(recipe_obj) == 0:
                        return ({'status':'error','message':'recipe key is invalid'})
                    
                    # Preparing Metadata of Create Recipe for Pipeline
                    recipe_obj[0]['_id'] = str(recipe_obj[0]['_id']['$oid'])
                    recipe_obj[0]['created_at'] = str(recipe_obj[0]['created_at']['$date'])
                    recipe_obj[0]['updated_at'] = str(recipe_obj[0]['updated_at']['$date'])
                    metadata = recipe_obj[0]
                if 'delete' in kwargs.keys() and kwargs['delete'] is not None:
                    delete = kwargs['delete']
                else:
                    delete = False
                if delete == True:
                    recipe_details = self.pipeline_schema.objects(id = recipe_obj[0]['_id'], catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).to_json()
                    recipe_details = list(loads(recipe_details))
                    source_dataset_key = recipe_details[0]['source']
                    
                    if len(source_dataset_key)>0:
                        for source_key in source_dataset_key:
                            recipe_details = self.pipeline_schema.objects(id = source_key, catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).to_json()
                            recipe_details = list(loads(recipe_details))
                            target_keys    = recipe_details[0]['target']
                            if len(target_keys)>0:
                                for item in target_keys:
                                    if item == recipe_obj[0]['_id']:
                                        target_keys.remove(recipe_obj[0]['_id'])
                            
                                if target_keys is None:
                                    target_keys = []

                                pipelineObj = self.pipeline_schema.objects(id = source_key, catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).modify(
                                    new=True,
                                    set__target  = target_keys,
                                    set__updatedAt = datetime.now()
                                )
                pipelineObj = self.pipeline_schema.objects(id = recipe_obj[0]['_id'], catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).modify(
                    new=True,
                    set__metadata  = metadata,
                    set__isDeleted = delete,
                    set__updatedAt = datetime.now()
                )
                return pipeline_helper.pipeline_response(pipelineObj)
            else:
                return ({'status': 'error', 'message': "Required parameter is missing"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
