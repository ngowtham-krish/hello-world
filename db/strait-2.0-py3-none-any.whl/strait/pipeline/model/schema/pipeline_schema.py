from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class PipelineSchema(Document):
    catalog_key = StringField()
    project_key = StringField()
    metadata    = DictField()
    source      = ListField()
    target      = ListField()
    dataset     = ListField()
    createdAt   = DateTimeField(default=datetime.now())
    updatedAt   = DateTimeField(default=datetime.now())
    isDeleted   = BooleanField(default= False)
    type        = StringField()
    meta = {'collection': 'pipelines'}

    @classmethod
    def pre_save(cls,sender,document,**kwargs):
        if project_key in document:
            response = sender.objects(key=document.project_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("project key already exists")

#signals.pre_save.connect(PipelineSchema.pre_save,sender = PipelineSchema)



