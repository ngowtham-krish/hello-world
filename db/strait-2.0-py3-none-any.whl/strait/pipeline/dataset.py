from os import path, environ
from json import loads, dumps
from datetime import datetime
from strait.pipeline.model.schema import PipelineSchema
from strait.core.model.schema import DatasetSchema, RecipeSchema
import strait.pipeline.helper.pipeline_helper as pipeline_helper

class Dataset:

    def __init__(self, catalog_key=None, project_key=None,dataset_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API    
            self.project_key = project_key
        
        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API    
            self.dataset_key = dataset_key
        
        self.pipeline_schema = PipelineSchema

    def create(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                source = []
                target = []
                
                if 'metadata' in kwargs.keys() and kwargs['metadata'] is not None:
                    metadata    = kwargs['metadata']
                else:
                    dataset_obj = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,key=self.dataset_key,deleted=False).to_json()
                    dataset_obj = list(loads(dataset_obj))
                    if len(dataset_obj) == 0:
                        return ({'status':'error','message':'dataset key is invalid'})
                    dataset_obj[0]['_id'] = str(dataset_obj[0]['_id']['$oid'])
                    dataset_obj[0]['created_at'] = str(dataset_obj[0]['created_at']['$date'])
                    dataset_obj[0]['updated_at'] = str(dataset_obj[0]['updated_at']['$date'])
                    metadata = dataset_obj[0]
                
                if 'request_from' in kwargs.keys() and kwargs['request_from'] is not None:
                    request_from = kwargs['request_from']
                else:
                    request_from = 'dataset'
                pipelineObj  = self.pipeline_schema(id=metadata['_id'],catalog_key=self.catalog_key,project_key=self.project_key,source=source,target=target,metadata=metadata,type=request_from)
                pipelineObj.save()
                return pipeline_helper.pipeline_response(pipelineObj)
            else:
                return ({'status': 'error', 'message': "Required parameter is missing"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    def update(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                if 'metadata' in kwargs.keys() and kwargs['metadata'] is not None:
                    metadata    = kwargs['metadata']
                else:
                    dataset_obj = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,key=self.dataset_key,deleted=False).to_json()
                    dataset_obj = list(loads(dataset_obj))
                    if len(dataset_obj) == 0:
                        return ({'status':'error','message':'dataset key is invalid'})
                    dataset_obj[0]['_id'] = str(dataset_obj[0]['_id']['$oid'])
                    dataset_obj[0]['created_at'] = str(dataset_obj[0]['created_at']['$date'])
                    dataset_obj[0]['updated_at'] = str(dataset_obj[0]['updated_at']['$date'])
                    metadata = dataset_obj[0]    
                
                if 'delete' in kwargs.keys() and kwargs['delete'] is not None:
                    delete = kwargs['delete']
                else:
                    delete = False
                if delete == True:
                    dataset_details = self.pipeline_schema.objects(id = dataset_obj[0]['_id'], catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).to_json()
                    dataset_details = list(loads(dataset_details))
                    source_dataset_key = dataset_details[0]['source'] # Recipe Keys
                    if len(source_dataset_key)>0:
                        for source_key in source_dataset_key:
                            recipe_details = self.pipeline_schema.objects(id = source_key, catalog_key = self.catalog_key, project_key=self.project_key).to_json()
                            recipe_details = list(loads(recipe_details))
                            if len(recipe_details)>0:
                                if recipe_details[0]['isDeleted'] in [True]:
                                    pass
                                else:
                                    recipe_details = self.pipeline_schema.objects(id = source_key, catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).to_json()
                                    recipe_details = list(loads(recipe_details))
                                    if len(recipe_details)>0:
                                        # Deleting Recipe From Recipe Schema
                                        recipe_key = recipe_details[0]['metadata']['key']
                                        dataset_key = recipe_details[0]['metadata']['source_key'][0]
                                        
                                        recipe_resp = RecipeSchema.objects(key=recipe_key,source_key=dataset_key,catalog_key = self.catalog_key, project_key=self.project_key, deleted=False).modify(
                                                        new=True,
                                                        set__deleted  = True,
                                                        set__updated_at = datetime.now()
                                                    )
                                        
                                        # Deleting Recipe from Pipeline schema
                                        pipelineObj = self.pipeline_schema.objects(id = recipe_details[0]['_id']['$oid'], catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).modify(
                                            new=True,
                                            set__isDeleted  = True,
                                            set__updatedAt = datetime.now()
                                        )

                                        # Fetching source dataset details
                                        source_keys = recipe_details[0]['source'] # Dataset Keys
                                        if len(source_keys)>0:
                                            for item in source_keys:
                                                dataset_details = self.pipeline_schema.objects(id = item, catalog_key = self.catalog_key, project_key=self.project_key).to_json()
                                                dataset_details = list(loads(dataset_details))
                                                if len(dataset_details)>0:
                                                    if dataset_details[0]['isDeleted'] in [True]:
                                                        pass
                                                    else:
                                                        dataset_details = self.pipeline_schema.objects(id = item, catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).to_json()
                                                        dataset_details = list(loads(dataset_details))
                                                        # Removing recipe key id from target of source datasets
                                                        target_keys    = dataset_details[0]['target']
                                                        if len(target_keys)>0:
                                                            # Checking recipe key inside target of source dataset 
                                                            for target_key in target_keys:
                                                                if target_key == source_key:
                                                                    target_keys.remove(source_key)
                                                        
                                                            if target_keys is None:
                                                                target_keys = []

                                                            pipelineObj = self.pipeline_schema.objects(id = item, catalog_key = self.catalog_key, project_key=self.project_key, isDeleted=False).modify(
                                                                new=True,
                                                                set__target  = target_keys,
                                                                set__updatedAt = datetime.now()
                                                            )
                                    
                pipeline_obj  = self.pipeline_schema.objects(id = metadata['_id'],catalog_key = self.catalog_key,project_key=self.project_key, isDeleted=False).modify(
                    new=True,
                    set__metadata = metadata,
                    set__isDeleted = delete,
                    set__updatedAt = datetime.now()
                )
                return pipeline_helper.pipeline_response(pipeline_obj)
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
          
