from mongoengine import connect
from os import environ
if environ.get("ENVIRONMENT", None) == "DEV":
    mongoclient = environ.get("STRAIT_LOCAL_MONGODB", None)
else:
    mongoclient = environ.get("STRAIT_PROD_MONGODB", None)

try:
    conn = connect(host=mongoclient)
    if conn:
        print (conn)
    else:
        print("unable to connect to db %s")
except Exception as e:
    print("unable to connect to db %s", str(e))