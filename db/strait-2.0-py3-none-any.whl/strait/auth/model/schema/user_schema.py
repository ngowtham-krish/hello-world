from mongoengine import *
from datetime import datetime
from mongoengine import signals

class UserSchema(DynamicDocument):
    name            = StringField(max_length=200, required=True)
    email           = StringField()
    password        = StringField()
    active          = BooleanField(default= False)
    deleted         = BooleanField(default= False)
    refresh_token   = StringField()
    active_session  = ListField()
    created_at      = DateTimeField(default=datetime.now())
    updated_at      = DateTimeField(default=datetime.now())
    meta = {'collection': 'mmx-users'}

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        # Checking whether email id already exists or not
        if 'email' in document:
            response = sender.objects(email=document.email,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Email id already exists")
    
# Checking whether Dataset name already exists before saving data into project 
signals.pre_save.connect(UserSchema.pre_save, sender = UserSchema)




