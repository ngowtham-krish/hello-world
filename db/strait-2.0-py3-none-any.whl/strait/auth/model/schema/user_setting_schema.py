from mongoengine import *
from datetime import datetime
from json import loads, dumps
from mongoengine import signals

class UserSettingSchema(Document):
    user_id         = StringField()
    organization    = StringField(max_length=200)
    designation     = StringField(max_length=200)
    role            = StringField()
    contact_no      = StringField()
    activation_code = StringField()
    remember_me     = BooleanField(default= False) 
    reset_code      = StringField() # Forgot Password
    last_login      = DateTimeField(default=datetime.now())
    created_at      = DateTimeField(default=datetime.now())
    updated_at      = DateTimeField(default=datetime.now())
    meta = {'collection': 'mmx-user_settings'}
                    