import smtplib, ssl
from os import environ
from json import loads, dumps
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email(receiver_email, subject, body, receiver_name=None):
        """ For Sending Email. It requires Receiver emailId, subject and body as required parameter whereas receiver_name as optional """ 
        try: 
                smtp_server     = environ.get('SMTP_SERVER',None)
                smtp_port_no    = environ.get('SMTP_PORT_NO',None)
                sender_email    = environ.get('SENDER_EMAIL',None)    
                password        = environ.get('SENDER_PASSWORD',None)    
                message         = MIMEMultipart("alternative")
                message["Subject"] = subject
                message["From"]    = sender_email
                message["To"]      = receiver_email
                email_body         = MIMEText(body, "html")
                message.attach(email_body)
                # Create secure connection with server and send email
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(smtp_server, smtp_port_no, context=context) as server:
                        server.login(sender_email, password)
                        server.sendmail(sender_email, receiver_email, message.as_string())
                return ({'status':'success','message':'Mail sent successfully'})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)}) 
