from json import loads
from os import environ
from bson import ObjectId
from functools import wraps 
import re, random, string, base64
from datetime import datetime, timedelta, time
from urllib.parse import quote_plus, unquote_plus 
from strait.auth.model.schema import UserSchema,UserSettingSchema

# Validating Incoming request 
def validate(access_token=None,refresh_token=None,email_id=None,user_id=None,logout=False):
    try:
        if access_token is not None or refresh_token is not None or email_id is not None or user_id is not None:
            user_data = None
            if email_id is not None:
                user_data = UserSchema.objects(email=email_id,deleted=False,active=True).to_json()
                user_data = list(loads(user_data))
                if len(user_data)==0:
                    return ({'status':'error','message':'email id is invalid'})

            if refresh_token is not None:
                refresh_token = unquote_plus(refresh_token,encoding='utf-8')
                # Checking whether there is any space in the given string 
                refresh_token = refresh_token.replace(" ","+")
                refresh_token = base64.b64decode(refresh_token).decode('utf-8') 
                user_data = UserSchema.objects(refresh_token=refresh_token,deleted=False,active=True).to_json()
                user_data = list(loads(user_data))
                if len(user_data)==0:
                    return ({'status':'error','message':'refresh token is invalid'})

            if access_token is not None:
                access_token = unquote_plus(access_token,encoding='utf-8')
                # Checking whether there is any space in the given string 
                access_token = access_token.replace(" ","+")
                access_token = base64.b64decode(access_token).decode('utf-8') 
                user_data = UserSchema.objects(active_session__match={'access_token': access_token},deleted=False,active=True).to_json()
                user_data = list(loads(user_data))
                if len(user_data)==0:
                    return ({'status':'error','message':'access token is invalid'})
            
            for item in user_data[0]['active_session']:
                if item['access_token']==access_token:
                    expiry_time = item['expiry_time'].split('.')
                    expiry_time = datetime.strptime(expiry_time[0],'%Y-%m-%d %H:%M:%S')
            #expiry_time = datetime.utcfromtimestamp(int(expiry_time)/1000)
            now = datetime.now()
            if logout == False:
                if expiry_time > now:
                    user_id = user_data[0]['_id']['$oid']
                    user_setting_data = UserSettingSchema.objects(user_id=user_id).to_json()
                    user_setting_data = list(loads(user_setting_data))
                    if len(user_setting_data)==0:
                        return ({'status':'error','message':'session is expired'})
                    else:
                        if user_setting_data[0]['remember_me']:
                            # Session expired time
                            expiry_time    = int(environ.get('EXPIRY_TIME_MIN',None))
                            expiry_time    = datetime.now() + timedelta(minutes = expiry_time)
                            active_session = user_data[0]['active_session']
                            i = 0
                            for item in active_session:
                                active_session[i]['expiry_time'] = str(expiry_time)
                                i = i + 1
                            # Updating expiry_time into user schema
                            user_obj = UserSchema.objects(id=ObjectId(user_id)).modify(
                                new=True,
                                set__active_session= active_session,
                                set__updated_at = datetime.now()
                            )
                        return ({'status':'success'})
                else:
                    return ({'status':'error','message':'session is expired'})
            else:
                return ({"status": "success"})
        else:
            return ({'status':'error','message':'missing required parameter'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})   

# Validating email id already exists or not
def validate_email(email_id=None,requestFrom='login'):
    try:
        if email_id is not None:
            response = UserSchema.objects(email=email_id,deleted=False).to_json()
            response = list(loads(response))
            if requestFrom=='signup':
                if len(response)>0:
                    return ({'status':"error",'message':"email id already exists"})
                else:
                    return ({'status':"success"})
            else:
                if len(response)==0:
                    return ({'status':"error",'message':"email id does not exists"})
                elif response[0]['active'] is False:
                    return ({'status':"error",'message':"account is not active"})
                else:
                    return ({'status':"success"})
        else:
            return ({'status':"error",'message':'emailId is required'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Sending response to UI
def user_response(user,user_setting=None,request_form=None,catalog=None):
    try:
        if user.id is not None:
            data = {
                'userId' : str(user.id),
                'name' : user.name,
                'emailId' : user.email,
                'active' : user.active,
                'deleted' : user.deleted,
                'updatedAt' : str(user.updated_at)
            }

            if request_form is not None:
                if request_form in ['login','generate_token','reset_password']:
                    encoded = base64.b64encode(user.active_session[-1]['access_token'].encode("utf-8"))
                    encoded = str(encoded, "utf-8")
                    encoded = quote_plus(encoded,safe=" /+",encoding='utf-8')
                    data['accessToken'] = encoded
                    data['expiryTime'] = user.active_session[-1]['expiry_time']
                
                if request_form in ['create_user', 'login']:
                    if catalog is not None:
                        data['catalogKey'] = catalog['key'] or catalog.key

            if user_setting is not None:
                data['role'] = user_setting.role
                data['contactNo'] = user_setting.contact_no if user_setting.contact_no is not None else ""
            return ({'status':'success','data':data}) 
        else:
            return ({'status':'error','message':'userId is required'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Generating random string
def random_string(stringLength,string_type=None):
    """ Generate a random string with the combination of lowercase, uppercase letters, digits and special characters """
    try:
        if string_type=='alpha_numeric':
            letters = string.ascii_letters + string.digits
            return ''.join(random.choice(letters) for i in range(stringLength))
        else:
            # Removing ~ it produce + when encode base64 which producing error and plus treating as space separator
            special_char = "`!@$%^&*_="
            letters = string.ascii_letters + string.digits + special_char
            return ''.join(random.choice(letters) for i in range(stringLength))
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Fetching user info from request header
def get_request_headers_info(request):
    try:
        data = {}
        if 'ip_address' in request.form:
            data['ip_address'] = request.form['ip_address']
        else:
            data['ip_address'] = request.remote_addr or ""
        
        if 'user_agent' in request.form:
            data['user_agent'] = request.form['user_agent']
        else:
            data['user_agent'] = request.headers['User-Agent'] or "" 
        return data
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Validating active session
def validate_active_session(active_session_data):
    try:
        data = []
        now = datetime.now()
        for item in active_session_data:
            if item['expiry_time'] is not None and item['expiry_time']!='':
                expiry_time = item['expiry_time'].split('.')
                expiry_time = datetime.strptime(expiry_time[0],'%Y-%m-%d %H:%M:%S')
                if now < expiry_time:
                    data.append(item)
        return data
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Validating reset code
def validate_reset_link(reset_code=None):
    try:
        if reset_code is not None:
            #reset_code = unquote_plus(reset_code,encoding='utf-8')
            # Checking whether there is any space in the given string 
            #reset_code = reset_code.replace(" ","+")
            #reset_code = base64.b64decode(reset_code).decode('utf-8') 
            user_setting_data = UserSettingSchema.objects(reset_code=reset_code).to_json()
            user_setting_data = list(loads(user_setting_data))
            if len(user_setting_data)==0:
                return ({'status':'error','message':'reset code is invalid'})
            else:
                return ({'status':'success','user_id':user_setting_data[0]['user_id']})
        else:
            return ({'status':'error','message':'reset code is required'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Vaidating token is valid or not
def validateToken(request,request_form='notebook'):
    def validateField(func):
        @wraps(func)
        def decorated_function(*args, **kwargs):
            try:
                if 'token' in dict(request.args):  #and 'EmailId' in request.headers:
                    access_token = request.args.get('token')
                    access_token = unquote_plus(access_token,encoding='utf-8')
                    # Checking whether there is any space in the given string 
                    access_token = access_token.replace(" ","+")
                    access_token = base64.b64decode(access_token).decode('utf-8') 
                    user_data = UserSchema.objects(active_session__match={'access_token': access_token},deleted=False,active=True).to_json()
                    user_data = list(loads(user_data))
                    if len(user_data)==0:
                        return ({'status':'error','message':'token is invalid'})
                    else:
                        '''
                        # Checking the email association by accessToken with the given emailId
                        if user_data[0]['email'] != request.headers['EmailId']:
                            return ({'status':'error','message':'unauthorized token'})
                        '''
                        for item in user_data[0]['active_session']:
                            if item['access_token']==access_token:
                                expiry_time = item['expiry_time'].split('.')
                                expiry_time = datetime.strptime(expiry_time[0],'%Y-%m-%d %H:%M:%S')
                        now = datetime.now()
                        if expiry_time > now:
                            user_id = user_data[0]['_id']['$oid']
                            time_delta = now - expiry_time
                            in_seconds = time_delta.days * 24 * 3600 + time_delta.seconds
                            # If time is less then 5 min then extending the expiry time
                            if in_seconds < 300:
                                expiry_time    = int(environ.get('EXPIRY_TIME_MIN',None))
                                expiry_time    = datetime.now() + timedelta(minutes = expiry_time)
                                active_session = user_data[0]['active_session']
                                i = 0
                                for item in active_session:
                                    active_session[i]['expiry_time'] = str(expiry_time)
                                    i = i + 1
                                # Updating expiry_time into user schema
                                user_obj = UserSchema.objects(id=ObjectId(user_id)).modify(
                                    new=True,
                                    set__active_session= active_session,
                                    set__updated_at = datetime.now()
                                )
                        else:
                            return ({'status':'error','message':'session is expired'})
                else:
                    return ({'status':'error','message':'token is required'})
            except Exception as e:
                return ({'status': 'error', 'message': "token is invalid"})

            return func(*args, **kwargs)
        return decorated_function
    return validateField

# Removing the special characters by space 
def remove_special_characters(data):
    try:
        special_character_lists = ["!","#","$","%","&","(",")","*","+","-",".","/",":",";","<","=",">","?","@","[","]","^","`","{","|","}","~"]
        for item in special_character_lists:
            data = data.replace(item, " ")
        return ({'status':'success','data':data})
    except Exception as e:
        return ({'status':"error",'message':str(e)})