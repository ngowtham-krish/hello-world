import base64, pkgutil
from os import environ,path,getcwd
from bson import ObjectId
from json import loads, dumps
from passlib.hash import oracle10
from datetime import datetime, timedelta
import strait.auth.helper.email as email
import strait.auth.helper.validate as validate
from urllib.parse import quote_plus, unquote_plus 
from strait.core.model.schema import CatalogSchema
from strait.auth.model.schema import UserSchema, UserSettingSchema

class Authorization:

    def __init__(self):
        self.user_schema            = UserSchema
        self.user_setting_schema    = UserSettingSchema

    def login(self,*args):
        try:
            data        = dict(*args)
            user_data   = self.user_schema.objects(email=data['email_id'],deleted=False,active=True).to_json()
            user_data   = list(loads(user_data))
            if len(user_data)==0:
                return ({'status':'error','message':'email id is invalid'})

            # Validating password
            secret_key  = environ.get('PASSWORD_SECRET_KEY',None)
            password    = oracle10.hash(secret_key, user=data['password'])
            if password!=user_data[0]['password']:
                return ({'status':'error','message':'password is invalid'})
            
            # Checking whether remember_me is passed
            remember_me    = False 
            if 'remember_me' in data:
                if data['remember_me'] in ['True','true','TRUE']:
                    remember_me = True
                elif data['remember_me'] in ['False','false','FALSE']:
                    remember_me = False 

            random_length  = int(environ.get('RANDOM_LENGTH',None))
            # Removing Expired Session
            active_session = validate.validate_active_session(user_data[0]['active_session'])
            # Session expired time
            expiry_time    = int(environ.get('EXPIRY_TIME_MIN',None))
            expiry_time    = datetime.now() + timedelta(minutes = expiry_time)
            session_data   = {
                'access_token': validate.random_string(random_length),
                'expiry_time': str(expiry_time),
                'ip_address': data['ip_address'],
                'user_agent': data['user_agent']
            }
            active_session.append(session_data)
            # Updating expiry_time into user schema
            user_obj = self.user_schema.objects(email=data['email_id']).modify(
                new=True,
                set__active_session= active_session,
                set__updated_at = datetime.now()
            )
            user_id = str(user_obj.id)
            # Updating last_login into user_setting schema
            user_setting_obj = self.user_setting_schema.objects(user_id=user_id).modify(
                new=True,
                set__last_login = datetime.now(),
                set__remember_me= remember_me,
                set__updated_at = datetime.now()
            )

            if 'request_form' in data:
                if data['request_form'] in ['model_db','strait']:
                    catalog   = CatalogSchema.objects(created_by=user_id,deleted=False).to_json()
                    catalog   = list(loads(catalog))
                    if len(catalog)==0:
                        return ({'status':'error','message':'userId is invalid'})
                    return validate.user_response(user_obj,user_setting_obj,'login',catalog[0])
                else:
                    return validate.user_response(user_obj,user_setting_obj,'login')
            else:
                return validate.user_response(user_obj,user_setting_obj,'login')
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    def generate_token(self,*args):
        try:
            data        = dict(*args)
            access_token = unquote_plus(data['access_token'],encoding='utf-8')
            # Checking whether there is any space in the given string 
            access_token = access_token.replace(" ","+")
            access_token = base64.b64decode(access_token).decode('utf-8') 
            user_data   = self.user_schema.objects(active_session__match={'access_token': access_token},deleted=False,active=True).to_json()
            user_data   = list(loads(user_data))
            if len(user_data)==0:
                return ({'status':'error','message':'access token is invalid'})
            active_session  = validate.validate_active_session(user_data[0]['active_session'])
            expiry_time     = int(environ.get('EXPIRY_TIME_MIN',None))
            random_length   = int(environ.get('RANDOM_LENGTH',None))
            expiry_time     = datetime.now() + timedelta(minutes = expiry_time)
            session_data    = {
                'access_token' : validate.random_string(random_length), # generate the access token
                'expiry_time': str(expiry_time), # Session expired time
                'ip_address': data['ip_address'],
                'user_agent': data['user_agent']
            }
            active_session.append(session_data)
            # Updating expiry_time into user schema
            user_obj = self.user_schema.objects(active_session__match={'access_token': access_token}).modify(
                new=True,
                set__active_session = active_session,
                set__updated_at = datetime.now()
            )
            #user_id = str(user_obj.id)
            return validate.user_response(user_obj,None,'generate_token')
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    def activation_code(self,*args):
        try:
            data                = dict(*args)
            activation_code     = data['activation_code']
            #activation_code    = unquote_plus(data['activation_code'],encoding='utf-8')
            # Checking whether there is any space in the given string 
            #activation_code    = activation_code.replace(" ","+")
            #activation_code    = base64.b64decode(activation_code).decode('utf-8') 
            user_setting_data   = self.user_setting_schema.objects(activation_code=activation_code).to_json()
            user_setting_data   = list(loads(user_setting_data))
            if len(user_setting_data)==0:
                return ({'status':'error','message':'activation code is invalid'})
            else:
                # Have to work on this have to pass user_id from user_setting to do below operation
                user_id         = user_setting_data[0]['user_id']
                #user_data      = self.user_schema.objects(pk=user_id).to_json()
                user_data       = self.user_schema.objects.get(_id=ObjectId(user_id)).to_json()
                user_data       = loads(user_data)
                active_session  = user_data["active_session"]
                # Session expired time
                expiry_time     = int(environ.get('EXPIRY_TIME_MIN',None))
                random_length   = int(environ.get('RANDOM_LENGTH',None))
                expiry_time     = datetime.now() + timedelta(minutes = expiry_time)
                session_data    = {
                    'access_token': validate.random_string(random_length),
                    'expiry_time': str(expiry_time),
                    'ip_address': data['ip_address'],
                    'user_agent': data['user_agent']
                }
                active_session.append(session_data)
                # Updating expiry_time into user schema
                user_obj = self.user_schema.objects(email=user_data['email']).modify(
                    new=True,
                    set__active= True,
                    set__active_session= active_session,
                    set__updated_at= datetime.now()
                )
                user_id = str(user_obj.id)
                # Updating last_login into user_setting schema
                user_setting_obj = self.user_setting_schema.objects(user_id=user_id).modify(
                    new=True,
                    set__last_login = datetime.now(),
                    set__updated_at = datetime.now()
                )
                return validate.user_response(user_obj,user_setting_obj,'login')
        except Exception as e:
            return ({'status': 'error', 'message': str(e)}) 

    def forgot_password(self,*args):
        try:
            data = dict(*args)
            user_data  = self.user_schema.objects(email=data['email_id'],deleted=False,active=True).to_json()
            user_data  = list(loads(user_data))
            if len(user_data)==0:
                return ({'status':'error','message':'email id is invalid'})
            user_id    = user_data[0]['_id']['$oid']
            mail_from  = environ.get('MAIL_FROM',None)
            reset_code = validate.random_string(10,'alpha_numeric')
            # Updating user_setting schema
            user_setting_obj = self.user_setting_schema.objects(user_id=user_id).modify(
                new=True,
                set__reset_code = reset_code,
                set__updated_at = datetime.now()
            )

            #reset_code = base64.b64encode(reset_code.encode("utf-8"))
            #reset_code = str(reset_code, "utf-8")
            #reset_code = quote_plus(reset_code,safe=" /+",encoding='utf-8')
            host_name  = environ.get('HOST_NAME',None) 
            product_name  = environ.get('PRODUCT_NAME',None)
            html_data = pkgutil.get_data(__package__,path.join("static","forgot-password.html"))
            html_data = html_data.decode("utf-8") 
            email_body = html_data.format(receiver_name=user_data[0]['name'],reset_code=reset_code,host_name=host_name,mail_from=mail_from)
            response   = email.send_email(data['email_id'],str(product_name)+":Reset Password Code",email_body)
            return ({'status':'success','message':'Reset code is send to your register emailId'})
            '''
            if path.exists(file_path):
                email_body = open(file_path).read().format(receiver_name=user_data[0]['name'],reset_code=reset_code,host_name=host_name)
                response   = email.send_email(data['email_id'],"Strait.ai:Reset Password Link",email_body)
                return ({'status':'success','message':'Reset link is send to your register emailId'})
            else:
                return ({'status':'error','message':"File path is invalid"})
            '''
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})    

    def reset_password(self,*args):
        try:
            data = dict(*args)
            if 'user_id' in data:
                user_data   = self.user_schema.objects(id=ObjectId(data['user_id']),deleted=False,active=True).to_json()
                user_data   = list(loads(user_data))
                if len(user_data)==0:
                    return ({'status':'error','message':'userId is invalid'})
                else:
                    secret_key          = environ.get('PASSWORD_SECRET_KEY',None)
                    encrypt_password    = oracle10.hash(secret_key, user=data['password'])
                    random_length       = int(environ.get('RANDOM_LENGTH',None))
                    # Removing Expired Session
                    active_session = validate.validate_active_session(user_data[0]['active_session'])
                    # Session expired time
                    expiry_time    = int(environ.get('EXPIRY_TIME_MIN',None))
                    expiry_time    = datetime.now() + timedelta(minutes = expiry_time)
                    session_data   = {
                        'access_token': validate.random_string(random_length),
                        'expiry_time': str(expiry_time),
                        'ip_address': data['ip_address'],
                        'user_agent': data['user_agent']
                    }
                    active_session.append(session_data)

                    user_obj = self.user_schema.objects(id=ObjectId(data['user_id'])).modify(
                        new=True,
                        set__active_session= active_session,
                        set__password= encrypt_password,
                        set__updated_at = datetime.now()
                    )

                    user_id = str(user_obj.id)
                    # Updating last_login into user_setting schema
                    user_setting_obj = self.user_setting_schema.objects(user_id=user_id).modify(
                        new=True,
                        set__last_login = datetime.now(),
                        set__updated_at = datetime.now()
                    )
                    return validate.user_response(user_obj,user_setting_obj,'reset_password')
            else:
                return ({'status':'error','message':'userId is required'})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    def logout(self,*args):
        try:
            data         = dict(*args)
            access_token = unquote_plus(data['access_token'],encoding='utf-8')
            # Checking whether there is any space in the given string 
            access_token = access_token.replace(" ","+")
            access_token = base64.b64decode(access_token).decode('utf-8') 
            user_data    = self.user_schema.objects(active_session__match={'access_token': access_token},deleted=False,active=True).to_json()
            user_data    = list(loads(user_data))
            if len(user_data)==0:
                return ({'status':'error','message':'access token is invalid'})
            user_id         = user_data[0]['_id']['$oid']
            active_session  = validate.validate_active_session(user_data[0]['active_session'])
            active_session_data = []
            for item in active_session:
                if item['access_token']!=access_token:
                    active_session_data.append(item)
            
            # Updating expiry_time into user schema
            user_obj = self.user_schema.objects(id=user_id).modify(
                new=True,
                set__active_session = active_session_data,
                set__updated_at = datetime.now()
            )

            return ({'status':'success','message':"Logout successfully"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})