import base64, pkgutil
from os import environ,path,getcwd
from json import loads, dumps
from passlib.hash import oracle10
from datetime import datetime, timedelta
import strait.auth.helper.email as email
import strait.auth.helper.validate as validate
from urllib.parse import quote_plus, unquote_plus 
import strait.core.helper.catalog_helper as catalog_helper
from strait.core.model.schema import CatalogSchema
from strait.auth.model.schema import UserSchema,UserSettingSchema

class User:

    def __init__(self,user_id=None, email_id=None):
        if user_id is None: # For Notebook or Custom Recipe
            self.user_id    = environ.get('USER_ID',None) 
        else: # For API    
            self.user_id    = user_id

        if email_id is None: # For Notebook or Custom Recipe
            self.email_id   = environ.get('EMAIL_ID',None) 
        else: # For API   
            self.email_id   = email_id

        self.user_schema            = UserSchema
        self.user_setting_schema    = UserSettingSchema
    
    # Create Users 
    def create_user(self,*args):
        try:
            data            = dict(*args)
            secret_key      = environ.get('PASSWORD_SECRET_KEY',None)
            # encrpty the password
            encrypt_password= oracle10.hash(secret_key, user=data['password'])
            random_length   = int(environ.get('RANDOM_LENGTH',None))
            active_data  = {
                'access_token': validate.random_string(random_length), # generate the access token
                'expiry_time': "", # Session expired time #datetime.now() + timedelta(minutes = expiry_time)
                'ip_address': data['ip_address'],
                'user_agent': data['user_agent']
            }
            active_session  = []
            active_session.append(active_data)
            refresh_token   = validate.random_string(random_length)
            activation_code = validate.random_string(10,'alpha_numeric')
            if data['request_form'] is not None and data['request_form'] in ['model_db','strait']:
                activate_account = True
            else:
                activate_account = False
            userObj = self.user_schema(name=data['name'], email=data['email_id'],active=activate_account,password=encrypt_password,refresh_token=refresh_token,active_session=active_session)
            userObj.save()
            user_id = str(userObj.id)
            userSettingObj = self.user_setting_schema(user_id=user_id,role='basic',activation_code=activation_code)
            userSettingObj.save()
            #activation_code = base64.b64encode(activation_code.encode("utf-8"))
            #activation_code = str(activation_code, "utf-8")
            #activation_code = quote_plus(activation_code,safe=" /+",encoding='utf-8')
            host_name       = environ.get('HOST_NAME',None)
            if data['request_form'] is not None and data['request_form'] in ['model_db','strait']:
                temp        = validate.remove_special_characters(data['email_id'])
                catalog_key = catalog_helper.generate_key(temp['data'])
                catalog_obj = CatalogSchema(name=data['name'],key=catalog_key['key'],created_by=user_id)
                catalog_obj.save()
                return validate.user_response(userObj,userSettingObj,'create_user',catalog_obj)
            else:
                product_name  = environ.get('PRODUCT_NAME',None)
                mail_from  = environ.get('MAIL_FROM',None)
                html_data = pkgutil.get_data(__package__,path.join("static","signup.html"))
                html_data = html_data.decode("utf-8") 
                email_body = html_data.format(receiver_name=data['name'],activation_code=activation_code,host_name=host_name,mail_from=mail_from)
                response   = email.send_email(data['email_id'],str(product_name)+":Activation Link",email_body)
                return validate.user_response(userObj,userSettingObj,'create_user')
                '''            
                file_path = path.join("strait","auth","static","signup.html")
                if path.exists(file_path):
                    email_body = open(file_path).read().format(receiver_name=data['name'],activation_code=activation_code,host_name=host_name)
                    response   = email.send_email(data['email_id'],"Strait.ai:Activation Link",email_body)
                    return validate.user_response(userObj,userSettingObj,'create_user')
                else:
                    return ({'status':'error','message':"File path is invalid"})
                '''
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
