from datetime import timedelta
import airflow
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
import pandas as pd 
import os 
import csv
from subprocess import Popen
from flask import Flask,jsonify
app = Flask(__name__)
import requests 
import json 
import pymongo
from pymongo import MongoClient
from datetime import datetime  #, timedeltas
from pprint import pprint
import api
#import loader
#import summarizer
import tasks 
from airflow.models import  TaskInstance
                            

default_args = {
    'owner': 'airflow2',
    'depends_on_past': False,
    'start_date': airflow.utils.dates.days_ago(2),
    #'start_date': datetime(2019, 2, 4),
    #'start_date': datetime(2016, 3, 29, 8, 15),
    'email': ['naveenkumars@gain-insights.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
    # 'wait_for_downstream': False,
    # 'dag': dag,
    # 'adhoc':False,
    # 'sla': timedelta(hours=2),
     'execution_timeout': timedelta(seconds=300),
    # 'on_failure_callback': some_function,
    # 'on_success_callback': some_other_function,
    # 'on_retry_callback': another_function,
    # 'trigger_rule': u'all_success'
}

dag = DAG(
    'DAG',
    default_args=default_args,
    description='A Base airflow DAG',
    #catchup=False,
    #schedule_interval="@daily",
    schedule_interval=timedelta(days=1),
    #schedule_interval="49 03 * * *",
    #dagrun_timeout=timedelta(minutes=1))
)
dag_name = dag.dag_id
# print("--->",dag_name)
# print(dag.dag_id)




def dag_name_fetch():
    dag_name = "DAG"
    return dag_name

    
#----------------------------- D B   C O N N E C T I VI T Y-----------------------------------------------------------------------------------------
   
try:
    client = MongoClient("mongodb://airflow_mongodb:27017/DAG")
    #client = MongoClient("mongo")
    #db = client.DAG
    collection = client["dags"] 
    #print("db connected successfully ")
except:   
    print("Could not connect to MongoDB")

#------------------------------T A S K S   D E P E N D E N C I E S----------------------------------------------------------------------------------------




t1 = PythonOperator(
    task_id='upload_dataset',
    provide_context=True,
    python_callable=tasks.dags().upload_dataset,
    op_kwargs={'filename': 'dataset.csv'},
    dag = dag
    )
 

t2 = PythonOperator(
    task_id='summarize_dataset',
    provide_context=True,
    python_callable=tasks.dags().summarize_dataset,
    dag=dag
    )   


t3 = PythonOperator(
    task_id='store_dataset_details',
    provide_context=True,
    python_callable=tasks.dags().store_dataset_details,
    dag=dag
    )


t1 >> t2 >>t3




