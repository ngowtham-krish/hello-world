
from datetime import timedelta
import airflow
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
import pandas as pd 
import os 
import csv
from subprocess import Popen
from flask import Flask,jsonify
app = Flask(__name__)
import requests 
import json 
import pymongo
from pymongo import MongoClient
from datetime import datetime  #, timedeltas
from pprint import pprint
#import api
#import loader
#import summarizer
from airflow.models import  TaskInstance

'''
try:
    client = MongoClient("mongodb://localhost:27017/")    
    db = client.DAG
    collection = db["dags"] 
except:   
    print("Could not connect to MongoDB")
'''
class dags():

    def __init__(self,):
        return None


    #   T H E   F I L E   I S   U P L O A D E D
    def upload_dataset(self ,**kwargs):
        filename = kwargs['filename']
        dataset_file = None
        if filename != None:
            try:
                    dataset_file = filename
            except :
                print("could not be loaded")
        else:
            return ("file name not found")
        return dataset_file    

    
    
    #   T H E   D A T A S E T    I S    S U M M A R I Z E D 
    def summarize_dataset(self ,**context):
        try:
            dataset_file = context['task_instance'].xcom_pull(task_ids='upload_dataset')
            #no_of_rows = summarizer.rows(dataset_file) 
            #no_of_columns = summarizer.columns(dataset_file)

            with open(dataset_file, 'r') as file:
                reader = csv.reader(file)
                row_count = 0
                for row in reader:
                    row_count+=1
                    print(row)
            no_of_rows = row


            d = '\t'
            f=open(dataset_file,'r')
            reader=csv.reader(f,delimiter=d)
            ncol=next(reader) # Read first line and count columns
            column_names = ncol[0].split(",")
            print("no_of_colums :",len(column_names))
            no_of_columns = len(column_names)


        #      S T O R E D    I N    A   C O L L E C T I O N 
            dag_details = { 
            "dag_id":dag_name,
            "no_of_rows" : no_of_rows ,
            "no_of_columns": no_of_columns
            } 
            print("the value is : ",dag_details)    
            return dag_details

        except :
            print("Dataset file could not be found!")
            dag_details = None
            return dag_details
                



    #   S T O R E D    I N    D B 
    def store_dataset_details(self ,**context):
            #store_item  = context['task_instance'].xcom_pull(task_ids='summarize_dataset')  
            #print("store_item :",store_item)
            #rec_id1 = collection.insert_one()
            myclient = pymongo.MongoClient("mongodb://airflow_mongodb:27017/DAG")
            #mydb = myclient["DAG"]
            mycol = myclient["DAG"]

            mydict = { "name": "John", "address": "Highway 37" }

            x = mycol.insert_one(mydict)
            print("dag_details inserted successfully",x)
            return "inserted successfully"


