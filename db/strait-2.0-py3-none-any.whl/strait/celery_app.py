from celery import Celery
from os import environ

celery_app = Celery('tasks', broker=environ.get("BROKER_URL"))

# if __name__ == '__main__':
#     celery_app.start()