from bson import ObjectId
from datetime import datetime
from json import loads, dumps
from os import environ, path, remove
from base64 import b64encode, b64decode
from simplecrypt import encrypt, decrypt
import strait.nifi.database_connector as database_connector
from strait.nifi.model.schema import DatabaseConnectorSchema
#from strait.environment import load_env
 
# Initializing Environment
#load_env()

class Connector:

    def __init__(self, **kwargs):
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        
        self.connector_schema = DatabaseConnectorSchema
    
    # Fetching connection lists
    def get_connection_lists(self,**kwargs):
        try:
            print("---- Inside get_connection_lists methods ------")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                connector_lists = self.connector_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json() 
                connector_lists = list(loads(connector_lists))
                connection_details = []
                for item in connector_lists:
                    temp = {
                        "connectorId" : str(item['_id']['$oid']),
                        "catalogKey": item['catalog_key'],
                        "projectKey": item['project_key'], 
                        "connectionUrl": item['connection_url'],
                        "userName": item['user_name'],
                        "portNo": item['port_no'],
                        "tableLists":item['table_lists'],
                        "deleted":item['deleted'],
                        "updatedAt":datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S')
                    }   
                    connection_details.append(temp)
                return ({'status':'success','connection_details':connection_details})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)}) 

    # Fetch details
    def fetch_table_data(self,**kwargs):
        try:
            print("---- Inside get_connection_lists methods ------")
            if self.catalog_key is None or self.project_key is None and kwargs['connectorId'] is not None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                connector_lists = self.connector_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, id=ObjectId(kwargs['connectorId']), deleted=False).to_json() 
                connector_lists = list(loads(connector_lists))
                print("--- connector_lists ----")
                print(connector_lists)
                if len(connector_lists)>0:
                    my_secret_password = environ.get('SESSION_SECRET_KEY',None)
                    connector_lists = connector_lists[0]
                    connection_url = connector_lists['connection_url']
                    user_name   = connector_lists['user_name']
                    port_no     = connector_lists['port_no']
                    password    = connector_lists['password']
                    password    = b64decode(password)
                    password    = decrypt(my_secret_password, password)
                    password    = password.decode('utf8')
                    print("---- password -----")
                    print(password)
                    database_type = connector_lists['database_type']
                    database_name = connector_lists['database_name']
                    table_lists = connector_lists['table_lists']

                    connector_obj = database_connector.DatabaseConnector(catalog_key=self.catalog_key, project_key=self.project_key)
                    connector_resp = connector_obj.save_table_data(database_type=database_type,
                                                 connection_url= connection_url,
                                                 port_no= port_no,
                                                 user_name= user_name,
                                                 password = password,
                                                 database_name = database_name,
                                                 table_lists= table_lists,
                                                 avro_to=environ.get('NIFI_MERGE_RECORDS',None),
                                                 database_processor="query_database_table",
                                                 ret_file_path="yes")
                    return connector_resp
                else:
                    return ({'status':'error','message':'connector id is invalid'})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)}) 

