from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class DatabaseConnectorSchema(Document):
    catalog_key     = StringField()
    project_key     = StringField()
    database_type   = StringField(max_length=200, required=True)
    connection_url  = StringField(max_length=200)
    user_name       = StringField(max_length=200)
    password        = StringField(max_length=500)
    port_no         = StringField(max_length=20)
    database_name   = StringField(max_length=200)
    table_lists     = ListField()
    table_info   = ListField()
    created_at   = DateTimeField(default=datetime.now())
    updated_at   = DateTimeField(default=datetime.now())
    created_by   = StringField()
    updated_by   = StringField()
    owners       = ListField()
    deleted      = BooleanField(default= False)
    meta = {'collection': 'database-connector'}




