from strait.nifi.model.schema.database_connector_schema import DatabaseConnectorSchema

__all__ = ["DatabaseConnectorSchema"]
