#import nipyapi
import requests
from os import environ
from flask import session
from json import loads, dumps
import strait.nifi.helper.process_group_helper as process_group_helper
#from strait.environment import load_env
 
# Initializing Environment
#load_env()

class ProcessGroup:

    def __init__(self, **kwargs):
        self.catalog_key = None
        self.project_key = None
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        
        if 'parent_group_id' in kwargs and kwargs['parent_group_id'] is not None:
            self.parent_group_id = kwargs['parent_group_id']
        '''
        else:
            self.parent_group_id = nipyapi.canvas.get_root_pg_id()
        '''
        self.base_url = environ.get('NIFI_URL',None)
        self.headers = {'content-type': 'application/json'}
    
    # For creating process group
    def create(self,**kwargs):
        try:
            print("---- Inside create process group methods ------")
            if self.catalog_key is None or self.project_key is None or self.parent_group_id is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None:
                    return ({'status':'error','message':'process group name is required'})
                else:
                    if 'group_name' in kwargs and kwargs['group_name'] is not None:
                        group_name = kwargs['group_name']
                    else:
                        group_name = kwargs['process_group_name'].replace("_"," ")
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    clientId = process_group_helper.random_string(8)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(12)
                    url = self.base_url+'/process-groups/'+str(self.parent_group_id)+'/process-groups'
                    print("--- URL ---")
                    print(url)
                    data = {
                                "revision": { "clientId": clientId,"version": 0},
                                "disconnectedNodeAcknowledged": False,
                                "component": {
                                    "name":  group_name,
                                    "position": {"x": 370.94653524075363, "y": 98.72120786996959} # Random position to be set
                                }
                    }
                    print("--- data ---")
                    print(data)
                    resp = requests.post(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"

                    session[process_group_key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        'flow':{}
                    }
                    return ({'status':'success','data':session[process_group_key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # For fetching process group details
    def fetch(self,**kwargs):
        try:
            print("---- Inside fetch process group methods ------")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None:
                    return ({'status':'error','message':'process group name is required'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                    
                    url = self.base_url+'/flow/process-groups/'+str(session[key]['id'])
                    print("--- URL ---")
                    print(url)
                    resp = requests.get(url, headers=self.headers)
                    resp = resp.json()
                    
                    session[key]['flow'] = resp['processGroupFlow']['flow']
                    return ({'status':'success','data':session[key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # For deleting process group
    def delete(self,**kwargs):
        try:
            print("---- Inside delete process group methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None:
                    return ({'status':'error','message':'process group name is required'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                    
                    process_group_data = session[key]
                    url = self.base_url+'/process-groups/'+str(process_group_data['id'])+"?version="+str(process_group_data['revision']['version'])+"&disconnectedNodeAcknowledged=false&clientId="+str(process_group_data['revision']['clientId'])
                    print("URL "+str(url))
                    resp = requests.delete(url, headers=self.headers)
                    resp = resp.json()
                    #print(resp)
                    session.pop(key,None)
                    return ({'status':'success','message':"Porcess group deleted successfully"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # For enabling/disabling process group
    def run_status(self,**kwargs):
        try:
            print("---- Inside run_status process group methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None:
                    return ({'status':'error','message':'process group name is required'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing process group key
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                    
                    process_group_data = session[process_group_key]
                    
                    run_status = 'STOPPED'
                    if 'run_status' in kwargs and kwargs['run_status'] in ['start']:
                        run_status = 'RUNNING'
                    elif 'run_status' in kwargs and kwargs['run_status'] in ['stop']:
                        run_status = 'STOPPED'
                        
                    url = self.base_url+'/flow/process-groups/'+str(process_group_data['id'])
                    print("URL "+str(url))
                    data = {
                        "id": process_group_data['id'],
                        "state": run_status,
                        "disconnectedNodeAcknowledged": False
                    }
                    print(dumps(data))
                    resp = requests.put(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    #print(resp)
                    return ({'status':'success','message':"Process group is "+str(kwargs['run_status'].lower())})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})