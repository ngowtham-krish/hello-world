#import nipyapi
import requests, time
from os import environ
from flask import session
from json import loads, dumps
import strait.nifi.helper.process_group_helper as process_group_helper
#from strait.environment import load_env

# Initializing Environment
#load_env()

class Connection:

    def __init__(self, **kwargs):
        self.catalog_key = None
        self.project_key = None
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        
        '''
        if 'parent_group_id' in kwargs and kwargs['parent_group_id'] is not None:
            self.parent_group_id = kwargs['parent_group_id']
        else:
            self.parent_group_id = nipyapi.canvas.get_root_pg_id()
        '''
        
        self.base_url = environ.get('NIFI_URL',None)
        self.headers = {'content-type': 'application/json'}

    def create(self,**kwargs):
        try:
            print("---- Inside create connection methods ----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'source_processor_name' not in kwargs or kwargs['source_processor_name'] is None or 'destination_processor_name' not in kwargs or kwargs['destination_processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['source_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['destination_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    clientId = process_group_helper.random_string(8)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(12)
                    
                    # Preparing process group key
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                    
                    # Preparing source processor key
                    if 'source_processor_key' in kwargs and kwargs['source_processor_key'] is not None: # Generating Random Key
                        source_processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        source_processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_name'])+"_data"
                    
                    # Preparing source processor key
                    if 'destination_processor_key' in kwargs and kwargs['destination_processor_key'] is not None: # Generating Random Key
                        destination_processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['destination_processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        destination_processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    
                    # Preparing connection key
                    if 'source_processor_key' in kwargs and kwargs['source_processor_key'] is not None and 'destination_processor_key' in kwargs and kwargs['destination_processor_key'] is not None: # Generating Random Key
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+'_connection_'+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_key'])+"_"+str(kwargs['destination_processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    
                    #source_processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+kwargs['process_group_name']+"_"+str(kwargs['source_processor_name'])+"_data"
                    #destination_processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    #connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    
                    # Prepaing the URL for creation of connection 
                    url = self.base_url+'/process-groups/'+str(session[process_group_key]['id'])+'/connections'
                    print(url)
                    
                    # Preparing data for creation of connection            
                    data = {
                        "revision": { "clientId": clientId,"version": 0},
                        "disconnectedNodeAcknowledged": False,
                        "component":{
                            "name": "",
                            "source":{
                                "id": session[source_processor_key]['id'],
                                "groupId": session[process_group_key]['id'],
                                "type": "PROCESSOR"
                            },
                            "destination":{
                                "id": session[destination_processor_key]['id'],
                                "groupId": session[process_group_key]['id'],
                                "type": "PROCESSOR"
                            },
                            "selectedRelationships": [kwargs['relationship']],
                            "flowFileExpiration": "0 sec",
                            "backPressureDataSizeThreshold": "15 GB",
                            "backPressureObjectThreshold": "1000000",
                            "bends": [],
                            "prioritizers": [],
                            "loadBalanceStrategy": "DO_NOT_LOAD_BALANCE",
                            "loadBalancePartitionAttribute": "",
                            "loadBalanceCompression": "DO_NOT_COMPRESS"
                        }        
                    }

                    print("--- create connection data ----")
                    print(dumps(data))

                    # Calling NiFi API
                    resp = requests.post(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    
                    # Preparing response
                    session[connection_key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component']
                    }
                    return ({'status':'success','data':session[connection_key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    def delete(self,**kwargs):
        try:
            print("--- Inside delete connection methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'source_processor_name' not in kwargs or kwargs['source_processor_name'] is None or 'destination_processor_name' not in kwargs or kwargs['destination_processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['source_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['destination_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    #connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+kwargs['process_group_name']+"_"+kwargs['source_processor_name']+"_"+kwargs['destination_processor_name']+"_data"
                    # Preparing connection key
                    if 'source_processor_key' in kwargs and kwargs['source_processor_key'] is not None and 'destination_processor_key' in kwargs and kwargs['destination_processor_key'] is not None: # Generating Random Key
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+'_connection_'+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_key'])+"_"+str(kwargs['destination_processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    
                    # Prepaing the URL for creation of connection 
                    url = self.base_url+'/connections/'+str(session[connection_key]['id'])+'?version='+str(session[connection_key]['revision']['version'])+"&clientId="+str(session[connection_key]['revision']['clientId'])+"&disconnectedNodeAcknowledged=false"
                    print(url)
                    
                    # Calling NiFi API
                    resp = requests.delete(url, headers=self.headers)
                    resp = resp.json()

                    session.pop(connection_key,None)
                    return ({'status':'success','message':"Connection deleted successfully"})    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    def clear_queue(self,**kwargs):
        try:
            print("--- Inside clear queue connection methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'source_processor_name' not in kwargs or kwargs['source_processor_name'] is None or 'destination_processor_name' not in kwargs or kwargs['destination_processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['source_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['destination_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing connection key
                    if 'source_processor_key' in kwargs and kwargs['source_processor_key'] is not None and 'destination_processor_key' in kwargs and kwargs['destination_processor_key'] is not None: # Generating Random Key
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+'_connection_'+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_key'])+"_"+str(kwargs['destination_processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    #connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+kwargs['process_group_name']+"_"+kwargs['source_processor_name']+"_"+kwargs['destination_processor_name']+"_data"
                    
                    # Prepaing the URL for creation of connection 
                    drop_requests_url = self.base_url+'/flowfile-queues/'+str(session[connection_key]['id'])+"/drop-requests"
                    print(drop_requests_url)
                    
                    # Calling NiFi API
                    resp = requests.post(drop_requests_url, headers=self.headers)
                    resp = resp.json()

                    # Delaying for 3 seconds to know whether connection is empty or not
                    time.sleep(3)

                    print("---- Checking whether queue has some item or not -----")
                    # Prepaing the URL for Listing the queue
                    listing_requests_url = self.base_url+'/flowfile-queues/'+str(session[connection_key]['id'])+"/listing-requests"
                    print(listing_requests_url)
                    while True:
                        # Calling NiFi API
                        resp = requests.post(listing_requests_url, headers=self.headers)
                        resp = resp.json()
                        if len(resp)>0:
                            if 'listingRequest' in resp:
                                listing_request = resp['listingRequest']
                                if 'queueSize' in listing_request:
                                    if 'byteCount' in listing_request['queueSize'] and 'objectCount' in listing_request['queueSize']:
                                        print("byteCount "+str(listing_request['queueSize']['byteCount'])+" objectCount "+str(listing_request['queueSize']['objectCount']))
                                        if int(listing_request['queueSize']['byteCount'])!=0 or int(listing_request['queueSize']['objectCount'])!=0:
                                            print("---- Inside if calling drop requests ----")
                                            resp = requests.post(drop_requests_url, headers=self.headers)
                                            resp = resp.json()
                                        else:
                                            break
                                    '''
                                    else:
                                        break
                                else:
                                    break
                            else:
                                break
                        else:
                            break
                        '''

                    print("---- resp of clear queue -----")
                    print(resp)
                    return ({'status':'success','message':"Queue cleared successfully"})   
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    def list_queue(self, **kwargs):
        try:
            print("--- Inside list_queue connection methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'source_processor_name' not in kwargs or kwargs['source_processor_name'] is None or 'destination_processor_name' not in kwargs or kwargs['destination_processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['source_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['destination_processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing connection key
                    if 'source_processor_key' in kwargs and kwargs['source_processor_key'] is not None and 'destination_processor_key' in kwargs and kwargs['destination_processor_key'] is not None: # Generating Random Key
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+'_connection_'+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_key'])+"_"+str(kwargs['destination_processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+str(kwargs['process_group_name'])+"_"+str(kwargs['source_processor_name'])+"_"+str(kwargs['destination_processor_name'])+"_data"
                    #connection_key = str(self.catalog_key)+"_"+str(self.project_key)+"_connection_"+kwargs['process_group_name']+"_"+kwargs['source_processor_name']+"_"+kwargs['destination_processor_name']+"_data"
                    
                    # Prepaing the URL for creation of listing queue requests 
                    url = self.base_url+'/flowfile-queues/'+str(session[connection_key]['id'])+"/listing-requests"
                    print("1st URL")
                    print(url)

                    # Calling NiFi API
                    resp = requests.post(url, headers=self.headers)
                    resp = resp.json()
                    
                    if len(resp)>0:
                        print("Inside first resp")
                        if 'listingRequest' in resp:
                            listing_request = resp['listingRequest']
                            print("---- listing_request first ----")
                            print(listing_request)
                            if 'queueSize' in listing_request:
                                if 'byteCount' in listing_request['queueSize'] and 'objectCount' in listing_request['queueSize']:
                                    print("---- listing_request queueSize ----")
                                    print(listing_request['queueSize']['byteCount'])
                                    print("---- listing_request objectCount ----")
                                    print(listing_request['queueSize']['objectCount'])
                                    if int(listing_request['queueSize']['byteCount'])!=0 and int(listing_request['queueSize']['objectCount'])!=0:
                                        print("Inside if of byteCount & objectCount")
                                        listing_request_id = listing_request['id']
                                        # Prepaing the URL for creation of listing queue requests 
                                        url = self.base_url+'/flowfile-queues/'+str(session[connection_key]['id'])+"/listing-requests/"+str(listing_request_id)
                                        print("2nd URL")
                                        print(url)
                                        # Calling NiFi API
                                        resp = requests.get(url, headers=self.headers)
                                        resp = resp.json()
                                        if len(resp)>0:
                                            print("Inside second resp")
                                            if 'listingRequest' in resp:
                                                listing_request = resp['listingRequest']
                                                if 'flowFileSummaries' in listing_request:
                                                    if len(listing_request['flowFileSummaries'])>0:
                                                        return ({'status':'success','flow_files':listing_request['flowFileSummaries']})
                                                    else:
                                                        return ({'status':'error','message':'The queue has no FlowFiles'})
                                                else:
                                                    return ({'status':'error','message':'The queue has no FlowFiles'})
                                            else:
                                                return ({'status':'error','message':'The queue has no FlowFiles'})
                                        else:
                                            return ({'status':'error','message':'The queue has no FlowFiles'})
                                    else:
                                        print("Else The queue has no FlowFiles")
                                        return ({'status':'error','message':'The queue has no FlowFiles'})
                                else:
                                    return ({'status':'error','message':'The queue has no FlowFiles'})
                            else:
                                return ({'status':'error','message':'The queue has no FlowFiles'})
                        else:
                            return ({'status':'error','message':'The queue has no FlowFiles'})
                    else:
                        return ({'status':'error','message':'The queue has no FlowFiles'})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})