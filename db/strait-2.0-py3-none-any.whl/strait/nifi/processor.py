import nipyapi, requests, time
from datetime import datetime, timedelta
import random, string
from os import environ
from flask import session
from json import loads, dumps
import strait.nifi.helper.process_group_helper as process_group_helper
#from strait.environment import load_env

# Initializing Environment
#load_env()

class Processor:

    def __init__(self, **kwargs):
        self.catalog_key = None
        self.project_key = None
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        
        '''
        if 'parent_group_id' in kwargs and kwargs['parent_group_id'] is not None:
            self.parent_group_id = kwargs['parent_group_id']
        else:
            self.parent_group_id = nipyapi.canvas.get_root_pg_id()
        '''
        
        self.base_url = environ.get('NIFI_URL',None)
        self.headers = {'content-type': 'application/json'}
    
    # For creating processor
    def create(self,**kwargs):
        try:
            print("---- Create processor methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    clientId = process_group_helper.random_string(8)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(12)
                    
                    # Preparing process group key
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                        
                    # Prepaing the URL for creation of processor 
                    print("--- URL ----")
                    url = self.base_url+'/process-groups/'+str(session[process_group_key]['id'])+'/processors'
                    print(url)
                    
                    if 'processor_name' in kwargs and kwargs['processor_name'] is not None:
                        # Preparing processor key
                        if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                            processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                        else: # Generating Key Based on Group Name
                            processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                        
                        # Preparing data for respective processor name
                        if kwargs['processor_name'] in ['execute_sql']: # For Executing SQL
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.standard.ExecuteSQL",
                                                                      component_name="ExecuteSQL",
                                                                      component_bundle_artifact="nifi-standard-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=100,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['query_database_table']: # For querying database table
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.standard.QueryDatabaseTable",
                                                                      component_name="QueryDatabaseTable",
                                                                      component_bundle_artifact="nifi-standard-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=100,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['convert_avro_to_json']: # For Conversion from AVRO to JSON
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.avro.ConvertAvroToJSON",
                                                                      component_name="ConvertAvroToJSON",
                                                                      component_bundle_artifact="nifi-avro-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=320,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['convert_avro_to_parquet']: # For Conversion from AVRO to Parquet 
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.parquet.ConvertAvroToParquet",
                                                                      component_name="ConvertAvroToParquet",
                                                                      component_bundle_artifact="nifi-parquet-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=320,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['merge_records']:
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.standard.MergeRecord",
                                                                      component_name="MergeRecord",
                                                                      component_bundle_artifact="nifi-standard-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=320,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['update_attribute']: # Updating Attribute Processor
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.attributes.UpdateAttribute",
                                                                      component_name="UpdateAttribute",
                                                                      component_bundle_artifact="nifi-update-attribute-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=520,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['put_file']: # Put File Processor
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.standard.PutFile",
                                                                      component_name="PutFile",
                                                                      component_bundle_artifact="nifi-standard-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=720,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        elif kwargs['processor_name'] in ['get_file']: # Get File Processor
                            resp = process_group_helper.prepare_processor_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.processors.standard.GetFile",
                                                                      component_name="GetFile",
                                                                      component_bundle_artifact="nifi-standard-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      component_position_x=368,
                                                                      component_position_y=420,
                                                                      request_from="create")
                            if resp['status'] in ['error']:
                                return resp
                            data = resp['data']
                        
                        print("---- data ---")
                        print(dumps(data))
                    
                    # Calling NiFi API
                    resp = requests.post(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    
                    # Preparing response
                    session[processor_key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component'],
                        "bulletins": resp['bulletins']
                    }
                    return ({'status':'success','data':session[processor_key]})
            
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # For updating processor
    def update(self,**kwargs):
        try:
            print("---- Inside update processor methods ----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response

                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    
                    if response['status'] in ['error']:
                        return response
                    
                    if kwargs['processor_name'] in ['execute_sql','query_database_table']:
                        if 'controller_service_name' not in kwargs and kwargs['controller_service_name'] is None:
                            return ({'status':'error','message':'controller service name is required'})
                        else:
                            # Validating controller service name is valid or not
                            response = process_group_helper.validate_name(request_for='controller_service', controller_service_name=kwargs['controller_service_name'])
                            if response['status'] in ['error']:
                                return response
                            
                            # Preparing controller service key
                            if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None: # Generating Random Key
                                controller_service_key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_key'])+"_data"
                            else: # Generating Key Based on Group Name
                                controller_service_key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_name'])+"_"+"data"
                            
                    # Preparing processor key
                    if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                    
                    # Preparing URL
                    print("--- URL ----")
                    url = self.base_url+'/processors/'+str(session[processor_key]['id'])
                    print(url)
                    
                    if 'scheduling_period' in kwargs and kwargs['scheduling_period'] is not None:
                        scheduling_period = kwargs['scheduling_period']
                    else: # Default
                        scheduling_period = "1 sec"
                    
                    if 'relationships' in kwargs and kwargs['relationships'] is not None:
                        relationships = kwargs['relationships']
                    else: # Default
                        if 'processor_name' in kwargs and kwargs['processor_name'] in ['get_file']:
                            relationships = ["success"]
                        elif 'processor_name' in kwargs and kwargs['processor_name'] in ['query_database_table']:
                            relationships = None
                        else:
                            relationships = ["failure", "success"]

                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['execute_sql','query_database_table']:
                        if 'skip_database_validation' in kwargs and kwargs['skip_database_validation'] is not None and kwargs['skip_database_validation'].lower() in ['yes']:
                            running_state = "STOPPED"
                        else:
                            running_state = "RUNNING"

                    print("---- kwargs['process_group_name'] ----"+str(kwargs['process_group_name']))
                    print("---- kwargs['processor_name'] ----"+str(kwargs['processor_name']))
                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['execute_sql']: # For Executing SQL
                        if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_database_name_from_mysql','fetch_database_name_from_postgres','fetch_database_name_from_sqlite']:
                            sql_pre_query = None
                            if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_database_name_from_mysql']:
                                sql_select_query = "show databases"
                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_database_name_from_postgres']:
                                sql_select_query = "select datname from pg_database"
                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_database_name_from_sqlite']:
                                sql_select_query = None
                        
                        elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_lists_from_mysql','fetch_table_lists_from_postgres','fetch_table_lists_from_sqlite']:
                            # Initializing mysql database name
                            if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_lists_from_mysql']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_lists']:
                                    sql_pre_query    = "use "+ str(kwargs['database_name'])
                                    sql_select_query = "show tables"

                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_lists_from_postgres']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_lists']:
                                    sql_select_query = "select * from pg_catalog.pg_tables where schemaname != 'pg_catalog' and schemaname != 'information_schema'"
                                    sql_pre_query = None

                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_lists_from_sqlite']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_lists']:
                                    sql_select_query = "select name from sqlite_master where type ='table' and name not like 'sqlite_%'"
                                    sql_pre_query = None

                        elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_row_count_from_mysql','fetch_table_row_count_from_postgres','fetch_table_row_count_from_sqlite']:
                            # Initializing mysql database name
                            if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_row_count_from_mysql']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_row_count']:
                                    sql_pre_query    = "use "+ str(kwargs['database_name'])
                                    sql_select_query = "select count(*) as count from `"+str(kwargs['table_name'])+"`"

                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_row_count_from_postgres']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_row_count']:
                                    sql_pre_query = None
                                    sql_select_query = "select count(*) as count from public."+str(kwargs['table_name'])

                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_row_count_from_sqlite']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_row_count']:
                                    pass

                        elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_schema_from_mysql','fetch_table_schema_from_postgres','fetch_table_schema_from_sqlite']:
                            if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_schema_from_mysql']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_schema']:
                                    sql_pre_query    = "use "+ str(kwargs['database_name'])
                                    sql_select_query = "desc `" + str(kwargs['table_name']) + "`"
                            
                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_schema_from_postgres']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_schema']:
                                    sql_select_query = "select column_name, data_type, character_maximum_length, is_nullable from INFORMATION_SCHEMA.COLUMNS where table_name = '" + str(kwargs['table_name']) +"'"
                                    sql_pre_query = None

                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_schema_from_sqlite']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_schema']:
                                    sql_select_query = "select sql from sqlite_master where name = '" + str(kwargs['table_name']) +"'"
                                    sql_pre_query = None

                        elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_mysql','fetch_table_details_from_postgres','fetch_table_details_from_sqlite']:
                            # Initializing mysql database name
                            if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_mysql']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_data']:
                                    sql_pre_query    = "use "+ str(kwargs['database_name'])
                                    if 'query' in kwargs and kwargs['query'] is not None:
                                        sql_select_query = kwargs['query']
                                    else:
                                        sql_select_query = "select * from `"+ str(kwargs['table_name'])+"`"
                                
                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_postgres']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_data']:
                                    sql_pre_query = None
                                    if 'query' in kwargs and kwargs['query'] is not None:
                                        sql_select_query = kwargs['query']
                                    else:
                                        sql_select_query = "select * from "+ str(kwargs['table_name'])

                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_sqlite']:
                                if 'query_type' in kwargs and kwargs['query_type'] in ['fetching_table_data']:
                                    sql_select_query = "select * from "+ str(kwargs['table_name'])
                                    sql_pre_query = None
                                                  
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                    revision_version=int(session[processor_key]['revision']['version']),
                                                                    disconnected_node_acknowledged=False,
                                                                    component_id=str(session[processor_key]['id']),
                                                                    component_name=str(session[processor_key]['status']['name']),
                                                                    component_config_concurrently_schedulable_task_count="1",
                                                                    component_config_scheduling_period=scheduling_period,
                                                                    component_config_execution_node="ALL",
                                                                    component_config_penalty_duration="30 sec",
                                                                    component_config_yield_duration="1 sec",
                                                                    component_config_bulletin_level="WARN",
                                                                    component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                    component_config_comments="",
                                                                    component_config_auto_terminated_relationships=relationships,
                                                                    database_connection_pooling_service=str(session[controller_service_key]['id']),
                                                                    sql_pre_query=sql_pre_query,
                                                                    sql_select_query=sql_select_query,
                                                                    component_state= running_state, #"STOPPED",#"RUNNING",
                                                                    component_config_esql_max_rows= environ.get('NIFI_MAX_ROWS_PER_FLOW_FILE', None),
                                                                    component_config_esql_output_batch_size= environ.get('NIFI_OUTPUT_BATCH_SIZE', None),
                                                                    component_config_esql_fetch_size= environ.get('NIFI_FETCH_SIZE', None),
                                                                    request_from="update",
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['query_database_table']: # For query database SQL
                        print("--- query_database_table ---")
                        if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_mysql','fetch_table_details_from_postgres','fetch_table_details_from_sqlite']:
                            if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_mysql']:
                                table_name = str(kwargs['database_name'])+"."+str(kwargs['table_name'])
                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_postgres']:
                                print("--- fetch_table_details_from_postgres ---")
                                table_name = str(kwargs['table_name'])
                            elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_sqlite']:
                                table_name = str(kwargs['table_name'])

                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                revision_version=int(session[processor_key]['revision']['version']),
                                                                disconnected_node_acknowledged=False,
                                                                component_id=str(session[processor_key]['id']),
                                                                component_name=str(session[processor_key]['status']['name']),
                                                                component_config_scheduling_period=scheduling_period,
                                                                component_config_execution_node="PRIMARY",
                                                                component_config_penalty_duration="30 sec",
                                                                component_config_yield_duration="1 sec",
                                                                component_config_bulletin_level="WARN",
                                                                component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                component_config_comments="",
                                                                component_config_auto_terminated_relationships=relationships,
                                                                database_connection_pooling_service=str(session[controller_service_key]['id']),
                                                                component_config_properties_table_name = table_name,
                                                                component_config_properties_fetch_size = environ.get('NIFI_FETCH_SIZE', None),
                                                                component_config_properties_qdbt_max_rows = environ.get('NIFI_MAX_ROWS_PER_FLOW_FILE', None),
                                                                component_config_properties_qdbt_output_batch_size = environ.get('NIFI_OUTPUT_BATCH_SIZE', None),
                                                                component_state=running_state,#"RUNNING",
                                                                request_from="update",
                                                                process_group_name=kwargs['process_group_name'],
                                                                processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                        
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['convert_avro_to_json']: # For Conversion from AVRO to JSON
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                      revision_version=int(session[processor_key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=str(session[processor_key]['id']),
                                                                      component_name=str(session[processor_key]['status']['name']),
                                                                      component_config_concurrently_schedulable_task_count="1",
                                                                      component_config_scheduling_period=scheduling_period,
                                                                      component_config_execution_node="ALL",
                                                                      component_config_penalty_duration="30 sec",
                                                                      component_config_yield_duration="1 sec",
                                                                      component_config_bulletin_level="WARN",
                                                                      component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                      component_config_comments="",
                                                                      component_config_run_duration_millis=0,
                                                                      component_config_auto_terminated_relationships=relationships,
                                                                      component_state="STOPPED",
                                                                      request_from="update",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['convert_avro_to_parquet']: # For Conversion from AVRO to Parquet
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                      revision_version=int(session[processor_key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=str(session[processor_key]['id']),
                                                                      component_name=str(session[processor_key]['status']['name']),
                                                                      component_config_concurrently_schedulable_task_count="1",
                                                                      component_config_scheduling_period=scheduling_period,
                                                                      component_config_execution_node="ALL",
                                                                      component_config_penalty_duration="30 sec",
                                                                      component_config_yield_duration="1 sec",
                                                                      component_config_bulletin_level="WARN",
                                                                      component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                      component_config_comments="",
                                                                      component_config_auto_terminated_relationships=relationships,
                                                                      component_state="STOPPED",
                                                                      request_from="update",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['merge_records']:
                        print("--- Inside update merge_records ----")
                        if 'record_reader' in kwargs and kwargs['record_reader'] is not None:
                            record_reader = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['record_reader'])+"_data"
                            record_reader_id = str(session[record_reader]['id'])

                        if 'record_writer' in kwargs and kwargs['record_writer'] is not None:
                            record_writer = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['record_writer'])+"_data"
                            record_writer_id = str(session[record_writer]['id'])
                        print("--- record_reader_id ---")
                        print(record_reader_id)
                        print("--- record_writer_id ---")
                        print(record_writer_id) 
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                      revision_version=int(session[processor_key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=str(session[processor_key]['id']),
                                                                      component_name=str(session[processor_key]['status']['name']),
                                                                      component_config_concurrently_schedulable_task_count="1",
                                                                      component_config_scheduling_period=scheduling_period,
                                                                      component_config_execution_node="ALL",
                                                                      component_config_penalty_duration="30 sec",
                                                                      component_config_yield_duration="1 sec",
                                                                      component_config_bulletin_level="WARN",
                                                                      component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                      component_config_comments="",
                                                                      component_config_auto_terminated_relationships=relationships, #["failure", "original"]
                                                                      component_config_properties_record_reader=record_reader_id,
                                                                      component_config_properties_record_writer=record_writer_id,
                                                                      component_config_properties_min_records=kwargs['min_records'],
                                                                      component_config_properties_max_records=kwargs['max_records'],
                                                                      component_state="STOPPED",
                                                                      request_from="update",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      processor_name=kwargs['processor_name'])
                        
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['update_attribute']: # Updating Attribute Processor
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                      revision_version=int(session[processor_key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=str(session[processor_key]['id']),
                                                                      component_name=str(session[processor_key]['status']['name']),
                                                                      component_config_concurrently_schedulable_task_count="1",
                                                                      component_config_scheduling_period=scheduling_period,
                                                                      component_config_execution_node="ALL",
                                                                      component_config_penalty_duration="30 sec",
                                                                      component_config_yield_duration="1 sec",
                                                                      component_config_bulletin_level="WARN",
                                                                      component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                      component_config_comments="",
                                                                      component_config_run_duration_millis=0,
                                                                      component_config_auto_terminated_relationships=relationships,
                                                                      component_config_properties_filename=kwargs['filename'],
                                                                      component_state="STOPPED",
                                                                      request_from="update",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['put_file']: # Put File Processor               
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                      revision_version=int(session[processor_key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=str(session[processor_key]['id']),
                                                                      component_name=str(session[processor_key]['status']['name']),
                                                                      component_config_concurrently_schedulable_task_count="1",
                                                                      component_config_scheduling_period=scheduling_period,
                                                                      component_config_execution_node="ALL",
                                                                      component_config_penalty_duration="30 sec",
                                                                      component_config_yield_duration="1 sec",
                                                                      component_config_bulletin_level="WARN",
                                                                      component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                      component_config_comments="",
                                                                      component_config_run_duration_millis=0,
                                                                      component_config_auto_terminated_relationships=relationships,
                                                                      component_config_properties_directory=kwargs['file_path'],
                                                                      component_config_properties_conflict_resolution_strategy="replace",
                                                                      component_state="STOPPED",
                                                                      request_from="update",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'processor_name' in kwargs and kwargs['processor_name'] in ['get_file']: # Get File Processor
                        resp = process_group_helper.prepare_processor_data(revision_clientId=str(session[processor_key]['revision']['clientId']),
                                                                      revision_version=int(session[processor_key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=str(session[processor_key]['id']),
                                                                      component_name=str(session[processor_key]['status']['name']),
                                                                      component_config_concurrently_schedulable_task_count="1",
                                                                      component_config_scheduling_period=scheduling_period,
                                                                      component_config_execution_node="ALL",
                                                                      component_config_penalty_duration="30 sec",
                                                                      component_config_yield_duration="1 sec",
                                                                      component_config_bulletin_level="WARN",
                                                                      component_config_scheduling_strategy="TIMER_DRIVEN",
                                                                      component_config_comments="",
                                                                      component_config_auto_terminated_relationships=relationships,
                                                                      component_config_properties_input_directory=kwargs['file_path'],
                                                                      component_state="STOPPED",
                                                                      request_from="update",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      processor_name=kwargs['processor_name'])
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    
                    print("First dumps inside update")
                    print(dumps(data))
                    resp = requests.put(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    
                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['query_database_table']:
                        print("---- response from processor ----")
                        print(resp)

                    session[processor_key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component'],
                        "bulletins": resp['bulletins']
                    }
                    
                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['execute_sql','query_database_table']: # For Executing SQL Validating Database/Table name is valid or not
                        print("Validating connection inside update processor "+str(kwargs['skip_database_validation']))
                        temp_key = None
                        if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                            temp_key = kwargs['processor_key'] 
                        
                        if 'skip_database_validation' in kwargs and kwargs['skip_database_validation'] is not None and kwargs['skip_database_validation'].lower() in ['yes']:
                            pass # Skipping the database table validation
                        else: 
                            '''
                            # Updating schedulingPeriod to 1 min
                            url = self.base_url+'/processors/'+str(session[processor_key]['id'])
                            self.run_status(process_group_name=kwargs['process_group_name'], 
                                            processor_name=kwargs['processor_name'], 
                                            processor_key = temp_key,
                                            run_status='RUNNING')
                            '''
                            
                            # Preparing process group key
                            if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                                process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                            else: # Generating Key Based on Group Name
                                process_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                            
                            print("--- Before 5 second ----")
                            # Delaying for 10 seconds to know whether information given by user is valid or not
                            time.sleep(5)
                            print("--- After 5 second ----")

                            print("----- Inside Flow ------")
                            process_resp = process_group_helper.validating_flow(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            headers=self.headers,
                                                            base_url=self.base_url,
                                                            process_group_key=process_group_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            processor_key=kwargs['processor_key'],
                                                            processor_name=kwargs['processor_name'], 
                                                            run_status='STOPPED',
                                                            request_from='processor_update')
                            
                            if process_resp['status'] in ['error']:
                                return process_resp

                            '''
                            # Now checking whether the database/table name is valid or not
                            url = self.base_url+'/flow/process-groups/'+str(session[process_group_key]['id'])
                            resp = requests.get(url, headers=self.headers)
                            resp = resp.json()
                            #print(resp['processGroupFlow']['flow'])
                            if 'flow' in resp['processGroupFlow']:
                                print("Inside processGroupFlow")
                                if len(resp['processGroupFlow']['flow'])>0:
                                    print("Inside flow has some length")
                                    if 'processors' in resp['processGroupFlow']['flow']:
                                        print("Inside flow processor")
                                        if len(resp['processGroupFlow']['flow']['processors'])>0:
                                            print("Inside flow processor has some length")
                                            #print(resp['processGroupFlow']['flow']['processors'][0])
                                            # First check activeThreadCount if it is zero that mean there is error
                                            if 'bulletins' in resp['processGroupFlow']['flow']['processors'][0]:
                                                print("Inside flow processor bulletins ")
                                                print(resp['processGroupFlow']['flow']['processors'][0]['bulletins'])
                                                if len(resp['processGroupFlow']['flow']['processors'][0]['bulletins'])>0:
                                                    print("Inside flow processor bulletins has some length")
                                                    print(resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0])
                                                    if 'bulletin' in resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0]:
                                                        print(len(resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0]['bulletin']))
                                                        if len(resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0]['bulletin'])>0:
                                                            current_time = datetime.now() #.strftime("%H:%M:%S")
                                                            print("---- First current_time -----")
                                                            print(current_time)
                                                            current_time = current_time - timedelta(seconds=10)
                                                            print("---- Second current_time -----")
                                                            print(current_time)
                                                            current_time = current_time.strftime("%H:%M:%S")
                                                            print("---- Third current_time -----")
                                                            print(current_time)
                                                            error_time = resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0]['bulletin']['timestamp']
                                                            print(error_time)
                                                            error_time = error_time.split(" ")
                                                            print(error_time)
                                                            error_time = datetime.strptime(error_time[0],'%H:%M:%S')
                                                            error_time = error_time + timedelta(0,1)
                                                            print("error_time ")
                                                            error_time = str(error_time.time())
                                                            print(type(error_time))
                                                            if error_time >= current_time:
                                                                print("Inside same time")
                                                                if 'message' in resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0]['bulletin']:
                                                                    print(resp['processGroupFlow']['flow']['processors'][0]['bulletins'][0]['bulletin'])
                                                                    self.run_status(process_group_name=kwargs['process_group_name'],
                                                                                    processor_name=kwargs['processor_name'], 
                                                                                    processor_key=temp_key, 
                                                                                    run_status='STOPPED')
                                                                    return ({'status':'error','message':'Database/Table name is invalid or does not exists'})

                            # Updating schedulingPeriod to 1 min
                            url = self.base_url+'/processors/'+str(session[processor_key]['id'])
                            self.run_status(process_group_name=kwargs['process_group_name'], 
                                            processor_name=kwargs['processor_name'], 
                                            processor_key = temp_key,
                                            run_status='STOPPED')
                            '''
                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['update_attribute']:
                        return ({'status':'success','data':session[processor_key]})
                    else:
                        return ({'status':'success','data':session[processor_key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # Enabling/Disabling processor
    def run_status(self,**kwargs):
        try:
            print("---- Inside run_status processor methods -----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response

                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    if response['status'] in ['error']:
                        return response

                    # Preparing processor key
                    if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                    
                    run_status = 'STOPPED'
                    if 'run_status' in kwargs and kwargs['run_status'] in ['start']:
                        run_status = 'RUNNING'

                    url = self.base_url+'/processors/'+str(session[processor_key]['id'])+'/run-status'
                    print("---URL---")
                    print(url)
                    data = {
                        "revision": { "clientId": str(session[processor_key]['revision']['clientId']),"version": int(session[processor_key]['revision']['version'])},
                        "disconnectedNodeAcknowledged": False,
                        "state": run_status
                    }
                    print("--- data ----")
                    print(dumps(data)) #"use testing" #STOPPED # "RUNNING"
                    resp = requests.put(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    
                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['execute_sql']: # Checking request for execute sql
                        session[processor_key] = {
                            "id":resp['id'],
                            "status":resp['status'],
                            "revision":resp['revision'],
                            "component": resp['component'],
                            "bulletins": resp['bulletins']
                        }
                    return ({'status':'success','data':session[processor_key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # Fetching processor details
    def fetch(self,**kwargs):
        try:
            print("--- Inside fetch processor methods ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response

                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    if response['status'] in ['error']:
                        return response

                    # Preparing processor key
                    if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                    
                    url = self.base_url+'/processors/'+str(session[processor_key]['id'])
                    print("--- URL ----")
                    print(url)
                    resp = requests.get(url, headers=self.headers)
                    resp = resp.json()
                    #print(resp)
                    if 'processor_name' in kwargs and kwargs['processor_name'] in ['execute_sql']: # Checking request for execute sql
                        session[processor_key] = {
                            "id":resp['id'],
                            "status":resp['status'],
                            "revision":resp['revision'],
                            "component": resp['component'],
                            "bulletins": resp['bulletins']
                        }
                    return ({'status':'success','data':session[processor_key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # Deleting processor
    def delete(self,**kwargs):
        try:
            print("--- Inside delete processor methods ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response

                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing processor key
                    if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                    
                    url = self.base_url+'/processors/'+str(session[processor_key]['id'])+"?version="+str(session[processor_key]['revision']['version'])+"&clientId="+str(session[processor_key]['revision']['clientId'])+"&disconnectedNodeAcknowledged=false"
                    print("--- URL ----")
                    print(url)
                    resp = requests.delete(url, headers=self.headers)
                    resp = resp.json()
                    session.pop(processor_key,None)
                    return ({'status':'success','message':"Processor deleted successfully"})    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # For terminating processor thread
    def terminate_threads(self,**kwargs):
        try:
            print("--- Inside terminate_threads processor methods ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response

                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing processor key
                    if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                    
                    url = self.base_url+'/processors/'+str(session[processor_key]['id'])+"/threads"
                    print("--- URL ----")
                    print(url)
                    resp = requests.delete(url, headers=self.headers)
                    resp = resp.json()
                    session[processor_key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component'],
                        "bulletins": resp['bulletins']
                    }
                    return ({'status':'success','data':session[processor_key]})    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # Clears the state for a processor
    def clear_requests(self,**kwargs):
        try:
            print("--- Inside clear_requests processor methods ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Validating process group name is valid or not
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    if response['status'] in ['error']:
                        return response

                    # Validating processor name is valid or not
                    response = process_group_helper.validate_name(request_for='processor', processor_name=kwargs['processor_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing processor key
                    if 'processor_key' in kwargs and kwargs['processor_key'] is not None: # Generating Random Key
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_key = str(self.catalog_key)+"_"+str(self.project_key)+'_processor_'+str(kwargs['process_group_name'])+"_"+str(kwargs['processor_name'])+"_data"
                    
                    url = self.base_url+'/processors/'+str(session[processor_key]['id'])+"/state/clear-requests"
                    print("--- URL ----")
                    print(url)
                    resp = requests.post(url, headers=self.headers)
                    print(resp)
                    resp = resp.json()
                    if len(resp)>0:
                        print("---- resp of clear_requests ------")
                        print(resp)
                    '''
                    session[processor_key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component'],
                        "bulletins": resp['bulletins']
                    }
                    '''
                    return ({'status':'success','message':"processor state clear successfully"}) 
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
