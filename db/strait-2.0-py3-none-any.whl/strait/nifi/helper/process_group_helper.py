from flask import session
from datetime import datetime, timedelta
import random, string, sys, stat, time, requests
import strait.nifi.processor as processor
import strait.nifi.connection as connection
import strait.nifi.controller_service as controller_service
import strait.nifi.processor as processor
import strait.nifi.process_group as process_group
from os import path, getcwd, makedirs, environ, rename, remove, chmod
#from environment import load_env

# Initializing Environment
#load_env()

# Generating random string
def random_string(stringLength):
    """ Generate a random string with the combination of lowercase, uppercase letters, digits and special characters """
    try:
        # Removing ~ it produce + when encode base64 which producing error and plus treating as space separator in URL
        letters = string.ascii_letters + string.digits
        return ''.join(random.choice(letters) for i in range(stringLength))
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Fetching predefined processor group/processor lists
def get_predefined_lists(**kwargs):
    try:
        if 'request_for' not in kwargs or kwargs['request_for'] is None:
            return ({'status':"error",'message':"list name is required"})
        else:
            if 'request_for' in kwargs and kwargs['request_for'] in ['process_group']:
                processor_group_lists = environ.get('PROCESSOR_GROUP_NAME',None)
                processor_group_lists = processor_group_lists.split(",")
                return ({'status':"success",'data':processor_group_lists})
            elif 'request_for' in kwargs and kwargs['request_for'] in ['processor']:
                processor_lists = environ.get('PROCESSOR_NAME',None)
                processor_lists = processor_lists.split(",")
                return ({'status':"success",'data':processor_lists})
            elif 'request_for' in kwargs and kwargs['request_for'] in ['controller_service']:
                controller_service_lists = environ.get('CONTROL_SERVICE_NAME',None)
                controller_service_lists = controller_service_lists.split(",")
                return ({'status':"success",'data':controller_service_lists})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Validating process group, processor, controller service name
def validate_name(**kwargs):
    try:
        if 'request_for' in kwargs and kwargs['request_for'] in ['controller_service']:
            # Fetching predefined controller service lists
            controller_service_lists = get_predefined_lists(request_for=kwargs['request_for'])
            if controller_service_lists['status'] in ['error']:
                return controller_service_lists
            controller_service_lists = controller_service_lists['data']
            
            # Checking controller service name is valid or not
            if 'controller_service_name' in kwargs and kwargs['controller_service_name'] not in controller_service_lists:
                return ({'status':'error','message':"controller service name is invalid"})
            return ({'status':'success','message':'controller service group name is valid'})
        elif 'request_for' in kwargs and kwargs['request_for'] in ['process_group']:
            # Fetching predefined process group lists
            process_group_lists = get_predefined_lists(request_for=kwargs['request_for'])
            if process_group_lists['status'] in ['error']:
                return process_group_lists
            process_group_lists = process_group_lists['data']
            
            # Checking process group name is valid or not
            if 'process_group_name' in kwargs and kwargs['process_group_name'] not in process_group_lists:
                return ({'status':'error','message':"process group name is invalid"})
            return ({'status':'success','message':'process group name is valid'})
        elif 'request_for' in kwargs and kwargs['request_for'] in ['processor']:
            # Fetching predefined processor lists
            processor_lists = get_predefined_lists(request_for=kwargs['request_for'])
            if processor_lists['status'] in ['error']:
                return processor_lists
            processor_lists = processor_lists['data']
            
            # Checking processor name is valid or not
            if 'processor_name' in kwargs and kwargs['processor_name'] not in processor_lists:
                return ({'status':'error','message':"processor name is invalid"})
            return ({'status':'success','message':'processor name is valid'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Creating file path for create dataset
def create_file_path(**kwargs):
    storage_type = environ.get('STORAGE_TYPE',None)
    if storage_type in ['docker']:
        base_path = environ.get('STORAGE',None)
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None: 
            # Making catalog folder to store respective projects inside that
            catalog_dir = path.join(base_path,kwargs['catalog_key'])
            if not path.exists(catalog_dir):
                makedirs(catalog_dir) 

            # Making project folder to store respective dataset inside that
            project_dir = path.join(catalog_dir,kwargs['project_key'],'datasets')
            if not path.exists(project_dir):
                makedirs(project_dir)

            # Making dataset folder to store respective dataset inside that
            temp_dir = path.join(project_dir,'temp')
            if not path.exists(temp_dir):
                makedirs(temp_dir)
            
            # Making dataset folder to store respective dataset inside that
            nifi_dir = path.join(project_dir,'nifi')
            if not path.exists(nifi_dir):
                makedirs(nifi_dir)

            if 'return_type' in kwargs and kwargs['return_type'] is not None:
                if kwargs['return_type'] in ['temp','nifi']:
                    pass
                else:
                    if 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
                        # Making dataset folder to store respective dataset inside that
                        dataset_dir = path.join(project_dir,kwargs['dataset_key'])
                        if not path.exists(dataset_dir):
                            makedirs(dataset_dir)
                        
                        # Making history folder to store respective dataset recipe file inside that
                        history_dir = path.join(dataset_dir,'history')
                        if not path.exists(history_dir):
                            makedirs(history_dir)
                    else:
                        return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
                    # Making dataset folder to store respective dataset inside that
                    dataset_dir = path.join(project_dir,kwargs['dataset_key'])
                    if not path.exists(dataset_dir):
                        makedirs(dataset_dir)
                    
                    # Making history folder to store respective dataset recipe file inside that
                    history_dir = path.join(dataset_dir,'history')
                    if not path.exists(history_dir):
                        makedirs(history_dir)
                else:
                    return ({'status':'error','message':'Missing required parameters'})

            if 'return_type' in kwargs and kwargs['return_type'] is not None: # Retruning temp path
                if kwargs['return_type'] in ['temp']:
                    return ({'status':'success','file_path':temp_dir})
                elif kwargs['return_type'] in ['nifi']:
                    print("-- Inside NiFi file path ----")
                    chmod(nifi_dir, stat.S_IRWXO)
                    print("--- Path Changed -----")
                    return ({'status':'success','file_path':nifi_dir})
                else:
                    return ({'status':'success','file_path':dataset_dir})
            else: # Retruning dataset path
                return ({'status':'success','file_path':dataset_dir})
        else:
            return ({'status':'error','message':'Missing required parameters'})

# Prepare processor data
def prepare_processor_data(**kwargs):
    try:
        print("--- Inside prepare_processor_data ---")
        if 'request_from' in kwargs and kwargs['request_from'] in ['update']:
            data = {
                "revision": { 
                    "clientId": kwargs['revision_clientId'],
                    "version": int(kwargs['revision_version']),
                },
                "disconnectedNodeAcknowledged": kwargs['disconnected_node_acknowledged'],
                "component":{
                    "id": str(kwargs['component_id']), 
                    "name": str(kwargs['component_name']),
                    "config":{},
                    "state": str(kwargs['component_state']),
                }
            }

            if 'component_config_concurrently_schedulable_task_count' in kwargs and kwargs['component_config_concurrently_schedulable_task_count'] is not None:
                data['component']['config']['concurrentlySchedulableTaskCount'] = kwargs['component_config_concurrently_schedulable_task_count']
            
            if 'component_config_scheduling_period' in kwargs and kwargs['component_config_scheduling_period'] is not None:
                data['component']['config']['schedulingPeriod'] = kwargs['component_config_scheduling_period']
            
            if 'component_config_execution_node' in kwargs and kwargs['component_config_execution_node'] is not None:
                data['component']['config']['executionNode'] = kwargs['component_config_execution_node']
            
            if 'component_config_penalty_duration' in kwargs and kwargs['component_config_penalty_duration'] is not None:
                data['component']['config']['penaltyDuration'] = kwargs['component_config_penalty_duration']
            
            if 'component_config_yield_duration' in kwargs and kwargs['component_config_yield_duration'] is not None:
                data['component']['config']['yieldDuration'] = kwargs['component_config_yield_duration']
            
            if 'component_config_bulletin_level' in kwargs and kwargs['component_config_bulletin_level'] is not None:
                data['component']['config']['bulletinLevel'] = kwargs['component_config_bulletin_level']
            
            if 'component_config_scheduling_strategy' in kwargs and kwargs['component_config_scheduling_strategy'] is not None:
                data['component']['config']['schedulingStrategy'] = kwargs['component_config_scheduling_strategy']
            
            if 'component_config_comments' in kwargs and kwargs['component_config_comments'] is not None:
                data['component']['config']['comments'] = kwargs['component_config_comments']
            
            if 'component_config_auto_terminated_relationships' in kwargs and kwargs['component_config_auto_terminated_relationships'] is not None:
                data['component']['config']['autoTerminatedRelationships'] = kwargs['component_config_auto_terminated_relationships']
            
            if 'processor_name' in kwargs and kwargs['processor_name'] in ['execute_sql']:
                #if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_lists_from_mysql','fetch_table_details_from_mysql']:
                data['component']['config']['properties'] = {}
                if 'database_connection_pooling_service' in kwargs and kwargs['database_connection_pooling_service'] is not None:
                    data['component']['config']['properties']['Database Connection Pooling Service'] = str(kwargs['database_connection_pooling_service'])
                
                if 'sql_pre_query' in kwargs and kwargs['sql_pre_query'] is not None:
                    data['component']['config']['properties']['sql-pre-query'] = str(kwargs['sql_pre_query'])
                
                if 'sql_select_query' in kwargs and kwargs['sql_select_query'] is not None:
                    data['component']['config']['properties']['SQL select query'] = str(kwargs['sql_select_query'])

                if 'component_config_esql_max_rows' in kwargs and kwargs['component_config_esql_max_rows'] is not None:
                    data['component']['config']['properties']['esql-max-rows'] = str(kwargs['component_config_esql_max_rows'])
                
                if 'component_config_esql_output_batch_size' in kwargs and kwargs['component_config_esql_output_batch_size'] is not None:
                    data['component']['config']['properties']['esql-output-batch-size'] = str(kwargs['component_config_esql_output_batch_size'])
                
                if 'component_config_esql_fetch_size' in kwargs and kwargs['component_config_esql_fetch_size'] is not None:
                    data['component']['config']['properties']['esql-fetch-size'] = str(kwargs['component_config_esql_fetch_size'])
        
            if 'processor_name' in kwargs and kwargs['processor_name'] in ['query_database_table']:
                data['component']['config']['properties'] = {}
                if 'database_connection_pooling_service' in kwargs and kwargs['database_connection_pooling_service'] is not None:
                    data['component']['config']['properties']['Database Connection Pooling Service'] = str(kwargs['database_connection_pooling_service'])
                
                if 'component_config_properties_table_name' in kwargs and kwargs['component_config_properties_table_name'] is not None:
                    data['component']['config']['properties']['Table Name'] = str(kwargs['component_config_properties_table_name'])
                
                if 'component_config_properties_fetch_size' in kwargs and kwargs['component_config_properties_fetch_size'] is not None:
                    data['component']['config']['properties']['Fetch Size'] = str(kwargs['component_config_properties_fetch_size'])

                if 'component_config_properties_qdbt_max_rows' in kwargs and kwargs['component_config_properties_qdbt_max_rows'] is not None:
                    data['component']['config']['properties']['qdbt-max-rows'] = str(kwargs['component_config_properties_qdbt_max_rows'])

                if 'component_config_properties_qdbt_output_batch_size' in kwargs and kwargs['component_config_properties_qdbt_output_batch_size'] is not None:
                    data['component']['config']['properties']['qdbt-output-batch-size'] = str(kwargs['component_config_properties_qdbt_output_batch_size'])

            if 'processor_name' in kwargs and kwargs['processor_name'] in ['convert_avro_to_json','update_attribute','put_file']:
                data['component']['config']['runDurationMillis'] = kwargs['component_config_run_duration_millis']
            
            if 'processor_name' in kwargs and kwargs['processor_name'] in ['update_attribute']:
                data['component']['config']['properties'] = {
                    "filename": kwargs['component_config_properties_filename']
                }
            
            if 'processor_name' in kwargs and kwargs['processor_name'] in ['put_file']:
                data['component']['config']['properties'] = {
                    "Directory": kwargs['component_config_properties_directory'],
                    "Conflict Resolution Strategy": kwargs['component_config_properties_conflict_resolution_strategy']
                }
            
            if 'processor_name' in kwargs and kwargs['processor_name'] in ['get_file']:
                data['component']['config']['properties'] = {
                    "Input Directory": kwargs['component_config_properties_input_directory']
                }
            
            if 'processor_name' in kwargs and kwargs['processor_name'] in ['merge_records']:
                data['component']['config']['properties'] = {}
                if 'component_config_properties_record_reader' in kwargs and kwargs['component_config_properties_record_reader'] is not None:
                    data['component']['config']['properties']['record-reader'] = str(kwargs['component_config_properties_record_reader'])
                
                if 'component_config_properties_record_writer' in kwargs and kwargs['component_config_properties_record_writer'] is not None:
                    data['component']['config']['properties']['record-writer'] = str(kwargs['component_config_properties_record_writer'])
                
                if 'component_config_properties_min_records' in kwargs and kwargs['component_config_properties_min_records'] is not None:
                    data['component']['config']['properties']['min-records'] = str(kwargs['component_config_properties_min_records'])
                
                if 'component_config_properties_max_records' in kwargs and kwargs['component_config_properties_max_records'] is not None:
                    data['component']['config']['properties']['max-records'] = str(kwargs['component_config_properties_max_records'])
                
            print(data)
        else:
            data = {
                "revision": { 
                    "clientId": kwargs['revision_clientId'],
                    "version": kwargs['revision_version']
                },
                "disconnectedNodeAcknowledged": kwargs['disconnected_node_acknowledged'],
                "component": {
                    "type":  kwargs['component_type'],
                    "name":  kwargs['component_name'],
                    "bundle": {
                        "group": "org.apache.nifi", 
                        "artifact": kwargs['component_bundle_artifact'],
                        "version": kwargs['component_bundle_version'],
                    },
                    "position": {
                        "x": kwargs['component_position_x'], 
                        "y": kwargs['component_position_y'],
                    } # Random position to be set
                }
            }
        return ({'status':'success','data':data})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Prepare controller service data
def prepare_controller_service_data(**kwargs):
    try:
        print("--- Inside prepare_controller_service_data ---")
        if 'request_from' in kwargs and kwargs['request_from'] in ['update']:
            data = {
                "revision": { 
                    "clientId": kwargs['revision_clientId'],
                    "version": int(kwargs['revision_version']),
                },
                "disconnectedNodeAcknowledged": kwargs['disconnected_node_acknowledged'],
                "component":{
                    "id": str(kwargs['component_id']), 
                    "name": str(kwargs['component_name']),
                    "comments":""
                }
            }

            if 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['mysql','postgres','sqlite']:
                base_path = environ.get('STORAGE',None)
                print("---- base_path ------")
                print(base_path)
                if 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_mysql','fetch_table_lists_from_mysql','fetch_table_schema_from_mysql','fetch_database_name_from_mysql','fetch_table_row_count_from_mysql']:
                    data['component']["properties"] = {
                            "Database Connection URL": "jdbc:mysql://"+str(kwargs['database_connection_url'])+":"+str(kwargs['database_port_no']),
                            "Database Driver Class Name": "com.mysql.jdbc.Driver", 
                            "database-driver-locations": path.join("/jardir","database","mysql","mysql-connector-java-8.0.18.jar"), # path.join(getcwd(),"nifi","lib","mysql","mysql-connector-java-8.0.18.jar") # Driver Location
                            "Database User":kwargs['database_username'],
                            "Password": kwargs['database_password']
                        }
                    
                    if 'validation_query' in kwargs and kwargs['validation_query'] is not None and kwargs['validation_query'].lower() in ['yes']:
                        data['component']['properties']['Validation-query'] = "select CURRENT_TIMESTAMP()"

                        # "database-driver-locations": path.join("C:\\","Program Files (x86)","MySQL","Connector J 8.0","mysql-connector-java-8.0.18.jar"), # Driver Location
                elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_postgres','fetch_table_lists_from_postgres','fetch_table_schema_from_postgres','fetch_database_name_from_postgres','fetch_table_row_count_from_postgres']:
                    data['component']["properties"] = {
                            "Database Connection URL": "jdbc:postgresql://"+str(kwargs['database_connection_url'])+":"+str(kwargs['database_port_no'])+"/"+str(kwargs['database_name']),
                            "Database Driver Class Name": "org.postgresql.Driver", 
                            "database-driver-locations": path.join("/jardir","database","postgres","postgresql-42.2.5.jar"), # path.join(getcwd(),"nifi","lib","postgres","postgresql-42.2.5.jar")  # Driver Location
                            "Database User":kwargs['database_username'],
                            "Password": kwargs['database_password']
                        }
                        #"database-driver-locations": path.join("C:\\","Program Files (x86)","PostgreSQL","pgJDBC","postgresql-42.2.5.jar"),  # Driver Location
                elif 'process_group_name' in kwargs and kwargs['process_group_name'] in ['fetch_table_details_from_sqlite','fetch_table_lists_from_sqlite','fetch_table_schema_from_sqlite','fetch_database_name_from_sqlite','fetch_table_row_count_from_sqlite']:
                    data['component']["properties"] = {
                            "Database Connection URL": "jdbc:sqlite:"+str(kwargs['database_connection_url'])+"/"+str(kwargs['database_name'])+".db",
                            "Database Driver Class Name": "org.sqlite.JDBC", 
                            "database-driver-locations": path.join("/jardir","database","sqlite","sqlite-jdbc-3.30.1.jar") #path.join(getcwd(),"nifi","lib","sqlite","sqlite-jdbc-3.30.1.jar") #"C:\\Users\\vineeth\\sqlite\\sqlite-jdbc-3.30.1.jar" #path.join("C:\\","Users","vineeth","sqlite","sqlite-jdbc-3.30.1.jar") # Driver Location
                        }
        else:
            data = {
                "revision": { 
                    "clientId": kwargs['revision_clientId'],
                    "version": kwargs['revision_version']
                },
                "disconnectedNodeAcknowledged": kwargs['disconnected_node_acknowledged'],
                "component": {
                    "type":  kwargs['component_type'],
                    "bundle": {
                        "group": "org.apache.nifi", 
                        "artifact": kwargs['component_bundle_artifact'],
                        "version": kwargs['component_bundle_version'],
                    }
                }
            }
        return ({'status':'success','data':data})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Deleting processor along with connection also
def delete_processor(**kwargs):
    try:
        if 'catalog_key' not in kwargs or kwargs['catalog_key'] is None or 'project_key' not in kwargs or kwargs['project_key'] is None or 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'processor_name' not in kwargs or kwargs['processor_name'] is None:
            return ({'status':'error','message':'Missing required parameters'})
        else: 
            if 'source_processor_name' in kwargs and kwargs['source_processor_name'] is not None and 'destination_processor_name' in kwargs and kwargs['destination_processor_name'] is not None:
                '''
                # Clearing Processor State
                print(" Clearing Processor State ")
                processor_obj = processor.Processor(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
                processor_resp = processor_obj.clear_requests(process_group_name=kwargs['process_group_name'],
                                                    process_group_key=kwargs['process_group_key'],
                                                    processor_name=kwargs['processor_name'],
                                                    processor_key=kwargs['processor_key'])
                print(processor_resp['status'])
                if processor_resp['status'] in ['error']:
                    return processor_resp
                '''
                
                # Deleting Any Item If in Queue
                print(" Deleting Any Item If in Queue connection between execute_sql to convert_avro_to_json ")
                connection_obj = connection.Connection(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
                connection_resp = connection_obj.clear_queue(process_group_name=kwargs['process_group_name'],
                                                        process_group_key=kwargs['process_group_key'],
                                                        source_processor_name=kwargs['source_processor_name'],
                                                        destination_processor_name=kwargs['destination_processor_name'],
                                                        source_processor_key=kwargs['source_processor_key'],
                                                        destination_processor_key=kwargs['destination_processor_key'])
                print(connection_resp['status'])
                if connection_resp['status'] in ['error']:
                    return connection_resp
                
                # Deleting Connection between execute_sql to convert_avro_to_json
                print("Deleting Connection between execute_sql to convert_avro_to_json")
                connection_obj = connection.Connection(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
                connection_resp = connection_obj.delete(process_group_name=kwargs['process_group_name'],
                                                        process_group_key=kwargs['process_group_key'],
                                                        source_processor_name=kwargs['source_processor_name'],
                                                        destination_processor_name=kwargs['destination_processor_name'],
                                                        source_processor_key=kwargs['source_processor_key'],
                                                        destination_processor_key=kwargs['destination_processor_key'])
                print(connection_resp['status'])
                if connection_resp['status'] in ['error']:
                    return connection_resp
            
            # Deleting ExecuteSQL Processor
            print(" Deleting ExecuteSQL processor ")
            processor_obj = processor.Processor(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
            processor_resp = processor_obj.delete(process_group_name=kwargs['process_group_name'],
                                                process_group_key=kwargs['process_group_key'],
                                                processor_name=kwargs['processor_name'],
                                                processor_key=kwargs['processor_key'])
            print(processor_resp['status'])
            if processor_resp['status'] in ['error']:
                return processor_resp
            
            return ({'status':'success',"message":"Processor deleted successfully"})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

def delete_controller_service(**kwargs):
    try:
        print("--- Inside delete_controller_service ----")
        if 'catalog_key' not in kwargs or kwargs['catalog_key'] is None or 'project_key' not in kwargs or kwargs['project_key'] is None or 'controller_service_name' not in kwargs or kwargs['controller_service_name'] is None:
            return ({'status':'error','message':'Missing required parameters'})
        else: 
            print("---- before 5 second delay")
            # Making Some delay before disabling controller service reason of doing that in below link
            # https://community.cloudera.com/t5/Support-Questions/Stop-Controller-Service-in-nifi-using-rest-api/td-p/215114
            time.sleep(5)
            print("---- after 5 second delay")
            
            # Disbaling controller service
            print(" Disbaling Controller Service ")
            controller_service_key = None
            if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None:
                controller_service_key = kwargs['controller_service_key']
            controller_service_obj  = controller_service.ControllerService(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
            controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                        controller_service_key = controller_service_key,
                                                                        run_status='stop')
            print(controller_service_resp['status'])
            if controller_service_resp['status'] in ['error']:
                return controller_service_resp
            
            # Deleting Controller Service
            print(" Deleting Controller Service ")
            controller_service_obj  = controller_service.ControllerService(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
            controller_service_resp = controller_service_obj.delete(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key = controller_service_key)
            print(controller_service_resp['status'])
            if controller_service_resp['status'] in ['error']:
                return controller_service_resp
            
            return ({'status':'success','message':'Controller service deleted successfully'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Now checking whether the database/table name is valid or not        
def validating_flow(**kwargs):
    try:
        print("---- Inside validating_flow ------")
        # Preparing process group key
        if 'request_from' in kwargs and kwargs['request_from'] is not None and kwargs['request_from'] in ['processor_update']:
            process_group_key = kwargs['process_group_key']
        else:
            if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                process_group_key = str(kwargs['catalog_key'])+"_"+str(kwargs['project_key'])+"_process_group_"+str(kwargs['process_group_key'])+"_data"
            else: # Generating Key Based on Group Name
                process_group_key = str(kwargs['catalog_key'])+"_"+str(kwargs['project_key'])+"_process_group_"+str(kwargs['process_group_name'])+"_data"
        
        print("---- process_group_key -----")
        print(process_group_key)
        url = str(kwargs['base_url'])+'/flow/process-groups/'+str(session[process_group_key]['id'])
        print("--- URL ---")
        print(url)
        resp = requests.get(url, headers=kwargs['headers'])
        resp = resp.json()
        #print(resp['processGroupFlow']['flow'])
        if 'flow' in resp['processGroupFlow']:
            print("--------------- Inside processGroupFlow -------------------")
            if len(resp['processGroupFlow']['flow'])>0:
                print("----------- Inside flow has some length -----------------")
                if 'processors' in resp['processGroupFlow']['flow']:
                    print("-------------- Inside flow processor --------------")
                    if len(resp['processGroupFlow']['flow']['processors'])>0:
                        print("------- Inside flow processor has some length -------------")
                        # First check activeThreadCount if it is zero that mean there is error
                        for item in resp['processGroupFlow']['flow']['processors']:
                            print("---------------- processor item -------------------")
                            print(item)
                            if 'bulletins' in item:
                                print("------------------- Inside flow processor bulletins ------------------------")
                                print(item['bulletins'])
                                if len(item['bulletins'])>0:
                                    print("------------ Inside flow processor bulletins has some length --------------")
                                    for bulletins_item in item['bulletins']:
                                        print("--------- bulletins_item -----------")
                                        print(bulletins_item)
                                        if 'bulletin' in bulletins_item:
                                            print(len(bulletins_item['bulletin']))
                                            if len(bulletins_item['bulletin'])>0:
                                                current_time = datetime.now() #.strftime("%H:%M:%S")
                                                print("---- First current_time -----")
                                                print(current_time)
                                                current_time = current_time - timedelta(seconds=10)
                                                print("---- Second current_time -----")
                                                print(current_time)
                                                current_time = current_time.strftime("%H:%M:%S")
                                                print("---- Third current_time -----")
                                                print(current_time)
                                                error_time = bulletins_item['bulletin']['timestamp']
                                                print(error_time)
                                                error_time = error_time.split(" ")
                                                print(error_time)
                                                error_time = datetime.strptime(error_time[0],'%H:%M:%S')
                                                error_time = error_time + timedelta(0,1)
                                                print("error_time ")
                                                error_time = str(error_time.time())
                                                print(type(error_time))
                                                if error_time >= current_time:
                                                    print("Inside same time")
                                                    if 'message' in bulletins_item['bulletin']:
                                                        print(bulletins_item['bulletin'])
                                                        # In case of error processor has to be stop
                                                        if 'request_from' in kwargs and kwargs['request_from'] is not None and kwargs['request_from'] in ['processor_update']:
                                                            processor_obj = processor.Processor(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
                                                            processor_obj.run_status(process_group_name=kwargs['process_group_name'],
                                                                            processor_name=kwargs['processor_name'], 
                                                                            processor_key=kwargs['processor_key'], 
                                                                            run_status=kwargs['run_status'])
                                                        elif 'request_from' in kwargs and kwargs['request_from'] is not None and kwargs['request_from'] in ['stop_process_group']:
                                                            process_group_obj = process_group.ProcessGroup(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'], parent_group_id=kwargs['parent_group_id'])
                                                            process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                            process_group_key=kwargs['process_group_key'],
                                                                            run_status='stop')
                                                        return ({'status':'error','message':'Database/Table name is invalid or does not exists'})
    
        if 'request_from' in kwargs and kwargs['request_from'] is not None and kwargs['request_from'] in ['processor_update']:
            # Updating schedulingPeriod to 1 min
            processor_obj = processor.Processor(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'])
            processor_obj.run_status(process_group_name=kwargs['process_group_name'], 
                            processor_name=kwargs['processor_name'], 
                            processor_key = kwargs['processor_key'],
                            run_status=kwargs['run_status'])
        
        return ({'status':'success'})
    except Exception as e:
        return ({'status':"error",'message':str(e)})