from strait.environment import load_env

# Initializing Environment
load_env()
