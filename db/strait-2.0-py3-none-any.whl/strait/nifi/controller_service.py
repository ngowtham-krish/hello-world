#import nipyapi
import requests, time
import random, string
from os import environ
from flask import session
from json import loads, dumps
import strait.nifi.helper.process_group_helper as process_group_helper
#from strait.environment import load_env

# Initializing Environment
#load_env()

class ControllerService:

    def __init__(self, **kwargs):
        self.catalog_key = None
        self.project_key = None
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        
        '''
        if 'parent_group_id' in kwargs and kwargs['parent_group_id'] is not None:
            self.parent_group_id = kwargs['parent_group_id']
        else:
            self.parent_group_id = nipyapi.canvas.get_root_pg_id()
        '''
        self.base_url = environ.get('NIFI_URL',None)
        self.headers = {'content-type': 'application/json'}
    
    # For creating controller service
    def create(self,**kwargs):
        try:
            print("--- Inside create controller service methods ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'process_group_name' not in kwargs or kwargs['process_group_name'] is None or 'controller_service_name' not in kwargs or kwargs['controller_service_name'] is None:
                    return ({'status':'error','message':'Missing required parameters'})
                else:
                    # Generating random clientId for requests
                    clientId = process_group_helper.random_string(8)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(4)+"-"+process_group_helper.random_string(12)
                    
                    # Validating process group name is valid or not
                    print("-- Validating process group name ---")
                    response = process_group_helper.validate_name(request_for='process_group', process_group_name=kwargs['process_group_name'])
                    print(response)
                    if response['status'] in ['error']:
                        return response
                    
                    # Validating controller service name is valid or not
                    print("-- Validating controller service name ---")
                    response = process_group_helper.validate_name(request_for='controller_service', controller_service_name=kwargs['controller_service_name'])
                    print(response)
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing process group key
                    if 'process_group_key' in kwargs and kwargs['process_group_key'] is not None: # Generating Random Key
                        processor_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        processor_group_key = str(self.catalog_key)+"_"+str(self.project_key)+"_process_group_"+str(kwargs['process_group_name'])+"_data"
                    
                    url = self.base_url+'/process-groups/'+str(session[processor_group_key]['id'])+'/controller-services'
                    print("--- URL ---")
                    print(url)

                    if 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['mysql','postgres','sqlite']: # Checking request for database connection
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.dbcp.DBCPConnectionPool",
                                                                      component_bundle_artifact="nifi-dbcp-service-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="create")
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['avro_reader']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.avro.AvroReader",
                                                                      component_bundle_artifact="nifi-record-serialization-services-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="create")
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['json_record_set_writer']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.json.JsonRecordSetWriter",
                                                                      component_bundle_artifact="nifi-record-serialization-services-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="create")
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['parquet_record_set_writer']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.parquet.ParquetRecordSetWriter",
                                                                      component_bundle_artifact="nifi-parquet-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="create")
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['csv_record_set_writer']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.csv.CSVRecordSetWriter",
                                                                      component_bundle_artifact="nifi-record-serialization-services-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="create")
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['avro_reader']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId=clientId,
                                                                      revision_version=0,
                                                                      disconnected_node_acknowledged=False,
                                                                      component_type="org.apache.nifi.avro.AvroReader",
                                                                      component_bundle_artifact="nifi-record-serialization-services-nar",
                                                                      component_bundle_version="1.11.2",
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="create")
                    if resp['status'] in ['error']:
                        return resp
                    data = resp['data']
                    
                    print("--- data ---")
                    print(dumps(data))
                    resp = requests.post(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()

                    # Preparing controller service key
                    if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_name'])+"_"+"data"
                    
                    session[key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component']
                    }
                    return ({'status':'success','data':session[key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # For updating controller service
    def update(self,**kwargs):
        try:
            print("--- Inside update controller service ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'controller_service_name' not in kwargs or kwargs['controller_service_name'] is None:
                    return ({'status':'error','message':'controller service name is required'})
                else:
                    # Validating controller service name is valid or not
                    print("-- Validating controller service name ---")
                    response = process_group_helper.validate_name(request_for='controller_service', controller_service_name=kwargs['controller_service_name'])
                    print(response)
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing controller service key
                    if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_name'])+"_"+"data"
                    
                    url = self.base_url+'/controller-services/'+str(session[key]['id'])
                    print("--- URL ---")
                    print(url)
                    if 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['mysql']: # Checking request for database connection for MySQL
                        validation_query = None
                        if 'validation_query' in kwargs and kwargs['validation_query'] is not None:
                            validation_query = kwargs['validation_query']
                        print("validation_query "+str(validation_query))
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId= str(session[key]['revision']['clientId']),
                                                                      revision_version= int(session[key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=session[key]['id'],
                                                                      component_name = "DB Connection Pool For "+str(kwargs['controller_service_name']),
                                                                      database_connection_url= kwargs['database_connection_url'],
                                                                      database_port_no = kwargs['database_port_no'],
                                                                      database_username = kwargs['database_user_name'],
                                                                      database_password = kwargs['database_password'],
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="update",
                                                                      validation_query=validation_query)
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['postgres']: # Checking request for database connection for Postgres
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId= str(session[key]['revision']['clientId']),
                                                                      revision_version= int(session[key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=session[key]['id'],
                                                                      component_name = "DB Connection Pool For "+str(kwargs['controller_service_name']),
                                                                      database_connection_url= kwargs['database_connection_url'],
                                                                      database_port_no = kwargs['database_port_no'],
                                                                      database_name = kwargs['database_name'],
                                                                      database_username = kwargs['database_user_name'],
                                                                      database_password = kwargs['database_password'],
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="update")
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['sqlite']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId= str(session[key]['revision']['clientId']),
                                                                      revision_version= int(session[key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=session[key]['id'],
                                                                      component_name = "DB Connection Pool For "+str(kwargs['controller_service_name']),
                                                                      database_connection_url= kwargs['database_connection_url'],
                                                                      database_name = kwargs['database_name'],
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="update")
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    elif 'controller_service_name' in kwargs and kwargs['controller_service_name'] in ['avro_reader']:
                        resp = process_group_helper.prepare_controller_service_data(revision_clientId= str(session[key]['revision']['clientId']),
                                                                      revision_version= int(session[key]['revision']['version']),
                                                                      disconnected_node_acknowledged=False,
                                                                      component_id=session[key]['id'],
                                                                      component_name = "DB Connection Pool For "+str(kwargs['controller_service_name']),
                                                                      database_connection_url= kwargs['database_connection_url'],
                                                                      database_name = kwargs['database_name'],
                                                                      process_group_name=kwargs['process_group_name'],
                                                                      controller_service_name = kwargs['controller_service_name'],
                                                                      request_from="update")
                        if resp['status'] in ['error']:
                            return resp
                        data = resp['data']
                    
                    print("---- data ----")
                    print(dumps(data))
                    resp = requests.put(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()
                    
                    session[key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component']
                    }
                    return ({'status':'success','data':session[key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # For deleting controller service
    def delete(self,**kwargs):
        try:
            print("--- Inside delete controller service methods ----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'controller_service_name' not in kwargs or kwargs['controller_service_name'] is None:
                    return ({'status':'error','message':'controller service name is required'})
                else:
                    # Validating controller service name is valid or not
                    print("-- Validating controller service name ---")
                    response = process_group_helper.validate_name(request_for='controller_service', controller_service_name=kwargs['controller_service_name'])
                    print(response)
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing controller service key
                    if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_name'])+"_"+"data"
                    
                    url = self.base_url+'/controller-services/'+str(session[key]['id'])+"?clientId="+str(session[key]['revision']['clientId'])+"&version="+str(session[key]['revision']['version'])+"&disconnectedNodeAcknowledged=false"
                    print("--- url ----")
                    print(str(url))
                    resp = requests.delete(url, headers=self.headers)
                    resp = resp.json()
                    session.pop(key,None)
                    return ({'status':'success','message':"Controller service deleted successfully"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # For enabling/disabling controller service
    def run_status(self,**kwargs):
        try:
            print("--- run_status of controller service methods ---")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'controller_service_name' not in kwargs or kwargs['controller_service_name'] is None:
                    return ({'status':'error','message':'controller service name is required'})
                else:
                    # Validating controller service name is valid or not
                    print("-- Validating controller service name ---")
                    response = process_group_helper.validate_name(request_for='controller_service', controller_service_name=kwargs['controller_service_name'])
                    print(response)
                    if response['status'] in ['error']:
                        return response
                    
                    run_status = 'DISABLED'
                    if 'run_status' in kwargs and kwargs['run_status'] in ['start']:
                        run_status = 'ENABLED'
                    elif 'run_status' in kwargs and kwargs['run_status'] in ['stop']:
                        run_status = 'DISABLED'
                    
                    # Preparing controller service key
                    if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_name'])+"_"+"data"
                    
                    url = self.base_url+'/controller-services/'+str(session[key]['id'])+"/run-status"
                    print("---- URL ----")
                    print(str(url))
                    data = {
                        "revision": { "clientId": session[key]['revision']['clientId'],"version": session[key]['revision']['version']},
                        "disconnectedNodeAcknowledged": False,
                        "state": run_status #"ENABLED"
                    }
                    print("---- data ----")
                    print(dumps(data))
                    resp = requests.put(url, data=dumps(data), headers=self.headers)
                    resp = resp.json()

                    print("---- After run status call ----")
                    # Basically enabling or disabling controller service take few seconds that why checking whether given run_status is updated in the session state
                    while True:
                        fetch_resp = self.fetch(controller_service_name=kwargs['controller_service_name'],
                                                controller_service_key=kwargs['controller_service_key'])
                        
                        if fetch_resp['status'] in ['success']:
                            print("status of fetch "+str(fetch_resp['data']['status'])+" run_status "+str(run_status))
                            if fetch_resp['data']['status']['runStatus'] == run_status:
                                break
                        
                        # Delaying for 2 seconds to know whether information given by user is valid or not
                        time.sleep(2)
                    print("--- After while loop ----")
                    session[key] = {
                        "id":resp['id'],
                        "status":resp['status'],
                        "revision":resp['revision'],
                        "component": resp['component']
                    }
                    return ({'status':'success','resp':session[key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # For fetching controller service details
    def fetch(self,**kwargs):
        try:
            print("---- Inisde fetch controller service details ----")
            if self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'controller_service_name' not in kwargs or kwargs['controller_service_name'] is None:
                    return ({'status':'error','message':'controller service name is required'})
                else:
                    # Validating controller service name is valid or not
                    print("--- Validating controller name ----")
                    response = process_group_helper.validate_name(request_for='controller_service', controller_service_name=kwargs['controller_service_name'])
                    if response['status'] in ['error']:
                        return response
                    
                    # Preparing controller service key
                    if 'controller_service_key' in kwargs and kwargs['controller_service_key'] is not None: # Generating Random Key
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_key'])+"_data"
                    else: # Generating Key Based on Group Name
                        key = str(self.catalog_key)+"_"+str(self.project_key)+"_controller_service_"+str(kwargs['controller_service_name'])+"_"+"data"
                    
                    url = self.base_url+'/controller-services/'+str(session[key]['id'])
                    print("--- URL ---")
                    print(url)
                    resp = requests.get(url, headers=self.headers)
                    resp = resp.json()
                    session[key] = {
                            "id":resp['id'],
                            "status":resp['status'],
                            "revision":resp['revision'],
                            "component": resp['component']
                        }
                    return ({'status':'success','data':session[key]})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})