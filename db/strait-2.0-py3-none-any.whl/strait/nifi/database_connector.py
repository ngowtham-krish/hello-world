import nipyapi, requests, time
from os import environ, path, remove
from flask import session
from datetime import datetime
from json import loads, dumps
from base64 import b64encode, b64decode
from simplecrypt import encrypt, decrypt
import strait.nifi.processor as processor
import strait.nifi.connection as connection
import strait.nifi.process_group as process_group
import strait.core.datasource as datasource
import strait.nifi.controller_service as controller_service
import strait.nifi.helper.process_group_helper as process_group_helper
from strait.nifi.model.schema import DatabaseConnectorSchema
#from strait.environment import load_env

# Initializing Environment
#load_env()

class DatabaseConnector:

    def __init__(self, **kwargs):
        self.catalog_key = None
        self.project_key = None
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        
        if 'parent_group_id' in kwargs and kwargs['parent_group_id'] is not None:
            self.parent_group_id = kwargs['parent_group_id']
        else:
            self.parent_group_id = nipyapi.canvas.get_root_pg_id()
        
        self.connector_schema = DatabaseConnectorSchema

    # Validate connection is valid or not
    def validate_connection(self,**kwargs):
        try:
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_lists_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])

                # Random Key for Mulit user and for same processor created multiple times in a process group
                process_group_key       = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key  = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                
                # Flow for Fetching Table Schema
                fetching_database_name_execute_sql = 'fetching_database_name_execute_sql_'+str(process_group_helper.random_string(8))
                
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_lists_from_mysql','fetch_table_lists_from_postgres','fetch_table_lists_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']
                    
                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no = port_no,
                                                                            database_name = database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Creating ExecuteSQL Processor
                    print(" Creating processor name ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key,
                                                                process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='execute_sql',
                                                                processor_key=fetching_database_name_execute_sql)
                    if processor_resp['status'] in ['error']:
                        return processor_resp

                    # Validating Database
                    print(" Validating Database ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    validation_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key,
                                                                process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='execute_sql',
                                                                processor_key=fetching_database_name_execute_sql,
                                                                database_name = database_name,
                                                                query_type="fetching_table_lists",
                                                                skip_database_validation="no",
                                                                relationships=['failure','success'])
                    
                    '''
                    # Disbaling controller service
                    print(" Disbaling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            run_status='stop')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    '''

                    # Deleting Controller Service
                    print(" Deleting Controller Service ")
                    controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                            project_key=self.project_key, 
                                                            controller_service_name= kwargs['controller_service_name'],
                                                            controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Deleting ExecuteSQL Processor
                    print(" Deleting ExecuteSQL processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.delete(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,  
                                                          processor_name='execute_sql',
                                                          processor_key=fetching_database_name_execute_sql)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Creating Process Group
                    print(" Deleting Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key)
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp
                    
                    if validation_resp['status'] in ['success']:
                        return ({'status':'success','message':'connection is valid'})
                    else:
                        return ({'status':'error','message':'connection is invalid'})

        except Exception as e:
            return ({'status': 'error', 'message': str(e)})     

    # Fetching database name
    def fetch_database_name(self,**kwargs):
        try:
            print("----- Inside fetch_database_name methods -----")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_database_name_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                print("--- process_group_name ----")
                print(kwargs['process_group_name'])

                print("--- controller_service_name ----")
                print(kwargs['controller_service_name'])
                
                # Random Key for Mulit user and for same processor created multiple times in a process group
                process_group_key       = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key  = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                
                # Flow for Fetching Table Schema
                fetching_database_name_execute_sql           = 'fetching_database_name_execute_sql_'+str(process_group_helper.random_string(8))
                fetching_database_name_convert_avro_to_json  = 'fetching_database_name_convert_avro_to_json_'+str(process_group_helper.random_string(8))
                fetching_database_name_update_attribute      = 'fetching_database_name_update_attribute_'+str(process_group_helper.random_string(8))
                fetching_database_name_put_file              = 'fetching_database_name_put_file_'+str(process_group_helper.random_string(8))
                
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_database_name_from_mysql','fetch_database_name_from_postgres','fetch_database_name_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']
                    
                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ",connection_url)
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Creating ExecuteSQL Processor
                    print(" Creating ExecuteSQL processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                            controller_service_key=controller_service_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='execute_sql',
                                                            processor_key=fetching_database_name_execute_sql)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Updating ExecuteSQL Processor
                    print(" Updating ExecuteSQL processor ")
                    skip_database_validation = 'no'
                    if 'skip_database_validation' in kwargs and kwargs['skip_database_validation'] is not None and kwargs['skip_database_validation'].lower() in ['yes']:
                        skip_database_validation = 'yes'

                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                            controller_service_key=controller_service_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='execute_sql',
                                                            query_type="fetching_table_schema",
                                                            processor_key=fetching_database_name_execute_sql,
                                                            skip_database_validation=skip_database_validation,
                                                            database_name=database_name,
                                                            relationships=['failure'])
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Creating AVRO to JSON Processor
                    print(" Creating AVRO to JSON processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name='convert_avro_to_json',
                                                        processor_key=fetching_database_name_convert_avro_to_json)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Updating AVRO to JSON Processor
                    print(" Updating AVRO to JSON Processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name='convert_avro_to_json',
                                                        processor_key=fetching_database_name_convert_avro_to_json)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Create Update Attribute Processor
                    print(" Creating Update Attribute processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name='update_attribute',
                                                        processor_key=fetching_database_name_update_attribute)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    timestamp = int(round(time.time() * 1000))
                    # Preparing the filename
                    #str(self.catalog_key)+"_"+str(self.project_key)+"_"+
                    filename = str(kwargs['process_group_name'])+"_"+str(timestamp)+".json"

                    # Updating Update Attribute Processor
                    print(" Updating Update Attribute processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name='update_attribute',
                                                        processor_key=fetching_database_name_update_attribute,
                                                        relationships=['failure'],
                                                        filename=filename)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Create Put File Processor
                    print(" Creating Put File processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='put_file',
                                                            processor_key=fetching_database_name_put_file)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Creating file path for NiFi
                    print(" Generating File Path ")
                    path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                    if path_resp['status'] in ['error']:
                        return path_resp
                    print("File path "+str(path_resp))

                    # Updating Put File Processor
                    print(" Updating Put File processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='put_file',
                                                            processor_key=fetching_database_name_put_file,
                                                            file_path=path_resp['file_path'])
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Establishing Connection between ExecuteSQL & AVRO_JSON Processor
                    print(" Establishing Connection between ExecuteSQL & AVRO_JSON Processor ")
                    connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                    connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name='execute_sql',
                                                            destination_processor_name='convert_avro_to_json',
                                                            source_processor_key=fetching_database_name_execute_sql,
                                                            destination_processor_key=fetching_database_name_convert_avro_to_json,
                                                            relationship="success")
                    if connection_resp['status'] in ['error']:
                        return connection_resp
                    
                    # Establishing Connection between AVRO_JSON & Update Attribute Processor
                    print(" Establishing Connection between AVRO_JSON & Update Attribute Processor ")
                    connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                    connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name='convert_avro_to_json',
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=fetching_database_name_convert_avro_to_json,
                                                            destination_processor_key=fetching_database_name_update_attribute,
                                                            relationship="success")
                    if connection_resp['status'] in ['error']:
                        return connection_resp
                    
                    # Establishing Connection between Update Attribute & Put File Processor
                    print(" Establishing Connection between Update Attribute & Put File Processor ")
                    connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                    connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name='update_attribute',
                                                            destination_processor_name='put_file',
                                                            source_processor_key=fetching_database_name_update_attribute,
                                                            destination_processor_key=fetching_database_name_put_file,
                                                            relationship="success")
                    if connection_resp['status'] in ['error']:
                        return connection_resp
                    
                    # Running the Processor group
                    print(" Starting the Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                        process_group_key=process_group_key,
                                                                        run_status='start')
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp
                    
                    # Delaying for 3 seconds to know whether information given by user is valid or not
                    #time.sleep(3)

                    # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                    source_file_path = path.join(path_resp['file_path'], filename)
                    counter = 0
                    while True:
                        #if counter < 20:
                        print(" Validating flow "+str(counter))
                        print("Putting 2 second delay")
                        time.sleep(2)
                        processor_resp = process_group_helper.validating_flow(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_key=fetching_database_name_execute_sql,
                                                                    processor_name='execute_sql',
                                                                    run_status='STOPPED',
                                                                    request_from='stop_process_group',
                                                                    headers={'content-type': 'application/json'},
                                                                    base_url=environ.get('NIFI_URL',None)
                                                                )
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        counter += 1
                        if path.exists(source_file_path):
                            break

                    # Running the Processor group
                    print(" Stopping the Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                        process_group_key=process_group_key,
                                                                        run_status='stop')
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp

                    # Deleting Controller Service
                    print(" Deleting Controller Service ")
                    controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                            project_key=self.project_key, 
                                                            controller_service_name= kwargs['controller_service_name'],
                                                            controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Deleting ExecuteSQL Processor
                    print(" Deleting ExecuteSQL processor ")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                        project_key=self.project_key,
                                                        process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name="execute_sql",
                                                        processor_key=fetching_database_name_execute_sql,
                                                        source_processor_name='execute_sql',
                                                        destination_processor_name='convert_avro_to_json',
                                                        source_processor_key=fetching_database_name_execute_sql,
                                                        destination_processor_key=fetching_database_name_convert_avro_to_json)
                    if processor_resp['status'] in ['error']:
                        return processor_resp

                    # Deleting AVROToJSON Processor
                    print("Deleting AVROToJSON Processor")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                        project_key=self.project_key,
                                                        process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name="convert_avro_to_json",
                                                        processor_key=fetching_database_name_convert_avro_to_json,
                                                        source_processor_name='convert_avro_to_json',
                                                        destination_processor_name='update_attribute',
                                                        source_processor_key=fetching_database_name_convert_avro_to_json,
                                                        destination_processor_key=fetching_database_name_update_attribute)
                    if processor_resp['status'] in ['error']:
                        return processor_resp

                    # Deleting Update Attribute Processor
                    print("Deleting Update Attribute Processor")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                        project_key=self.project_key,
                                                        process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name="update_attribute",
                                                        processor_key=fetching_database_name_update_attribute,
                                                        source_processor_name='update_attribute',
                                                        destination_processor_name='put_file',
                                                        source_processor_key=fetching_database_name_update_attribute,
                                                        destination_processor_key=fetching_database_name_put_file)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Deleting Put File Processor
                    print("Deleting Put File Processor")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="put_file",
                                                            processor_key=fetching_database_name_put_file)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                                    
                    # Creating Process Group
                    print(" Deleting Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key)
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp
                    
                    print("----- File Content ----")
                    # Checking whether Table is empty or it has some data
                    source_file_path = path.join(path_resp['file_path'], filename)
                    file_data = open(source_file_path,'r')
                    file_content = file_data.read()
                    file_data.close()
                    file_content = loads(file_content)
                    print(file_content)
                    if len(file_content)!=0:
                        database_names = []
                        if kwargs['process_group_name'] in ['fetch_database_name_from_mysql']:
                            for item in file_content:
                                database_names.append(item['Database'])
                        elif kwargs['process_group_name'] in ['fetch_database_name_from_postgres']:
                            for item in file_content:
                                database_names.append(item['datname'])
                        return ({'status':'success','database_list':database_names})
                    else:
                        return ({'status':'error','message':'Database connection is invalid'})
                else:
                    return ({'status':'error','message':'Process group name is invalid'})
            
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # List the Table Lists
    def fetch_table_lists(self,**kwargs):
        try:
            print("--- Inside fetch_table_lists methods -------")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_lists_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                # Random Key
                process_group_key = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                execute_sql = 'execute_sql_'+str(process_group_helper.random_string(8))
                convert_avro_to_json = 'convert_avro_to_json_'+str(process_group_helper.random_string(8))
                update_attribute = 'update_attribute_'+str(process_group_helper.random_string(8))
                put_file = 'put_file_'+str(process_group_helper.random_string(8))
                
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                             process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_lists_from_mysql','fetch_table_lists_from_postgres','fetch_table_lists_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']
                    
                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key,
                                                                        controller_service_name=kwargs['controller_service_name'],
                                                                        controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key= controller_service_key,
                                                                            process_group_name= kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Creating ExecuteSQL Processor
                    print(" Creating ExecuteSQL processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                        controller_service_key= controller_service_key,
                                                        process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name='execute_sql',
                                                        processor_key=execute_sql)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Updating ExecuteSQL Processor
                    print(" Updating ExecuteSQL processor ")
                    skip_database_validation = 'no'
                    if 'skip_database_validation' in kwargs and kwargs['skip_database_validation'] is not None and kwargs['skip_database_validation'].lower() in ['yes']:
                        skip_database_validation = 'yes'

                    print("skip_database_validation inside table_lists "+str(skip_database_validation))
                    
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                        controller_service_key= controller_service_key,
                                                        process_group_name=kwargs['process_group_name'],
                                                        process_group_key=process_group_key,
                                                        processor_name='execute_sql',
                                                        processor_key=execute_sql,
                                                        query_type="fetching_table_lists",
                                                        skip_database_validation=skip_database_validation,
                                                        database_name=database_name)
                    if processor_resp['status'] in ['error']:
                        return processor_resp

                    # Creating AVRO to JSON Processor
                    print(" Creating AVRO to JSON processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,
                                                          processor_name='convert_avro_to_json',
                                                          processor_key=convert_avro_to_json)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Updating AVRO to JSON Processor
                    print(" Updating AVRO to JSON Processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,
                                                          processor_name='convert_avro_to_json',
                                                          processor_key=convert_avro_to_json)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Create Update Attribute Processor
                    print(" Creating Update Attribute processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,  
                                                          processor_name='update_attribute',
                                                          processor_key=update_attribute)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Preparing the filename
                    timestamp = int(round(time.time() * 1000))
                    # str(self.catalog_key)+"_"+str(self.project_key)+"_"+
                    filename = str(database_name)+"_"+str(kwargs['process_group_name'])+"_"+str(timestamp)+".json"
                    
                    # Updating Update Attribute Processor
                    print(" Updating Update Attribute processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,
                                                          processor_name='update_attribute',
                                                          processor_key=update_attribute,
                                                          filename=filename)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Create Put File Processor
                    print(" Creating Put File processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,
                                                          processor_name='put_file',
                                                          processor_key=put_file)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Creating file path for NiFi
                    path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                    if path_resp['status'] in ['error']:
                        return path_resp
                    print("File path "+str(path_resp))

                    # Updating Put File Processor
                    print(" Updating Put File processor ")
                    processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                    processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,
                                                          processor_name='put_file',
                                                          processor_key=put_file,
                                                          file_path=path_resp['file_path'])
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Establishing Connection between ExecuteSQL & AVRO_JSON Processor
                    print(" Establishing Connection between ExecuteSQL & AVRO_JSON Processor ")
                    connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                    connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,  
                                                          source_processor_name='execute_sql',
                                                          source_processor_key=execute_sql,
                                                          destination_processor_name='convert_avro_to_json',
                                                          destination_processor_key=convert_avro_to_json,
                                                          relationship="success")
                    if connection_resp['status'] in ['error']:
                        return connection_resp
                    
                    # Establishing Connection between AVRO_JSON & Update Attribute Processor
                    print(" Establishing Connection between AVRO_JSON & Update Attribute Processor ")
                    connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                    connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,  
                                                          source_processor_name='convert_avro_to_json',
                                                          source_processor_key=convert_avro_to_json,
                                                          destination_processor_name='update_attribute',
                                                          destination_processor_key=update_attribute,
                                                          relationship="success")
                    if connection_resp['status'] in ['error']:
                        return connection_resp
                    
                    # Establishing Connection between Update Attribute & Put File Processor
                    print(" Establishing Connection between Update Attribute & Put File Processor ")
                    connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                    connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                          process_group_key=process_group_key,
                                                          source_processor_name='update_attribute',
                                                          source_processor_key=update_attribute,
                                                          destination_processor_name='put_file',
                                                          destination_processor_key=put_file,
                                                          relationship="success")
                    if connection_resp['status'] in ['error']:
                        return connection_resp
                    
                    # Running the Processor group
                    print(" Starting the Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'],
                                                                     process_group_key=process_group_key,
                                                                     run_status='start')
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp
                    
                    # Delaying for 3 seconds to know whether information given by user is valid or not
                    #time.sleep(3)

                    # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                    source_file_path = path.join(path_resp['file_path'], filename)
                    while True:
                        if path.exists(source_file_path):
                            break

                    # Running the Processor group
                    print(" Stopping the Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                      process_group_key=process_group_key,
                                                                      run_status='stop')
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp
                    
                    # Deleting Controller Service
                    print(" Deleting Controller Service ")
                    controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                                 project_key=self.project_key, 
                                                                                 controller_service_key= controller_service_key,
                                                                                 controller_service_name= kwargs['controller_service_name'])
                    print(controller_service_resp)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Deleting ExecuteSQL Processor
                    print(" Deleting ExecuteSQL processor ")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                        project_key=self.project_key,
                                                                        process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key,
                                                                        processor_name="execute_sql",
                                                                        processor_key=execute_sql,
                                                                        source_processor_name='execute_sql',
                                                                        source_processor_key=execute_sql,
                                                                        destination_processor_name='convert_avro_to_json',
                                                                        destination_processor_key=convert_avro_to_json)
                    if processor_resp['status'] in ['error']:
                        return processor_resp

                    # Deleting AVROToJSON Processor
                    print("Deleting AVROToJSON Processor")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                        project_key=self.project_key,
                                                                        process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key,
                                                                        processor_name="convert_avro_to_json",
                                                                        processor_key=convert_avro_to_json,
                                                                        source_processor_name='convert_avro_to_json',
                                                                        source_processor_key=convert_avro_to_json,
                                                                        destination_processor_name='update_attribute',
                                                                        destination_processor_key=update_attribute)
                    if processor_resp['status'] in ['error']:
                        return processor_resp

                    # Deleting Update Attribute Processor
                    print("Deleting Update Attribute Processor")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                        project_key=self.project_key,
                                                                        process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key,
                                                                        processor_name="update_attribute",
                                                                        processor_key=update_attribute,
                                                                        source_processor_name='update_attribute',
                                                                        source_processor_key=update_attribute,
                                                                        destination_processor_name='put_file',
                                                                        destination_processor_key=put_file)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                    
                    # Deleting Put File Processor
                    print("Deleting Put File Processor")
                    processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                        project_key=self.project_key,
                                                                        process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key,
                                                                        processor_name="put_file",
                                                                        processor_key=put_file)
                    if processor_resp['status'] in ['error']:
                        return processor_resp
                                        
                    # Creating Process Group
                    print(" Deleting Process Group ")
                    process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                    project_key=self.project_key,
                                                                    parent_group_id=self.parent_group_id)
                    process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key)
                    #print(process_group_resp)
                    if process_group_resp['status'] in ['error']:
                        return process_group_resp
                    
                    # Reading the table lists
                    file_path = path_resp['file_path']
                    if filename is not None:
                        source_file_path = path.join(file_path, filename)
                        file_content = open(source_file_path,'r')
                        file_content = file_content.read()
                        file_content = loads(file_content)
                        print(file_content)
                        table_lists = []
                        if len(file_content)>0:
                            if kwargs['process_group_name'] in ['fetch_table_lists_from_mysql']:
                                key = "Tables_in_"+str(kwargs['database_name'])
                                for item in file_content:
                                    table_lists.append(item[key])
                            elif kwargs['process_group_name'] in ['fetch_table_lists_from_postgres']:
                                for item in file_content:
                                    table_lists.append(item['tablename'])
                            elif kwargs['process_group_name'] in ['fetch_table_lists_from_sqlite']:
                                for item in file_content:
                                    table_lists.append(item['name'])
                            
                        return ({'status':'success','data':table_lists})
                    else:
                        return ({'status':'error','message':'Some error occur while establishing connection'})
                    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})   

    # Fetching Table Count
    def fetch_table_row_count(self,**kwargs):
        try:
            print("--- Inside fetch_table_row_count methods ----")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_row_count_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                # Random Key for Mulit user and for same processor created multiple times in a process group
                process_group_key       = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key  = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                
                # Flow for Fetching Table Schema
                fetching_table_row_count_execute_sql           = 'fetching_table_row_count_execute_sql_'+str(process_group_helper.random_string(8))
                fetching_table_row_count_convert_avro_to_json  = 'fetching_table_row_count_convert_avro_to_json_'+str(process_group_helper.random_string(8))
                fetching_table_row_count_update_attribute      = 'fetching_table_row_count_update_attribute_'+str(process_group_helper.random_string(8))
                fetching_table_row_count_put_file              = 'fetching_table_row_count_put_file_'+str(process_group_helper.random_string(8))
                
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_row_count_from_mysql','fetch_table_row_count_from_postgres','fetch_table_row_count_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']
                    
                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password,
                                                                            validation_query="yes")
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    
                    if 'table_lists' in kwargs and kwargs['table_lists'] is not None and len(kwargs['table_lists'])>0:
                        # Creating ExecuteSQL Processor
                        print(" Creating ExecuteSQL processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                              controller_service_key=controller_service_key,
                                                              process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='execute_sql',
                                                              processor_key=fetching_table_row_count_execute_sql)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating AVRO to JSON Processor
                        print(" Creating AVRO to JSON processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='convert_avro_to_json',
                                                            processor_key=fetching_table_row_count_convert_avro_to_json)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Updating AVRO to JSON Processor
                        print(" Updating AVRO to JSON Processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='convert_avro_to_json',
                                                            processor_key=fetching_table_row_count_convert_avro_to_json)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Update Attribute Processor
                        print(" Creating Update Attribute processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='update_attribute',
                                                            processor_key=fetching_table_row_count_update_attribute)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Put File Processor
                        print(" Creating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='put_file',
                                                              processor_key=fetching_table_row_count_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating file path for NiFi
                        print(" Generating File Path ")
                        path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                        if path_resp['status'] in ['error']:
                            return path_resp
                        print("File path "+str(path_resp))

                        # Updating Put File Processor
                        print(" Updating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='put_file',
                                                                processor_key=fetching_table_row_count_put_file,
                                                                file_path=path_resp['file_path'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Establishing Connection between ExecuteSQL & AVRO_JSON Processor
                        print(" Establishing Connection between ExecuteSQL & AVRO_JSON Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='execute_sql',
                                                                destination_processor_name='convert_avro_to_json',
                                                                source_processor_key=fetching_table_row_count_execute_sql,
                                                                destination_processor_key=fetching_table_row_count_convert_avro_to_json,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between AVRO_JSON & Update Attribute Processor
                        print(" Establishing Connection between AVRO_JSON & Update Attribute Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='convert_avro_to_json',
                                                                destination_processor_name='update_attribute',
                                                                source_processor_key=fetching_table_row_count_convert_avro_to_json,
                                                                destination_processor_key=fetching_table_row_count_update_attribute,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between Update Attribute & Put File Processor
                        print(" Establishing Connection between Update Attribute & Put File Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='update_attribute',
                                                                destination_processor_name='put_file',
                                                                source_processor_key=fetching_table_row_count_update_attribute,
                                                                destination_processor_key=fetching_table_row_count_put_file,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        table_lists = kwargs['table_lists']
                        timestamp = int(round(time.time() * 1000))
                        file_names = []
                        for table_name in table_lists:
                            # Updating ExecuteSQL Processor
                            skip_database_validation = 'no'
                            if 'skip_database_validation' in kwargs and kwargs['skip_database_validation'] is not None and kwargs['skip_database_validation'].lower() in ['yes']:
                                skip_database_validation = 'yes'

                            print("skip_database_validation inside table_row_count "+str(skip_database_validation))
                            
                            print(" Updating ExecuteSQL processor ")
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name='execute_sql',
                                                                    query_type="fetching_table_row_count",
                                                                    processor_key=fetching_table_row_count_execute_sql,
                                                                    database_name=database_name,
                                                                    skip_database_validation=skip_database_validation,
                                                                    relationships=['failure'],
                                                                    table_name=table_name)
                            #print("--- Response from update ExecuteSQL ---")
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                            # Preparing the filename
                            #str(self.catalog_key)+"_"+str(self.project_key)+"_"+str(kwargs['process_group_name'])+"_"+
                            filename = str(database_name)+"_"+str(table_name)+"_row_count_"+str(timestamp)+".json"
                            print("---- filename ----")
                            print(filename)
                            file_names.append(filename)

                            # Updating Update Attribute Processor
                            print(" Updating Update Attribute processor ")
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='update_attribute',
                                                                processor_key=fetching_table_row_count_update_attribute,
                                                                relationships=['failure'],
                                                                filename=filename)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            
                            # Running the Processor group
                            print(" Starting the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='start')
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Delaying for 3 seconds to know whether information given by user is valid or not
                            #time.sleep(3)

                            # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                            source_file_path = path.join(path_resp['file_path'], filename)
                            #print("----- source_file_path -----")
                            #print(source_file_path)
                            while True:
                                if path.exists(source_file_path):
                                    break

                            # Running the Processor group
                            print(" Stopping the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='stop')
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Clearing the queue show that next table if any does not have previous table data
                            print(" Clearing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.clear_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name='execute_sql',
                                                                    destination_processor_name='convert_avro_to_json',
                                                                    source_processor_key=fetching_table_row_count_execute_sql,
                                                                    destination_processor_key=fetching_table_row_count_convert_avro_to_json)
                            print(processor_resp['status'])
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                        # Deleting ExecuteSQL Processor
                        print(" Deleting ExecuteSQL processor ")
                        processor_resp = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="execute_sql",
                                                            processor_key=fetching_table_row_count_execute_sql,
                                                            source_processor_name='execute_sql',
                                                            destination_processor_name='convert_avro_to_json',
                                                            source_processor_key=fetching_table_row_count_execute_sql,
                                                            destination_processor_key=fetching_table_row_count_convert_avro_to_json)
                        print(processor_resp['status'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Controller Service
                        print(" Deleting Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key)
                        print(controller_service_resp['status'])
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp
                        
                        # Deleting AVROToJSON Processor
                        print("Deleting AVROToJSON Processor")
                        processor_resp = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="convert_avro_to_json",
                                                            processor_key=fetching_table_row_count_convert_avro_to_json,
                                                            source_processor_name='convert_avro_to_json',
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=fetching_table_row_count_convert_avro_to_json,
                                                            destination_processor_key=fetching_table_row_count_update_attribute)
                        print(processor_resp['status'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Update Attribute Processor
                        print("Deleting Update Attribute Processor")
                        processor_resp = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="update_attribute",
                                                            processor_key=fetching_table_row_count_update_attribute,
                                                            source_processor_name='update_attribute',
                                                            destination_processor_name='put_file',
                                                            source_processor_key=fetching_table_row_count_update_attribute,
                                                            destination_processor_key=fetching_table_row_count_put_file)
                        print(processor_resp['status'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Deleting Put File Processor
                        print("Deleting Put File Processor")
                        processor_resp = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                project_key=self.project_key,
                                                                process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name="put_file",
                                                                processor_key=fetching_table_row_count_put_file)
                        print(processor_resp['status'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                                            
                        # Creating Process Group
                        print(" Deleting Process Group ")
                        process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                        project_key=self.project_key,
                                                                        parent_group_id=self.parent_group_id)
                        process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key)
                        print(process_group_resp['status'])
                        if process_group_resp['status'] in ['error']:
                            return process_group_resp
                        
                        print("----- File Content ----")
                        row_count = {}
                        if len(file_names)>0:
                            i = 0
                            for filename in file_names:
                                # Checking whether Table is empty or it has some data
                                source_file_path = path.join(path_resp['file_path'], filename)
                                if path.exists(source_file_path): # If Path Exists May be Table has some data
                                    file_data = open(source_file_path,'r')
                                    file_content = file_data.read()
                                    file_data.close()
                                    file_content = loads(file_content)
                                    print(file_content)
                                    if len(file_content)!=0:
                                        if kwargs['process_group_name'] in ['fetch_table_row_count_from_mysql','fetch_table_row_count_from_postgres']:
                                            if 'count' in file_content:
                                                row_count[table_lists[i]] = file_content['count']
                                        #elif kwargs['process_group_name'] in ['fetch_table_row_count_from_postgres']:
                                        #    pass
                                        elif kwargs['process_group_name'] in ['fetch_table_row_count_from_sqlite']:
                                            pass
                                    remove(source_file_path)
                                else: # Table is Empty
                                    return ({'status':"error",'message':'Table/Database name is invalid or does not exists'})
                                i = i + 1
                                
                        return ({'status':'success','row_count':row_count})
                    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # Fetching table schema
    def fetch_table_schema(self,**kwargs):
        try:
            print("---- Inside fetch_table_schema methods ------")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_schema_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                # Random Key for Mulit user and for same processor created multiple times in a process group
                process_group_key       = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key  = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                
                # Flow for Fetching Table Schema
                fetching_table_schema_execute_sql           = 'fetching_table_schema_execute_sql_'+str(process_group_helper.random_string(8))
                fetching_table_schema_convert_avro_to_json  = 'fetching_table_schema_convert_avro_to_json_'+str(process_group_helper.random_string(8))
                fetching_table_schema_update_attribute      = 'fetching_table_schema_update_attribute_'+str(process_group_helper.random_string(8))
                fetching_table_schema_put_file              = 'fetching_table_schema_put_file_'+str(process_group_helper.random_string(8))
                
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_schema_from_mysql','fetch_table_schema_from_postgres','fetch_table_schema_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']
                    
                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ",connection_url)
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password,
                                                                            validation_query="yes")
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    if 'table_lists' in kwargs and kwargs['table_lists'] is not None and len(kwargs['table_lists'])>0:
                        # Creating ExecuteSQL Processor
                        print(" Creating ExecuteSQL processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                              controller_service_key=controller_service_key,
                                                              process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='execute_sql',
                                                              processor_key=fetching_table_schema_execute_sql)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating AVRO to JSON Processor
                        print(" Creating AVRO to JSON processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='convert_avro_to_json',
                                                            processor_key=fetching_table_schema_convert_avro_to_json)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Updating AVRO to JSON Processor
                        print(" Updating AVRO to JSON Processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='convert_avro_to_json',
                                                            processor_key=fetching_table_schema_convert_avro_to_json)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Update Attribute Processor
                        print(" Creating Update Attribute processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='update_attribute',
                                                            processor_key=fetching_table_schema_update_attribute)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Put File Processor
                        print(" Creating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='put_file',
                                                              processor_key=fetching_table_schema_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating file path for NiFi
                        print(" Generating File Path ")
                        path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                        if path_resp['status'] in ['error']:
                            return path_resp
                        print("File path "+str(path_resp))

                        # Updating Put File Processor
                        print(" Updating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='put_file',
                                                                processor_key=fetching_table_schema_put_file,
                                                                file_path=path_resp['file_path'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Establishing Connection between ExecuteSQL & AVRO_JSON Processor
                        print(" Establishing Connection between ExecuteSQL & AVRO_JSON Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='execute_sql',
                                                                destination_processor_name='convert_avro_to_json',
                                                                source_processor_key=fetching_table_schema_execute_sql,
                                                                destination_processor_key=fetching_table_schema_convert_avro_to_json,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between AVRO_JSON & Update Attribute Processor
                        print(" Establishing Connection between AVRO_JSON & Update Attribute Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='convert_avro_to_json',
                                                                destination_processor_name='update_attribute',
                                                                source_processor_key=fetching_table_schema_convert_avro_to_json,
                                                                destination_processor_key=fetching_table_schema_update_attribute,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between Update Attribute & Put File Processor
                        print(" Establishing Connection between Update Attribute & Put File Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='update_attribute',
                                                                destination_processor_name='put_file',
                                                                source_processor_key=fetching_table_schema_update_attribute,
                                                                destination_processor_key=fetching_table_schema_put_file,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        table_lists = kwargs['table_lists']
                        #file_path = []
                        file_names = []
                        timestamp = int(round(time.time() * 1000))
                        for table_name in table_lists:
                            # Updating ExecuteSQL Processor
                            print(" Updating ExecuteSQL processor ")
                            skip_database_validation = 'no'
                            if 'skip_database_validation' in kwargs and kwargs['skip_database_validation'] is not None and kwargs['skip_database_validation'].lower() in ['yes']:
                                skip_database_validation = 'yes'
                            
                            print("skip_database_validation inside table_schema "+str(skip_database_validation))

                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name='execute_sql',
                                                                    query_type="fetching_table_schema",
                                                                    processor_key=fetching_table_schema_execute_sql,
                                                                    skip_database_validation=skip_database_validation,
                                                                    database_name=database_name,
                                                                    relationships=['failure'],
                                                                    table_name=table_name)
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                            # Preparing the filename
                            #str(self.catalog_key)+"_"+str(self.project_key)+"_"+str(kwargs['process_group_name'])+"_"+
                            filename = str(database_name)+"_"+str(table_name)+"_schema_"+str(timestamp)+".json"
                            file_names.append(filename)

                            # Updating Update Attribute Processor
                            print(" Updating Update Attribute processor ")
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='update_attribute',
                                                                processor_key=fetching_table_schema_update_attribute,
                                                                relationships=['failure'],
                                                                filename=filename)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            
                            # Running the Processor group
                            print(" Starting the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='start')
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Delaying for 3 seconds to know whether information given by user is valid or not
                            #time.sleep(3)
                            # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                            source_file_path = path.join(path_resp['file_path'], filename)
                            while True:
                                if path.exists(source_file_path):
                                    break

                            # Running the Processor group
                            print(" Stopping the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='stop')
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Clearing the queue show that next table if any does not have previous table data
                            print(" Clearing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.clear_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name='execute_sql',
                                                                    destination_processor_name='convert_avro_to_json',
                                                                    source_processor_key=fetching_table_schema_execute_sql,
                                                                    destination_processor_key=fetching_table_schema_convert_avro_to_json)
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                        
                        # Deleting ExecuteSQL Processor
                        print(" Deleting ExecuteSQL processor ")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="execute_sql",
                                                            processor_key=fetching_table_schema_execute_sql,
                                                            source_processor_name='execute_sql',
                                                            destination_processor_name='convert_avro_to_json',
                                                            source_processor_key=fetching_table_schema_execute_sql,
                                                            destination_processor_key=fetching_table_schema_convert_avro_to_json)

                                                            
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Deleting Controller Service
                        print(" Deleting Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key)
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp
                        
                        # Deleting AVROToJSON Processor
                        print("Deleting AVROToJSON Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="convert_avro_to_json",
                                                            processor_key=fetching_table_schema_convert_avro_to_json,
                                                            source_processor_name='convert_avro_to_json',
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=fetching_table_schema_convert_avro_to_json,
                                                            destination_processor_key=fetching_table_schema_update_attribute)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Update Attribute Processor
                        print("Deleting Update Attribute Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="update_attribute",
                                                            processor_key=fetching_table_schema_update_attribute,
                                                            source_processor_name='update_attribute',
                                                            destination_processor_name='put_file',
                                                            source_processor_key=fetching_table_schema_update_attribute,
                                                            destination_processor_key=fetching_table_schema_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Deleting Put File Processor
                        print("Deleting Put File Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                project_key=self.project_key,
                                                                process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name="put_file",
                                                                processor_key=fetching_table_schema_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                                            
                        # Creating Process Group
                        print(" Deleting Process Group ")
                        process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                        project_key=self.project_key,
                                                                        parent_group_id=self.parent_group_id)
                        process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key)
                        if process_group_resp['status'] in ['error']:
                            return process_group_resp
                            
                        print("----- File Content ----")
                        schema_details = {}
                        i = 0
                        if len(file_names)>0:
                            for filename in file_names:
                                # Checking whether Table is empty or it has some data
                                source_file_path = path.join(path_resp['file_path'], filename)
                                #file_path.append(source_file_path)
                                file_data = open(source_file_path,'r')
                                file_content = file_data.read()
                                file_data.close()
                                file_content = loads(file_content)
                                print(file_content)
                                if len(file_content)!=0:
                                    schema_details[table_lists[i]] = filename
                                    table_schema = []
                                    if kwargs['process_group_name'] in ['fetch_table_schema_from_mysql']:
                                        for item in file_content:
                                            temp = {}
                                            temp['column_name'] = item['Field']
                                            temp['is_primary_key'] = "no"
                                            if 'Key' in item and item['Key'] is not None and item['Key'].strip()!='':
                                                temp['is_primary_key'] = "yes"
                                            if 'Type' in item and item['Type'] is not None and item['Type'].strip()!='':
                                                if item['Type'].find("(")!=-1:
                                                    data_type = item['Type'].replace("(","_")
                                                    data_type = data_type.replace(")","_")
                                                    data_type = data_type.split("_")
                                                    temp['data_type'] = data_type[0]
                                                    temp['length'] = data_type[1]
                                                else:
                                                    temp['data_type'] = item['Type']
                                                    temp['length'] = None
                                            if 'Null' in item and item['Null'] is not None and item['Null'].strip()!='':
                                                if item['Null'].strip() in ['YES','yes','Yes']:
                                                    temp['is_null'] = "yes"
                                                else:
                                                    temp['is_null'] = "no"
                                            table_schema.append(temp)
                                        file_data = open(source_file_path,'w')
                                        file_data.write(dumps(table_schema))
                                        file_data.close()
                                    elif kwargs['process_group_name'] in ['fetch_table_schema_from_postgres']:
                                        for item in file_content:
                                            temp = {}
                                            temp['column_name'] = item['column_name']
                                            temp['data_type'] = item['data_type']
                                            temp['length'] = item['character_maximum_length']
                                            if 'is_nullable' in item and item['is_nullable'] is not None and item['is_nullable'].strip()!='':
                                                if item['is_nullable'].strip() in ['YES','yes','Yes']:
                                                    temp['is_null'] = "yes"
                                                else:
                                                    temp['is_null'] = "no"
                                            table_schema.append(temp)
                                        file_data = open(source_file_path,'w')
                                        file_data.write(dumps(table_schema))
                                        file_data.close()
                                    elif kwargs['process_group_name'] in ['fetch_table_schema_from_sqlite']:
                                        pass
                                i = i + 1
                    else:
                        return ({'status': 'error', 'message': "Table name is required"})
                    
                    if 'ret_file_path' in kwargs and kwargs['ret_file_path'] is not None and kwargs['ret_file_path'].lower() in ['yes']:
                        return ({'status':"success",'message':'Updated successfully','file_names':schema_details})
                    else:    
                        return ({'status':"success",'message':'Updated successfully'})
                else:
                    return ({'status': 'error', 'message': "Processor group name is invalid"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    # Storing the table content (1st Method of fetching Table Data)
    def store_table_details(self,**kwargs):
        try:
            print("---- Inside store_table_details methods ------")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_details_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                # Random Key for Mulit user and for same processor created multiple times in a process group
                process_group_key                         = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key                    = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                fetching_table_data_execute_sql           = 'fetching_table_data_execute_sql_'+str(process_group_helper.random_string(8))
                fetching_table_data_convert_avro_to_json  = 'fetching_table_data_convert_avro_to_json_'+str(process_group_helper.random_string(8))
                fetching_table_data_convert_avro_to_parquet = 'fetching_table_data_convert_avro_to_parquet_'+str(process_group_helper.random_string(8))
                fetching_table_data_update_attribute      = 'fetching_table_data_update_attribute_'+str(process_group_helper.random_string(8))
                fetching_table_data_put_file              = 'fetching_table_data_put_file_'+str(process_group_helper.random_string(8))
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                print("process_group_name "+kwargs['process_group_name'])
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_details_from_mysql','fetch_table_details_from_postgres','fetch_table_details_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']

                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    if 'table_lists' in kwargs and kwargs['table_lists'] is not None and len(kwargs['table_lists'])>0:
                        # Creating ExecuteSQL Processor
                        print(" Creating ExecuteSQL processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                              controller_service_key=controller_service_key,
                                                              process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='execute_sql',
                                                              processor_key=fetching_table_data_execute_sql)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # AVRO To JSON/Parquet
                        if 'avro_to' in kwargs and kwargs['avro_to'] is not None and kwargs['avro_to'] in ['json']:
                            avro_to_processor_name = 'convert_avro_to_json'
                            avro_to_processor_key  = fetching_table_data_convert_avro_to_json
                            file_extension = "json"
                        else:
                            avro_to_processor_name = 'convert_avro_to_parquet'
                            avro_to_processor_key  = fetching_table_data_convert_avro_to_parquet
                            file_extension = "parquet"
                        
                        print("----- avro_to_processor_key -----")
                        print(avro_to_processor_key)
                        print("----- avro_to_processor_name -----")
                        print(avro_to_processor_name)
                        
                        # Creating AVRO to JSON Processor
                        print(" Creating AVRO to JSON processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=avro_to_processor_name,
                                                            processor_key=avro_to_processor_key)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Updating AVRO to JSON Processor
                        print(" Updating AVRO to JSON Processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=avro_to_processor_name,
                                                            processor_key=avro_to_processor_key)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Update Attribute Processor
                        print(" Creating Update Attribute processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='update_attribute',
                                                            processor_key=fetching_table_data_update_attribute)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Put File Processor
                        print(" Creating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='put_file',
                                                              processor_key=fetching_table_data_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating file path for NiFi
                        print(" Generating File Path ")
                        path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                        if path_resp['status'] in ['error']:
                            return path_resp
                        print("File path "+str(path_resp))

                        # Updating Put File Processor
                        print(" Updating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='put_file',
                                                            processor_key=fetching_table_data_put_file,
                                                            file_path=path_resp['file_path'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Establishing Connection between ExecuteSQL & AVRO_JSON Processor
                        print(" Establishing Connection between ExecuteSQL & AVRO_JSON Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name='execute_sql',
                                                            destination_processor_name=avro_to_processor_name,
                                                            source_processor_key=fetching_table_data_execute_sql,
                                                            destination_processor_key=avro_to_processor_key,
                                                            relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between AVRO_JSON & Update Attribute Processor
                        print(" Establishing Connection between AVRO_JSON & Update Attribute Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name=avro_to_processor_name,
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=avro_to_processor_key,
                                                            destination_processor_key=fetching_table_data_update_attribute,
                                                            relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                    
                        # Establishing Connection between Update Attribute & Put File Processor
                        print(" Establishing Connection between Update Attribute & Put File Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='update_attribute',
                                                                destination_processor_name='put_file',
                                                                source_processor_key=fetching_table_data_update_attribute,
                                                                destination_processor_key=fetching_table_data_put_file,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        table_lists = kwargs['table_lists']
                        file_path = []
                        file_name_lists = []
                        table_info = []

                        # Checking whether table has data or empty by count of the table
                        table_row_counts = self.fetch_table_row_count(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                database_type=kwargs['database_type'], 
                                                                connection_url=kwargs['connection_url'],
                                                                port_no=kwargs['port_no'],
                                                                user_name=kwargs['user_name'],
                                                                password = kwargs['password'],
                                                                database_name = kwargs['database_name'],
                                                                table_lists= table_lists,
                                                                skip_database_validation = "no",
                                                                ret_file_path="yes")
                        
                        if table_row_counts['status'] in ['error']:
                            return table_row_counts
                        
                        table_row_counts = table_row_counts['row_count']
                        table_not_uploaded = []
                        table_uploaded = []
                        if len(table_row_counts)>0:
                            for table_name in table_lists:
                                if int(table_row_counts[table_name])==0:
                                    table_not_uploaded.append(table_name)
                                else:
                                    table_uploaded.append(table_name)
                        
                        table_lists = table_uploaded

                        # Fetching Table Schema because few Data type is not supported by AVRO such as BIGINT to handle it converting it to varchar/char
                        table_schema = self.fetch_table_schema(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                database_type=kwargs['database_type'], 
                                                                connection_url=kwargs['connection_url'],
                                                                port_no=kwargs['port_no'],
                                                                user_name=kwargs['user_name'],
                                                                password = kwargs['password'],
                                                                database_name = kwargs['database_name'],
                                                                skip_database_validation = "yes",
                                                                table_lists= table_lists,
                                                                ret_file_path="yes")
                        
                        if table_schema['status'] in ['error']:
                            return table_schema
                        table_schema = table_schema['file_names']

                        for table_name in table_lists:
                            timestamp = int(round(time.time() * 1000))
                            
                            # Preparing Query
                            query = None
                            if len(table_schema)>0:
                                temp_path = path.join(path_resp['file_path'],table_schema[table_name])
                                file_data = open(temp_path,'r')
                                file_content = file_data.read()
                                file_data.close()
                                file_content = loads(file_content)
                                print(file_content)
                                if len(file_content)>0:
                                    i = 1
                                    default_length = 100
                                    query = "select "
                                    if kwargs['process_group_name'] in ['fetch_table_details_from_mysql']:
                                        for item in file_content:
                                            #select CAST(id as char(50)) as id, CAST(salary as char(50)) as salary, CAST(emp_id as char(50)) as emp_id from salary;
                                            if 'length' in item and item['length'] is not None:
                                                temp_query = " cast("+str(item['column_name'])+" as char("+str(item['length'])+")) as "+ str(item['column_name'])
                                            else:
                                                temp_query = " cast("+str(item['column_name'])+" as char("+str(default_length)+")) as "+ str(item['column_name'])
                                            
                                            if i != len(file_content):
                                                temp_query = temp_query + ", "
                                    
                                            i = i + 1
                                            query = query + temp_query

                                        query = query + " from "+str(table_name)
                                    elif kwargs['process_group_name'] in ['fetch_table_details_from_postgres']:
                                        for item in file_content:
                                            #select CAST(id as char(50)) as id, CAST(salary as char(50)) as salary, CAST(emp_id as char(50)) as emp_id from salary;
                                            if 'length' in item and item['length'] is not None:
                                                temp_query = " cast("+str(item['column_name'])+" as varchar("+str(item['length'])+")) as "+ str(item['column_name'])
                                            else:
                                                temp_query = " cast("+str(item['column_name'])+" as varchar("+str(default_length)+")) as "+ str(item['column_name'])
                                            
                                            if i != len(file_content):
                                                temp_query = temp_query + ", "
                                    
                                            i = i + 1
                                            query = query + temp_query

                                        query = query + " from "+str(table_name)
                                    print("------query-------")
                                    print(query)
                                    
                            # Updating ExecuteSQL Processor
                            print(" Updating ExecuteSQL processor "+str(table_name))
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name='execute_sql',
                                                                    query_type="fetching_table_data",
                                                                    query=query,
                                                                    processor_key=fetching_table_data_execute_sql,
                                                                    database_name=database_name,
                                                                    skip_database_validation = "yes",
                                                                    relationships=['failure'],
                                                                    table_name=table_name)
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                            # Preparing the filename
                            # str(self.catalog_key)+"_"+str(self.project_key)+"_"+str(kwargs['process_group_name'])+"_"+
                            filename = str(database_name)+"_"+str(table_name)+"_"+str(timestamp)+"."+str(file_extension)
                            file_name_lists.append(filename)

                            # Updating Update Attribute Processor
                            print(" Updating Update Attribute processor ")
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='update_attribute',
                                                                processor_key=fetching_table_data_update_attribute,
                                                                relationships=['failure'],
                                                                filename=filename)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            
                            # Running the Processor group
                            print(" Starting the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='start')
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Delaying for 5 seconds to know whether information given by user is valid or not
                            #time.sleep(5)
                            
                            # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                            source_file_path = path.join(path_resp['file_path'], filename)
                            while True:
                                if path.exists(source_file_path):
                                    break

                            # Running the Processor group
                            print(" Stopping the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='stop')
                            #print(process_group_resp)
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Clearing the queue show that next table if any does not have previous table data
                            print(" Clearing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.clear_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name='execute_sql',
                                                                    destination_processor_name=avro_to_processor_name,
                                                                    source_processor_key=fetching_table_data_execute_sql,
                                                                    destination_processor_key=avro_to_processor_key)

                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                            temp = {
                                'schema': table_schema[table_name],
                                'data': filename
                            }
                            table_info.append(temp)

                            print("----- table_info ------")
                            print(table_info)
                        
                        # Deleting ExecuteSQL Processor
                        print(" Deleting ExecuteSQL processor ")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="execute_sql",
                                                            processor_key=fetching_table_data_execute_sql,
                                                            source_processor_name='execute_sql',
                                                            destination_processor_name=avro_to_processor_name,
                                                            source_processor_key=fetching_table_data_execute_sql,
                                                            destination_processor_key=avro_to_processor_key)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Controller Service
                        print(" Deleting Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key)
                        #print(controller_service_resp)
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp
                        
                        # Deleting AVROToJSON Processor
                        print("Deleting AVROToJSON Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=avro_to_processor_name,
                                                            processor_key=avro_to_processor_key,
                                                            source_processor_name=avro_to_processor_name,
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=avro_to_processor_key,
                                                            destination_processor_key=fetching_table_data_update_attribute)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Update Attribute Processor
                        print("Deleting Update Attribute Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="update_attribute",
                                                            processor_key=fetching_table_data_update_attribute,
                                                            source_processor_name='update_attribute',
                                                            destination_processor_name='put_file',
                                                            source_processor_key=fetching_table_data_update_attribute,
                                                            destination_processor_key=fetching_table_data_put_file)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Deleting Put File Processor
                        print("Deleting Put File Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                            project_key=self.project_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            processor_name="put_file",
                                                                            processor_key=fetching_table_data_put_file)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                                            
                        # Creating Process Group
                        print(" Deleting Process Group ")
                        process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                        project_key=self.project_key,
                                                                        parent_group_id=self.parent_group_id)
                        process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key)
                        #print(process_group_resp)
                        if process_group_resp['status'] in ['error']:
                            return process_group_resp
                        
                        source_file_path = None
                        message = 'Updated successfully'
                        status = "success"

                        if len(table_uploaded)>0 and len(table_not_uploaded)>0:
                            #table_uploaded = ','.join(table_uploaded)
                            #table_not_uploaded = ','.join(table_not_uploaded)
                            message = 'Table '+str(','.join(table_uploaded))+" imported successfully. Cannot import empty "+str(','.join(table_not_uploaded))+' table'
                            status = 'error'
                        elif len(table_not_uploaded)>0:
                            #table_not_uploaded = ','.join(table_not_uploaded)
                            message = "Cannot import empty "+str(','.join(table_not_uploaded))+' table'
                            status = 'error'
                        else:
                            #table_uploaded = ','.join(table_uploaded)
                            message = 'Table '+str(','.join(table_uploaded))+" imported successfully"
                            status = 'success'

                        print("----- table_info ------")
                        print(table_info)

                        #Check Database Connection
                        print("Checking database connector")
                        connector_list = self.connector_schema.objects(catalog_key=self.catalog_key, project_key= self.project_key, database_type=kwargs['database_type'], database_name=database_name, deleted=False).to_json()
                        print(list(loads(connector_list)))
                        if len(list(loads(connector_list))) > 0: # Update Connector
                            connection_details = list(loads(connector_list))
                            if len(table_uploaded)==0:
                                table_uploaded = connection_details[0]['table_lists']
                            
                            if len(table_info)==0:
                                table_info = connection_details[0]['table_info']
                            
                            print("Inside If")
                            # Updating data into projects collection
                            connector_resp = self.connector_schema.objects(project_key=self.project_key, catalog_key=self.catalog_key, database_type=kwargs['database_type'], database_name=database_name, deleted=False).modify(
                                    new=True,
                                    table_lists=table_uploaded,
                                    table_info=table_info,
                                    updated_by=self.catalog_key,
                                    set__updated_at = datetime.now()
                                )
                        else: # Create Connector
                            print("Inside Else")
                            secret_key = environ.get('SESSION_SECRET_KEY',None)
                            new_password = encrypt(secret_key, str(password))
                            new_password = b64encode(new_password)
                            new_password = new_password.decode('utf8')
                            print("--- new_password ---")
                            print(new_password)
                            connector_obj = self.connector_schema(catalog_key=self.catalog_key, 
                                                    project_key= self.project_key, 
                                                    database_type=str(kwargs['database_type']), 
                                                    connection_url=str(connection_url),
                                                    user_name=str(user_name),
                                                    password=str(new_password),
                                                    port_no=str(port_no),
                                                    database_name=database_name,
                                                    table_lists=table_uploaded,
                                                    table_info=table_info,
                                                    created_by=self.catalog_key,
                                                    updated_by=self.catalog_key,
                                                    owners=[self.catalog_key]
                                                    )
                            connector_obj.save()
                        
                        if 'ret_file_path' in kwargs and kwargs['ret_file_path'] is not None and kwargs['ret_file_path'].lower() in ['yes']:
                            if table_info is not None:
                                return ({'status':status,'message':message,'file_path':table_info})
                            else:
                                return ({'status':status,'message':message})
                        else:    
                            return ({'status':status,'message':message})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})  

    # Fetching Table data (2nd Method of fetching Table Data)   
    def fetch_table_data(self,**kwargs):
        try:
            print("---- Inside fetch_table_data methods ----")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_details_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                # Random Key for Mulit user and for same processor created multiple times in a process group
                process_group_key                         = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                controller_service_key                    = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                fetching_table_data_query_database_table  = 'fetching_table_data_query_database_table_'+str(process_group_helper.random_string(8))
                fetching_table_data_convert_avro_to_json  = 'fetching_table_data_convert_avro_to_json_'+str(process_group_helper.random_string(8))
                fetching_table_data_convert_avro_to_parquet = 'fetching_table_data_convert_avro_to_parquet_'+str(process_group_helper.random_string(8))
                fetching_table_data_update_attribute      = 'fetching_table_data_update_attribute_'+str(process_group_helper.random_string(8))
                fetching_table_data_put_file              = 'fetching_table_data_put_file_'+str(process_group_helper.random_string(8))
                
                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_details_from_mysql','fetch_table_details_from_postgres','fetch_table_details_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']

                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Starting/Enabling DBPOOL Connection
                    print(" Enabling Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    if 'table_lists' in kwargs and kwargs['table_lists'] is not None and len(kwargs['table_lists'])>0:
                        # Creating queryDatabaseTable Processor
                        print(" Creating queryDatabaseTable processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                              controller_service_key=controller_service_key,
                                                              process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='query_database_table',
                                                              processor_key=fetching_table_data_query_database_table)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # AVRO To JSON/Parquet
                        if 'avro_to' in kwargs and kwargs['avro_to'] is not None and kwargs['avro_to'] in ['json']:
                            avro_to_processor_name = 'convert_avro_to_json'
                            avro_to_processor_key  = fetching_table_data_convert_avro_to_json
                            file_extension = "json"
                        else:
                            avro_to_processor_name = 'convert_avro_to_parquet'
                            avro_to_processor_key  = fetching_table_data_convert_avro_to_parquet
                            file_extension = "parquet"
                        
                        print("---- Avro to ------")
                        print(avro_to_processor_name)
                        print(avro_to_processor_key)
                        
                        # Creating AVRO to JSON Processor
                        print(" Creating AVRO to JSON processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=avro_to_processor_name,
                                                            processor_key=avro_to_processor_key)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Updating AVRO to JSON Processor
                        print(" Updating AVRO to JSON Processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=avro_to_processor_name,
                                                            processor_key=avro_to_processor_key)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Update Attribute Processor
                        print(" Creating Update Attribute processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='update_attribute',
                                                            processor_key=fetching_table_data_update_attribute)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Put File Processor
                        print(" Creating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='put_file',
                                                              processor_key=fetching_table_data_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating file path for NiFi
                        print(" Generating File Path ")
                        path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                        if path_resp['status'] in ['error']:
                            return path_resp
                        print("File path "+str(path_resp))

                        # Updating Put File Processor
                        print(" Updating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='put_file',
                                                                processor_key=fetching_table_data_put_file,
                                                                file_path=path_resp['file_path'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Establishing Connection between ExecuteSQL & AVRO_JSON Processor
                        print(" Establishing Connection between queryDatabaseTable & AVRO_JSON Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='query_database_table',
                                                                destination_processor_name=avro_to_processor_name,
                                                                source_processor_key=fetching_table_data_query_database_table,
                                                                destination_processor_key=avro_to_processor_key,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between AVRO_JSON & Update Attribute Processor
                        print(" Establishing Connection between AVRO_JSON & Update Attribute Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name=avro_to_processor_name,
                                                                destination_processor_name='update_attribute',
                                                                source_processor_key=avro_to_processor_key,
                                                                destination_processor_key=fetching_table_data_update_attribute,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                    
                        # Establishing Connection between Update Attribute & Put File Processor
                        print(" Establishing Connection between Update Attribute & Put File Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='update_attribute',
                                                                destination_processor_name='put_file',
                                                                source_processor_key=fetching_table_data_update_attribute,
                                                                destination_processor_key=fetching_table_data_put_file,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        table_lists = kwargs['table_lists']
                        file_path = []
                        table_info = []
                        table_uploaded = []
                        table_not_uploaded = []

                        # Checking whether table has data or empty by count of the table
                        table_row_counts = self.fetch_table_row_count(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                database_type=kwargs['database_type'], 
                                                                connection_url=kwargs['connection_url'],
                                                                port_no=kwargs['port_no'],
                                                                user_name=kwargs['user_name'],
                                                                password = kwargs['password'],
                                                                database_name = kwargs['database_name'],
                                                                table_lists= table_lists,
                                                                skip_database_validation = "no",
                                                                ret_file_path="yes")
                        
                        if table_row_counts['status'] in ['error']:
                            return table_row_counts
                        table_row_counts = table_row_counts['row_count']
                        if len(table_row_counts)>0:
                            for table_name in table_lists:
                                if int(table_row_counts[table_name])==0:
                                    table_not_uploaded.append(table_name)
                                else:
                                    table_uploaded.append(table_name)
                        table_lists = table_uploaded
                        
                        # Fetching Table Schema
                        table_schema = self.fetch_table_schema(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                database_type=kwargs['database_type'], 
                                                                connection_url=kwargs['connection_url'],
                                                                port_no=kwargs['port_no'],
                                                                user_name=kwargs['user_name'],
                                                                password = kwargs['password'],
                                                                database_name = kwargs['database_name'],
                                                                skip_database_validation="yes",
                                                                table_lists= table_lists,
                                                                ret_file_path="yes"
                                                                )
                        
                        if table_schema['status'] in ['error']:
                            return table_schema
                        table_schema = table_schema['file_names']
                        
                        for table_name in table_lists:
                            #temp = {}
                            timestamp = int(round(time.time() * 1000))
                            
                            # Updating ExecuteSQL Processor
                            print(" Updating ExecuteSQL processor "+str(table_name))
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name='query_database_table',
                                                                    query_type="fetching_table_data",
                                                                    processor_key=fetching_table_data_query_database_table,
                                                                    skip_database_validation='yes',
                                                                    database_name=database_name,
                                                                    table_name=table_name)
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            
                            '''
                            # Listing the queue
                            print(" Listing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.list_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name='query_database_table',
                                                                    destination_processor_name=avro_to_processor_name,
                                                                    source_processor_key=fetching_table_data_query_database_table,
                                                                    destination_processor_key=avro_to_processor_key,
                                                                    relationship="success")
                            print(connection_resp)
                            if connection_resp['status'] in ['error']:
                                table_not_uploaded.append(table_name)
                            else:
                                table_uploaded.append(table_name)
                            
                            # Clearing the queue
                            print(" Clearing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.clear_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name='query_database_table',
                                                                    destination_processor_name=avro_to_processor_name,
                                                                    source_processor_key=fetching_table_data_query_database_table,
                                                                    destination_processor_key=avro_to_processor_key)
                            print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            '''

                            # Preparing the filename
                            # str(self.catalog_key)+"_"+str(self.project_key)+"_"+str(kwargs['process_group_name'])+"_"+
                            filename = str(database_name)+"_"+str(table_name)+"_"+str(timestamp)+"."+str(file_extension)
                            file_path.append(filename)
                            
                            # Updating Update Attribute Processor
                            print(" Updating Update Attribute processor ")
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='update_attribute',
                                                                processor_key=fetching_table_data_update_attribute,
                                                                relationships=['failure'],
                                                                filename=filename)
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            
                            # Running the Processor group
                            print(" Starting the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='start')
                            #print(process_group_resp)
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Delaying for 5 seconds to know whether information given by user is valid or not
                            #time.sleep(5)
                            
                            # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                            source_file_path = path.join(path_resp['file_path'], filename)
                            while True:
                                if path.exists(source_file_path):
                                    break
                            
                            # Running the Processor group
                            print(" Stopping the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='stop')
                            #print(process_group_resp)
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp

                            # Clearing the queue show that next table if any does not have previous table data
                            print(" Clearing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.clear_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name='query_database_table',
                                                                    destination_processor_name=avro_to_processor_name,
                                                                    source_processor_key=fetching_table_data_query_database_table,
                                                                    destination_processor_key=avro_to_processor_key)
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                            print(" Updating table info")
                            temp = {
                                'schema':table_schema[table_name],
                                'data':filename
                            }
                            table_info.append(temp)                               
                            print("----- table_info -----") 
                            print(table_info)   
                        
                        # Deleting queryDatabaseTable Processor
                        print(" Deleting queryDatabaseTable processor ")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="query_database_table",
                                                            processor_key=fetching_table_data_query_database_table,
                                                            source_processor_name='query_database_table',
                                                            destination_processor_name=avro_to_processor_name,
                                                            source_processor_key=fetching_table_data_query_database_table,
                                                            destination_processor_key=avro_to_processor_key)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Controller Service
                        print(" Deleting Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key)
                        #print(controller_service_resp)
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp
                        
                        # Deleting AVROToJSON Processor
                        print("Deleting AVROToJSON Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=avro_to_processor_name,
                                                            processor_key=avro_to_processor_key,
                                                            source_processor_name=avro_to_processor_name,
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=avro_to_processor_key,
                                                            destination_processor_key=fetching_table_data_update_attribute)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting Update Attribute Processor
                        print("Deleting Update Attribute Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="update_attribute",
                                                            processor_key=fetching_table_data_update_attribute,
                                                            source_processor_name='update_attribute',
                                                            destination_processor_name='put_file',
                                                            source_processor_key=fetching_table_data_update_attribute,
                                                            destination_processor_key=fetching_table_data_put_file)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Deleting Put File Processor
                        print("Deleting Put File Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                    project_key=self.project_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name="put_file",
                                                                    processor_key=fetching_table_data_put_file)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                                            
                        # Creating Process Group
                        print(" Deleting Process Group ")
                        process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                        project_key=self.project_key,
                                                                        parent_group_id=self.parent_group_id)
                        process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key)
                        #print(process_group_resp)
                        if process_group_resp['status'] in ['error']:
                            return process_group_resp
                        
                        print("---- table_not_uploaded -----")
                        print(table_not_uploaded)
                        print("---- table_uploaded -----")
                        print(table_uploaded)

                        #Check Database Connection
                        print("Checking database connector")
                        connector_list = self.connector_schema.objects(catalog_key=self.catalog_key, project_key= self.project_key, database_type=kwargs['database_type'], database_name=database_name, deleted=False).to_json()
                        print(list(loads(connector_list)))
                        if len(list(loads(connector_list))) > 0: # Update Connector
                            connection_details = list(loads(connector_list))
                            if len(table_uploaded)==0:
                                table_uploaded = connection_details[0]['table_lists']
                            
                            if len(table_info)==0:
                                table_info = connection_details[0]['table_info']
                            
                            print("Inside If")
                            # Updating data into projects collection
                            connector_resp = self.connector_schema.objects(project_key=self.project_key, catalog_key=self.catalog_key, database_type=kwargs['database_type'], database_name=database_name, deleted=False).modify(
                                    new=True,
                                    table_lists=table_uploaded,
                                    table_info=table_info,
                                    updated_by=self.catalog_key,
                                    set__updated_at = datetime.now()
                                )
                        else: # Create Connector
                            print("Inside Else")
                            secret_key = environ.get('SESSION_SECRET_KEY',None)
                            new_password = encrypt(secret_key, str(password))
                            new_password = b64encode(new_password)
                            new_password = new_password.decode('utf8')
                            print("--- new_password ---")
                            print(new_password)

                            connector_obj = self.connector_schema(catalog_key=self.catalog_key, 
                                                    project_key= self.project_key, 
                                                    database_type=str(kwargs['database_type']), 
                                                    connection_url=str(connection_url),
                                                    user_name=str(user_name),
                                                    password=str(new_password),
                                                    port_no=str(port_no),
                                                    database_name=database_name,
                                                    table_lists=table_uploaded,
                                                    table_info=table_info,
                                                    created_by=self.catalog_key,
                                                    updated_by=self.catalog_key,
                                                    owners=[self.catalog_key]
                                                    )
                            connector_obj.save()
                    
                        if len(table_uploaded)>0 and len(table_not_uploaded)>0:
                            table_uploaded = ','.join(table_uploaded)
                            table_not_uploaded = ','.join(table_not_uploaded)
                            message = 'Table '+str(table_uploaded)+" imported successfully. Cannot import empty "+str(table_not_uploaded)+' table'
                            status = 'error'
                        elif len(table_not_uploaded)>0:
                            table_not_uploaded = ','.join(table_not_uploaded)
                            message = "Cannot import empty "+str(table_not_uploaded)+' table'
                            status = 'error'
                        else:
                            table_uploaded = ','.join(table_uploaded)
                            message = 'Table '+str(table_uploaded)+" imported successfully"
                            status = 'success'
                            
                        if 'ret_file_path' in kwargs and kwargs['ret_file_path'] is not None and kwargs['ret_file_path'].lower() in ['yes']:
                            return ({'status':status,'message':message,'table_info':table_info})
                        else:    
                            return ({'status':status,'message':message})
                
        except Exception as e:
            return ({'status': 'error', 'message': str(e)}) 

    # Fetching Table data (3rd Method of fetching Table Data)
    def save_table_data(self,**kwargs):
        try:
            print("---- Inside store_table_details_sec methods ------")
            if 'database_type' not in kwargs or kwargs['database_type'] is None or self.catalog_key is None or self.project_key is None:
                return ({'status':'error','message':"Missing required parameters"})
            else:
                kwargs['process_group_name'] = None
                if 'database_type' in kwargs and kwargs['database_type'] is not None:
                    kwargs['process_group_name'] = 'fetch_table_details_from_' + str(kwargs['database_type'])
                    kwargs['controller_service_name'] = str(kwargs['database_type'])
                
                print("---- process_group_name ---")
                print(kwargs['process_group_name'])
                print("---- controller_service_name ---")
                print(kwargs['controller_service_name'])
                
                # Random Key for Mulit user and for same processor created multiple times in a process group
                # Process Group
                process_group_key                         = kwargs['process_group_name']+"_"+str(process_group_helper.random_string(8))
                
                # Controller Service
                controller_service_key                    = kwargs['database_type']+"_"+str(process_group_helper.random_string(8))
                controller_avro_reader_key                = "controller_avro_reader_key_"+str(process_group_helper.random_string(8))
                controller_json_record_set_writer_key     = "controller_json_record_set_writer_key_"+str(process_group_helper.random_string(8))
                controller_parquet_record_set_writer_key  = "controller_parquet_record_set_writer_key_"+str(process_group_helper.random_string(8))
                controller_csv_record_set_writer_key      = "controller_csv_record_set_writer_key_"+str(process_group_helper.random_string(8))
                
                # Processor
                fetching_table_data_execute_sql           = 'fetching_table_data_execute_sql_'+str(process_group_helper.random_string(8))
                fetching_table_data_query_database_table  = 'fetching_table_data_query_database_table_'+str(process_group_helper.random_string(8))
                fetching_table_data_merge_record          = 'fetching_table_data_merge_record_'+str(process_group_helper.random_string(8))
                fetching_table_data_update_attribute      = 'fetching_table_data_update_attribute_'+str(process_group_helper.random_string(8))
                fetching_table_data_put_file              = 'fetching_table_data_put_file_'+str(process_group_helper.random_string(8))

                # Creating Process Group
                print(" Creating Process Group ")
                process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                parent_group_id=self.parent_group_id)
                process_group_resp = process_group_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key)
                if process_group_resp['status'] in ['error']:
                    return process_group_resp
                
                print("process_group_name "+kwargs['process_group_name'])
                # Configuring Controller Service based on group name
                if kwargs['process_group_name'] in ['fetch_table_details_from_mysql','fetch_table_details_from_postgres','fetch_table_details_from_sqlite']:
                    # Initializing variables
                    connection_url  = None
                    port_no         = None
                    user_name       = None
                    password        = None
                    database_name   = None

                    if 'connection_url' in kwargs and kwargs['connection_url'] is not None:
                        connection_url = kwargs['connection_url']
                    
                    if 'port_no' in kwargs and kwargs['port_no'] is not None:
                        port_no = kwargs['port_no']
                    
                    if 'user_name' in kwargs and kwargs['user_name'] is not None:
                        user_name = kwargs['user_name']
                    
                    if 'password' in kwargs and kwargs['password'] is not None:
                        password = kwargs['password']
                    
                    if 'database_name' in kwargs and kwargs['database_name'] is not None:
                        database_name = kwargs['database_name']

                    # Creating Controller Service for DBPOOL Connection
                    print(" Creating DB Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name=kwargs['controller_service_name'],
                                                                           controller_service_key=controller_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Updating Controller Service for DBPOOL Connection
                    print(" Updating Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                            controller_service_key=controller_service_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            database_connection_url= connection_url,
                                                                            database_port_no= port_no,
                                                                            database_name= database_name,
                                                                            database_user_name= user_name,
                                                                            database_password = password,
                                                                            validation_query="yes")
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Enabling DB Controller Service
                    print(" Enabling DB Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= kwargs['controller_service_name'],
                                                                                controller_service_key=controller_service_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    # Creating Avro Reader Controller
                    print(" Creating Avro Reader Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                           process_group_key=process_group_key,  
                                                                           controller_service_name="avro_reader",
                                                                           controller_service_key=controller_avro_reader_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    
                    # Enabling DB Controller Service
                    print(" Enabling Avro Reader Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= "avro_reader",
                                                                                controller_service_key=controller_avro_reader_key,
                                                                                run_status='start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                        
                    if 'avro_to' in kwargs and kwargs['avro_to'] is not None and kwargs['avro_to'] in ['json']:
                        controller_merge_record_service_name = 'json_record_set_writer'
                        controller_merge_record_service_key  = controller_json_record_set_writer_key
                        file_extension = "json"
                    elif 'avro_to' in kwargs and kwargs['avro_to'] is not None and kwargs['avro_to'] in  ['csv']:
                        controller_merge_record_service_name = 'csv_record_set_writer'
                        controller_merge_record_service_key  = controller_csv_record_set_writer_key
                        file_extension = "csv"
                    else:
                        controller_merge_record_service_name = 'parquet_record_set_writer'
                        controller_merge_record_service_key  = controller_parquet_record_set_writer_key
                        file_extension = "parquet"

                    # Creating JSON/Parquet Record Set Writer Controller
                    print(" Creating "+str(controller_merge_record_service_name)+" Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.create(process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key,  
                                                                        controller_service_name=controller_merge_record_service_name,
                                                                        controller_service_key=controller_merge_record_service_key)
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                
                    # Enabling JSON/Parquet Record Set Writer Controller Service
                    print(" Enabling "+str(controller_merge_record_service_name)+" Controller Service ")
                    controller_service_obj  = controller_service.ControllerService(catalog_key=self.catalog_key, project_key=self.project_key)
                    controller_service_resp = controller_service_obj.run_status(controller_service_name= controller_merge_record_service_name,
                                                                                controller_service_key= controller_merge_record_service_key,
                                                                                run_status= 'start')
                    if controller_service_resp['status'] in ['error']:
                        return controller_service_resp
                    
                    if 'table_lists' in kwargs and kwargs['table_lists'] is not None and len(kwargs['table_lists'])>0:
                        if 'database_processor' in kwargs and kwargs['database_processor'] is not None and kwargs['database_processor'] in ['execute_sql']:
                            database_processor_name = 'execute_sql'
                            database_processor_key  = fetching_table_data_execute_sql
                        else:
                            database_processor_name = 'query_database_table'
                            database_processor_key  = fetching_table_data_query_database_table
                        
                        # Creating ExecuteSQL Processor
                        print(" Creating ExecuteSQL processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(controller_service_name= kwargs['controller_service_name'],
                                                              controller_service_key=controller_service_key,
                                                              process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name=database_processor_name,
                                                              processor_key=database_processor_key)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating Merge Records Processor
                        print(" Creating Merge Records processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="merge_records",
                                                            processor_key=fetching_table_data_merge_record)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Update Attribute Processor
                        print(" Creating Update Attribute processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='update_attribute',
                                                            processor_key=fetching_table_data_update_attribute)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Create Put File Processor
                        print(" Creating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.create(process_group_name=kwargs['process_group_name'],
                                                              process_group_key=process_group_key,
                                                              processor_name='put_file',
                                                              processor_key=fetching_table_data_put_file)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Creating file path for NiFi
                        print(" Generating File Path ")
                        path_resp = process_group_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                        if path_resp['status'] in ['error']:
                            return path_resp
                        print("File path "+str(path_resp))

                        # Updating Put File Processor
                        print(" Updating Put File processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name='put_file',
                                                            processor_key=fetching_table_data_put_file,
                                                            file_path=path_resp['file_path'])
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Establishing Connection between ExecuteSQL & MergeRecords Processor
                        print(" Establishing Connection between ExecuteSQL & MergeRecords Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name=database_processor_name,
                                                            destination_processor_name="merge_records",
                                                            source_processor_key=database_processor_key,
                                                            destination_processor_key=fetching_table_data_merge_record,
                                                            relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        # Establishing Connection between MergeRecords & Update Attribute Processor
                        print(" Establishing Connection between MergeRecords & Update Attribute Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            source_processor_name="merge_records",
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=fetching_table_data_merge_record,
                                                            destination_processor_key=fetching_table_data_update_attribute,
                                                            relationship="merged")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                    
                        # Establishing Connection between Update Attribute & Put File Processor
                        print(" Establishing Connection between Update Attribute & Put File Processor ")
                        connection_obj = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                        connection_resp = connection_obj.create(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                source_processor_name='update_attribute',
                                                                destination_processor_name='put_file',
                                                                source_processor_key=fetching_table_data_update_attribute,
                                                                destination_processor_key=fetching_table_data_put_file,
                                                                relationship="success")
                        if connection_resp['status'] in ['error']:
                            return connection_resp
                        
                        table_lists = kwargs['table_lists']
                        file_path = []
                        file_name_lists = []
                        table_info = []

                        print("---- Table row count ----")     
                        # Checking whether table has data or empty by count of the table
                        table_row_counts = self.fetch_table_row_count(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                database_type=kwargs['database_type'], 
                                                                connection_url=kwargs['connection_url'],
                                                                port_no=kwargs['port_no'],
                                                                user_name=kwargs['user_name'],
                                                                password = kwargs['password'],
                                                                database_name = kwargs['database_name'],
                                                                table_lists= table_lists,
                                                                skip_database_validation = "no",
                                                                ret_file_path="yes")
                        
                        if table_row_counts['status'] in ['error']:
                            return table_row_counts
                        
                        table_row_counts = table_row_counts['row_count']
                        print("---- table_lists -----")
                        print(table_lists)
                        print("---- table_row_counts -----")
                        print(table_row_counts)
                        table_not_uploaded = []
                        table_uploaded = []
                        if len(table_row_counts)>0:
                            for table_name in table_lists:
                                print("--- table_row_counts[table_name] -----"+str(table_row_counts[table_name])+" table_name "+str(table_name))
                                if int(table_row_counts[table_name])==0:
                                    table_not_uploaded.append(table_name)
                                else:
                                    table_uploaded.append(table_name)
                        
                        table_lists = table_uploaded

                        print("---- table_lists -----")
                        print(table_lists)

                        print("---- fetching table schema ----")  
                        # Fetching Table Schema because few Data type is not supported by AVRO such as BIGINT to handle it converting it to varchar/char
                        table_schema = self.fetch_table_schema(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key,
                                                                database_type=kwargs['database_type'], 
                                                                connection_url=kwargs['connection_url'],
                                                                port_no=kwargs['port_no'],
                                                                user_name=kwargs['user_name'],
                                                                password = kwargs['password'],
                                                                database_name = kwargs['database_name'],
                                                                skip_database_validation = "yes",
                                                                table_lists= table_lists,
                                                                ret_file_path="yes")
                        
                        if table_schema['status'] in ['error']:
                            return table_schema
                        table_schema = table_schema['file_names']

                        print("----- Fetching table data -----")
                        for table_name in table_lists:
                            timestamp = int(round(time.time() * 1000))
                            
                            query = None
                            if 'database_processor' in kwargs and kwargs['database_processor'] is not None and kwargs['database_processor'] in ['execute_sql']:
                                # Preparing Query
                                '''
                                if len(table_schema)>0:
                                    temp_path = path.join(path_resp['file_path'],table_schema[table_name])
                                    file_data = open(temp_path,'r')
                                    file_content = file_data.read()
                                    file_data.close()
                                    file_content = loads(file_content)
                                    print(file_content)
                                    if len(file_content)>0:
                                        i = 1
                                        default_length = 100
                                        query = "select "
                                        if kwargs['process_group_name'] in ['fetch_table_details_from_mysql']:
                                            for item in file_content:
                                                #select CAST(id as char(50)) as id, CAST(salary as char(50)) as salary, CAST(emp_id as char(50)) as emp_id from salary;
                                                if 'length' in item and item['length'] is not None:
                                                    temp_query = " cast("+str(item['column_name'])+" as char("+str(item['length'])+")) as "+ str(item['column_name'])
                                                else:
                                                    temp_query = " cast("+str(item['column_name'])+" as char("+str(default_length)+")) as "+ str(item['column_name'])
                                                
                                                if i != len(file_content):
                                                    temp_query = temp_query + ", "
                                        
                                                i = i + 1
                                                query = query + temp_query

                                            query = query + " from "+str(table_name)
                                        elif kwargs['process_group_name'] in ['fetch_table_details_from_postgres']:
                                            for item in file_content:
                                                #select CAST(id as char(50)) as id, CAST(salary as char(50)) as salary, CAST(emp_id as char(50)) as emp_id from salary;
                                                if 'length' in item and item['length'] is not None:
                                                    temp_query = " cast("+str(item['column_name'])+" as varchar("+str(item['length'])+")) as "+ str(item['column_name'])
                                                else:
                                                    temp_query = " cast("+str(item['column_name'])+" as varchar("+str(default_length)+")) as "+ str(item['column_name'])
                                                
                                                if i != len(file_content):
                                                    temp_query = temp_query + ", "
                                        
                                                i = i + 1
                                                query = query + temp_query

                                            query = query + " from "+str(table_name)
                                        print("------query-------")
                                        print(query)
                                '''
                                
                            # Updating ExecuteSQL Processor
                            print(" Updating ExecuteSQL processor "+str(table_name))
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name=database_processor_name,
                                                                    query_type="fetching_table_data",
                                                                    query=query,
                                                                    processor_key=database_processor_key,
                                                                    skip_database_validation='yes',
                                                                    database_name=database_name,
                                                                    table_name=table_name)
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                                    
                            # Updating MergeRecord
                            print(" Updating MergeRecords processor ")
                            max_records = int(table_row_counts[table_name]) + 1000
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    processor_name='merge_records',
                                                                    processor_key=fetching_table_data_merge_record,
                                                                    relationships=["failure", "original"],
                                                                    record_reader=controller_avro_reader_key,
                                                                    record_writer=controller_merge_record_service_key,
                                                                    min_records=str(table_row_counts[table_name]),
                                                                    max_records=str(max_records))
                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp                           

                            # Preparing the filename
                            # str(self.catalog_key)+"_"+str(self.project_key)+"_"+str(kwargs['process_group_name'])+"_"+
                            filename = str(database_name)+"_"+str(table_name)+"_"+str(timestamp)+"."+str(file_extension)
                            print("---- filename ----")
                            print(filename)
                            file_name_lists.append(filename)

                            # Updating Update Attribute Processor
                            print(" Updating Update Attribute processor ")
                            processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                            processor_resp = processor_obj.update(process_group_name=kwargs['process_group_name'],
                                                                process_group_key=process_group_key,
                                                                processor_name='update_attribute',
                                                                processor_key=fetching_table_data_update_attribute,
                                                                relationships=['failure'],
                                                                filename=filename)
                            if processor_resp['status'] in ['error']:
                                return processor_resp
                            
                            # Running the Processor group
                            print(" Starting the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key, 
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='start')
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Delaying for 5 seconds to know whether information given by user is valid or not
                            #time.sleep(5)
                            
                            # Checking whether file is there in target location if yes then break otherwise infinite loop will goes on
                            source_file_path = path.join(path_resp['file_path'], filename)
                            while True:
                                if path.exists(source_file_path):
                                    break

                            # Running the Processor group
                            print(" Stopping the Process Group ")
                            process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                            project_key=self.project_key,
                                                                            parent_group_id=self.parent_group_id)
                            process_group_resp = process_group_obj.run_status(process_group_name=kwargs['process_group_name'], 
                                                                              process_group_key=process_group_key,
                                                                              run_status='stop')
                            #print(process_group_resp)
                            if process_group_resp['status'] in ['error']:
                                return process_group_resp
                            
                            # Clearing the queue show that next table if any does not have previous table data
                            print(" Clearing the queue ")
                            connection_obj  = connection.Connection(catalog_key=self.catalog_key, project_key=self.project_key)
                            connection_resp = connection_obj.clear_queue(controller_service_name= kwargs['controller_service_name'],
                                                                    controller_service_key=controller_service_key,
                                                                    process_group_name=kwargs['process_group_name'],
                                                                    process_group_key=process_group_key,
                                                                    source_processor_name=database_processor_name,
                                                                    destination_processor_name="merge_records",
                                                                    source_processor_key=database_processor_key,
                                                                    destination_processor_key=fetching_table_data_merge_record)

                            #print(processor_resp)
                            if processor_resp['status'] in ['error']:
                                return processor_resp

                            temp = {
                                'schema': table_schema[table_name],
                                'data': filename,
                                'row_count': table_row_counts[table_name]
                            }
                            table_info.append(temp)

                            print("----- table_info ------")
                            print(table_info)
                        
                        # Deleting Terminate ExecuteSQL Processor
                        print(" Deleting Terminate ExecuteSQL processor ")
                        processor_obj = processor.Processor(catalog_key=self.catalog_key, project_key=self.project_key)
                        processor_resp = processor_obj.terminate_threads(process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=database_processor_name,
                                                            processor_key=database_processor_key)
                        #print(processor_resp) 
                        if processor_resp['status'] in ['error']:
                            return processor_resp                        

                        # Deleting ExecuteSQL Processor
                        print(" Deleting ExecuteSQL processor ") 
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name=database_processor_name,
                                                            processor_key=database_processor_key,
                                                            source_processor_name=database_processor_name,
                                                            destination_processor_name="merge_records",
                                                            source_processor_key=database_processor_key,
                                                            destination_processor_key=fetching_table_data_merge_record)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting DB Controller Service
                        print(" Deleting DB Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= kwargs['controller_service_name'],
                                                                controller_service_key=controller_service_key)
                        #print(controller_service_resp)
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp
                        
                        # Deleting MergeRecords Processor
                        print("Deleting MergeRecords Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="merge_records",
                                                            processor_key=fetching_table_data_merge_record,
                                                            source_processor_name="merge_records",
                                                            destination_processor_name='update_attribute',
                                                            source_processor_key=fetching_table_data_merge_record,
                                                            destination_processor_key=fetching_table_data_update_attribute)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp

                        # Deleting AVRO Reader Controller Service
                        print(" Deleting AVRO Reader Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= "avro_reader",
                                                                controller_service_key=controller_avro_reader_key)
                        #print(controller_service_resp)
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp

                        
                        # Deleting JSON/Parquet Controller Service
                        print(" Deleting JSON/Parquet Controller Service ")
                        controller_service_resp = process_group_helper.delete_controller_service(catalog_key=self.catalog_key, 
                                                                project_key=self.project_key, 
                                                                controller_service_name= controller_merge_record_service_name,
                                                                controller_service_key=controller_merge_record_service_key)
                        #print(controller_service_resp)
                        if controller_service_resp['status'] in ['error']:
                            return controller_service_resp

                        # Deleting Update Attribute Processor
                        print("Deleting Update Attribute Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                            project_key=self.project_key,
                                                            process_group_name=kwargs['process_group_name'],
                                                            process_group_key=process_group_key,
                                                            processor_name="update_attribute",
                                                            processor_key=fetching_table_data_update_attribute,
                                                            source_processor_name='update_attribute',
                                                            destination_processor_name='put_file',
                                                            source_processor_key=fetching_table_data_update_attribute,
                                                            destination_processor_key=fetching_table_data_put_file)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                        
                        # Deleting Put File Processor
                        print("Deleting Put File Processor")
                        processor_obj = process_group_helper.delete_processor(catalog_key=self.catalog_key,
                                                                            project_key=self.project_key,
                                                                            process_group_name=kwargs['process_group_name'],
                                                                            process_group_key=process_group_key,
                                                                            processor_name="put_file",
                                                                            processor_key=fetching_table_data_put_file)
                        #print(processor_resp)
                        if processor_resp['status'] in ['error']:
                            return processor_resp
                                            
                        # Creating Process Group
                        print(" Deleting Process Group ")
                        process_group_obj  = process_group.ProcessGroup(catalog_key=self.catalog_key, 
                                                                        project_key=self.project_key,
                                                                        parent_group_id=self.parent_group_id)
                        process_group_resp = process_group_obj.delete(process_group_name=kwargs['process_group_name'],
                                                                        process_group_key=process_group_key)
                        #print(process_group_resp)
                        if process_group_resp['status'] in ['error']:
                            return process_group_resp
                        
                        source_file_path = None
                        message = 'Updated successfully'
                        status = "success"

                        if len(table_uploaded)>0 and len(table_not_uploaded)>0:
                            #table_uploaded = ','.join(table_uploaded)
                            #table_not_uploaded = ','.join(table_not_uploaded)
                            message = 'Table '+str(','.join(table_uploaded))+" imported successfully. Cannot import empty "+str(','.join(table_not_uploaded))+' table'
                            status = 'error'
                        elif len(table_not_uploaded)>0:
                            #table_not_uploaded = ','.join(table_not_uploaded)
                            message = "Cannot import empty "+str(','.join(table_not_uploaded))+' table'
                            status = 'error'
                        else:
                            #table_uploaded = ','.join(table_uploaded)
                            message = 'Table '+str(','.join(table_uploaded))+" imported successfully"
                            status = 'success'

                        print("----- table_info ------")
                        print(table_info)

                        if 'skip_database' in kwargs and kwargs['skip_database'] is not None and kwargs['skip_database'].lower() in ['yes']: # For Testing
                            return ({'status':status,'message':message})
                        else: # For Actual call
                            #Check Database Connection
                            print("Checking database connector")
                            connector_list = self.connector_schema.objects(catalog_key=self.catalog_key, project_key= self.project_key, database_type=kwargs['database_type'], database_name=database_name, deleted=False).to_json()
                            print(list(loads(connector_list)))
                            if len(list(loads(connector_list))) > 0: # Update Connector
                                connection_details = list(loads(connector_list))
                                if len(table_uploaded)==0:
                                    table_uploaded = connection_details[0]['table_lists']
                                
                                if len(table_info)==0:
                                    table_info = connection_details[0]['table_info']
                                
                                print("Inside If")
                                # Updating data into projects collection
                                connector_resp = self.connector_schema.objects(project_key=self.project_key, catalog_key=self.catalog_key, database_type=kwargs['database_type'], database_name=database_name, deleted=False).modify(
                                        new=True,
                                        table_lists=table_uploaded,
                                        table_info=table_info,
                                        updated_by=self.catalog_key,
                                        set__updated_at = datetime.now()
                                    )
                            else: # Create Connector
                                print("Inside Else")
                                secret_key = environ.get('SESSION_SECRET_KEY',None)
                                new_password = encrypt(secret_key, str(password))
                                new_password = b64encode(new_password)
                                new_password = new_password.decode('utf8')
                                print("--- new_password ---")
                                print(new_password)

                                connector_obj = self.connector_schema(catalog_key=self.catalog_key, 
                                                        project_key= self.project_key, 
                                                        database_type=str(kwargs['database_type']), 
                                                        connection_url=str(connection_url),
                                                        user_name=str(user_name),
                                                        password=str(new_password),
                                                        port_no=str(port_no),
                                                        database_name=database_name,
                                                        table_lists=table_uploaded,
                                                        table_info=table_info,
                                                        created_by=self.catalog_key,
                                                        updated_by=self.catalog_key,
                                                        owners=[self.catalog_key]
                                                        )
                                connector_obj.save()
                            
                            if 'create_dataset' in kwargs and kwargs['create_dataset'] is not None and kwargs['create_dataset'].lower() in ['yes']:
                                if table_info is not None:
                                    i = 0
                                    datasource_resp = None
                                    for table_name in table_uploaded:
                                        print("----- table_name ----"+str(table_name))
                                        datasource_obj = datasource.DataSource(catalog_key=self.catalog_key, project_key=self.project_key)
                                        datasource_obj = datasource_obj.create_dataset(name=table_name, 
                                                                            table_details=table_info[i],
                                                                            database_engine=kwargs['database_type'],
                                                                            file_extension=file_extension, 
                                                                            token=kwargs['token'], 
                                                                            request_from='api')
                                        if datasource_obj['status'] in ['error']:
                                            return datasource_obj
                                        if i == 0:
                                            datasource_resp = datasource_obj
                                        i += 1
                                    
                                    if datasource_resp is not None:
                                        return ({'status':status,'message':message,'data':datasource_resp['data']})
                                return ({'status':status,'message':message})
                            elif 'ret_file_path' in kwargs and kwargs['ret_file_path'] is not None and kwargs['ret_file_path'].lower() in ['yes']:
                                return ({'status':status,'message':message,'file_path':table_info})
                            else:    
                                return ({'status':status,'message':message})
                    else:
                        return ({'status':"error",'message':'tabe names are required'})
                    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})  

