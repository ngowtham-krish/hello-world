from strait.environment import load_env
load_env()
