from os import environ
from json import loads, dumps
from datetime import datetime
from strait.environment import load_env
from strait.core.model.schema import ColumnMenuSchema
import strait.core.helper.catalog_helper as catalog_helper

# Calling Enviroment Function
load_env()

class Column:

    def __init__(self, catalog_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key
        
        self.column_menu_schema = ColumnMenuSchema
        
    # Insert/Adding new column menu
    def create(self, **kwargs):
        try:
            if 'schema' in kwargs and 'schema' is not None:
                schema = kwargs['schema']
            else:
                return ({'status':'error','message':'schema is required'})

            system_admin = environ.get('SYSTEM_ADMIN',None) 
            if self.catalog_key in [system_admin]:
                visible = 'all'
                owners = [system_admin]    
                column_menu_type = "predefined"
                schema['column_type'] = "predefined"
            else:
                visible = "user"
                owners = [self.catalog_key]
                column_menu_type = "custom"
                schema['column_type'] = "custom"
            
            # Saving Column Menu details              
            column_menu_obj = self.column_menu_schema(
                schema=schema,
                created_by = self.catalog_key,
                updated_by = self.catalog_key,
                column_menu_type = column_menu_type,
                visible = visible,
                owners = owners
            )
            column_menu_obj.save()
            data = {
                'id': str(column_menu_obj.id),
                'schema': column_menu_obj.schema,
                'deleted': column_menu_obj.deleted,
                'updatedAt': str(column_menu_obj.updated_at)
            }
            return ({'status':'success','data':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    
    # Updating transformation
    def update(self, **kwargs):
        try:
            column_menu_data = self.column_menu_schema.objects(id=kwargs['column_id'],owners=self.catalog_key,deleted=False).to_json()
            column_menu_data = list(loads(column_menu_data))
            if len(column_menu_data)==0:
                return ({'status':'error','message':'Column id is invalid'})
            else:
                column_menu_data = column_menu_data[0]

                if 'schema' in kwargs and kwargs['schema'] is not None:
                    schema = kwargs['schema']
                else:
                    schema = column_menu_data['schema']
                
                # Updating data into dataset
                column_menu_obj  = self.column_menu_schema.objects(id=kwargs['column_id'],owners=self.catalog_key,deleted=False).modify(
                    new=True,
                    set__schema = schema,
                    set__updated_at = datetime.now()
                )

                data = {
                    'id': str(column_menu_obj.id),
                    'schema': column_menu_obj.schema,
                    'deleted': column_menu_obj.deleted,
                    'updatedAt': str(column_menu_obj.updated_at)
                }
                return ({'status':'success','data':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    
    # Deleting transformation
    def delete(self,**kwargs):
        try:
            # Updating data into transformation schema
            column_menu_obj  = self.column_menu_schema.objects(id=kwargs['column_id'], owners=self.catalog_key, deleted=False).modify(
                new=True,
                set__deleted = True,
                set__updated_at = datetime.now()
            )

            data = {
                'id': str(column_menu_obj.id),
                'deleted': column_menu_obj.deleted,
                'updatedAt': str(column_menu_obj.updated_at)
            }
            return ({'status':'success','data':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    
    # Lists transformation
    def lists(self,**kwargs):
        try:
            system_admin   = environ.get('SYSTEM_ADMIN',None) 
            pre_trans_data = self.column_menu_schema.objects(visible="all",deleted=False).to_json()
            pre_trans_data = list(loads(pre_trans_data))
            predefined_trans_lists = []
            custom_trans_lists = []
            for item in pre_trans_data:
                predefined_trans_lists.append(item['schema'])
            
            if self.catalog_key in [system_admin]:
                pass
            else:
                cust_trans_data = self.column_menu_schema.objects(owners=self.catalog_key, deleted=False).to_json()
                cust_trans_data = list(loads(cust_trans_data))
                for item in cust_trans_data:
                    custom_trans_lists.append(item['schema'])
            
            column_menu_lists = {
                'predefined': predefined_trans_lists,
                'custom': custom_trans_lists
            }

            return ({'status':'success','data':column_menu_lists})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    