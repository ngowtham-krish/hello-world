
class MongoWrapper:

    def __init__(self, *args):
        pass
    
    def insert(self, *args):
        pass
 
    def update(self, *args):
        pass
    
    def remove(self, *args):
        pass

    def findOne(self, *args):
        pass
    
    def findAll(self, *args):
        pass

    @staticmethod
    def formatter(self, *args):
        pass