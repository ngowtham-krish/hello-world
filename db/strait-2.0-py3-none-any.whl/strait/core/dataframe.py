
class DataFrame:

    def to_pandas(self, data_frame):
        return data_frame.to_pandas()

    def to_spark(self):
        pass
    
    def to_h2o(self):
        pass

    def to_table(self):
        pass