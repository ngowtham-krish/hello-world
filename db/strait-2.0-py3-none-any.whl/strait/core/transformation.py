from os import environ
from json import loads, dumps
from datetime import datetime
from strait.environment import load_env
from strait.core.model.schema import TransformationSchema
import strait.core.helper.catalog_helper as catalog_helper
import strait.core.helper.transformation_helper as transformation_helper

# Calling Enviroment Function
load_env()

class Transformation:

    def __init__(self, catalog_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key
        self.transformation_schema = TransformationSchema
        
    # Insert/Adding new transformation
    def create(self, **kwargs):
        try:
            key = None
            if 'transformation_key' in kwargs and 'transformation_key' is not None:
                key = kwargs['transformation_key']
            else:
                if 'transformation_name' in kwargs:
                    resp = catalog_helper.generate_key(kwargs['transformation_name'].strip())
                    if resp['status'] == 'error':
                        return resp
                key = resp['key']
            
            # Validating Transformation Name
            resp = transformation_helper.validate_transformation(catalog_key=self.catalog_key, transformation_key=key, request_from="add_transformation")
            if resp['status'] in ['error']:
                return resp

            if 'engine' in kwargs and kwargs['engine'] is not None:
                engine = kwargs['engine']
            else:
                engine = "python"

            if 'description' in kwargs and kwargs['description'] is not None:
                description = kwargs['description']
            else:
                description = ""
            
            if 'tags' in kwargs and kwargs['tags'] is not None:
                tags = kwargs['tags']
            else:
                tags = []
            
            system_admin = environ.get('SYSTEM_ADMIN',None) 
            if self.catalog_key in [system_admin]:
                visible = 'all'
                owners = [self.catalog_key]    
                transformation_type = "predefined"
            else:
                visible = "user"
                owners = [self.catalog_key]
                transformation_type = "custom"
            
            '''
            if 'new_column_name' in kwargs and kwargs['new_column_name'] is not None:
                new_column_name = kwargs['new_column_name']
            else:
                new_column_name = kwargs['transformation_name'].strip()
            '''
            # Saving Transformation details              
            transformation_obj = self.transformation_schema(
                name=kwargs['transformation_name'].strip(),
                key=key,
                description=description,
                tags=tags,
                engine=engine,
                path=kwargs['file_path'],
                schema= kwargs['schema'],
                function_name=kwargs['function_name'],
                transformation_type = transformation_type,
                transformation_level = kwargs['transformation_level'],
                created_by = self.catalog_key,
                updated_by = self.catalog_key,
                visible = visible,
                owners = owners
            )
            transformation_obj.save()
            data = {
                'id': str(transformation_obj.id),
                'transformationName': transformation_obj.name,
                'transformationKey': transformation_obj.key,
                'transformationType': transformation_obj.transformation_type,
                'deleted': transformation_obj.deleted,
                'tags': transformation_obj.tags,
                'updatedAt': str(transformation_obj.updated_at)
            }
            return ({'status':'success','data':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # Updating transformation
    def update(self, **kwargs):
        try:
            transformation_data = self.transformation_schema.objects(id=kwargs['transformation_id'],deleted=False).to_json()
            transformation_data = list(loads(transformation_data))
            if len(transformation_data)==0:
                return ({'status':'error','message':'Transformation id is invalid'})
            else:
                transformation_data = transformation_data[0]

                if 'description' in kwargs and kwargs['description'] is not None:
                    description = kwargs['description']
                else:
                    description = transformation_data['description']
                
                if 'tags' in kwargs and kwargs['tags'] is not None:
                    tags = kwargs['tags']
                else:
                    tags = transformation_data['tags']
                
                if 'schema' in kwargs and kwargs['schema'] is not None:
                    schema = kwargs['schema']
                else:
                    schema = transformation_data['schema']
                
                if 'transformation_level' in kwargs and kwargs['transformation_level'] is not None:
                    transformation_level = kwargs['transformation_level']
                else:
                    transformation_level = transformation_data['transformation_level']
                
                if 'transformation_name' in kwargs and kwargs['transformation_name'] is not None:
                    name = kwargs['transformation_name']
                else:
                    name = transformation_data['transformation_name']
                
                if 'function_name' in kwargs and kwargs['function_name'] is not None:
                    function_name = kwargs['function_name']
                else:
                    function_name = transformation_data['function_name']

                if 'code' in kwargs and kwargs['code'] is not None:
                    source_file = open(transformation_data['path'], "w")
                    source_file.write(kwargs['code'])
                    source_file.close()
                
                # Updating data into dataset
                transformation_obj  = self.transformation_schema.objects(id=kwargs['transformation_id'],deleted=False).modify(
                    new=True,
                    set__name = name,
                    set__description = description,
                    set__tags = tags,
                    set__schema = schema,
                    set__transformation_level = transformation_level,
                    set__function_name = function_name,
                    set__updated_at = datetime.now()
                )

                data = {
                    'id': str(transformation_obj.id),
                    'transformationName': transformation_obj.name,
                    'transformationKey': transformation_obj.key,
                    'deleted': transformation_obj.deleted,
                    'tags': transformation_obj.tags,
                    'updatedAt': str(transformation_obj.updated_at)
                }
                return ({'status':'success','data':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # Deleting transformation
    def delete(self,**kwargs):
        try:
            # Updating data into transformation schema
            transformation_obj  = self.transformation_schema.objects(id=kwargs['transformation_id'],deleted=False).modify(
                new=True,
                set__deleted = True,
                set__updated_at = datetime.now()
            )

            data = {
                'id': str(transformation_obj.id),
                'transformationName': transformation_obj.name,
                'transformationKey': transformation_obj.key,
                'deleted': transformation_obj.deleted,
                'tags': transformation_obj.tags,
                'updatedAt': str(transformation_obj.updated_at)
            }
            return ({'status':'success','data':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    # Lists transformation
    def lists(self,**kwargs):
        try:
            system_admin   = environ.get('SYSTEM_ADMIN',None) 
            pre_trans_data = self.transformation_schema.objects(owners=system_admin, transformation_type="predefined", deleted=False).to_json()
            pre_trans_data = list(loads(pre_trans_data))
            predefined_trans_lists = []
            for item in pre_trans_data:
                temp = {
                    'id': str(item['_id']['$oid']),
                    'transformationName': item['name'],
                    'deleted': item['deleted'],
                    'schema':item['schema'],
                    'transformationLevel': item['transformation_level'],
                    'updatedAt': datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S')
                }
                predefined_trans_lists.append(temp)
            
            if self.catalog_key in [system_admin]:
                pass
            else:
                cust_trans_data = self.transformation_schema.objects(owners=self.catalog_key, transformation_type="custom", deleted=False).to_json()
                cust_trans_data = list(loads(cust_trans_data))
            
                custom_trans_lists = []
                for item in cust_trans_data:
                    temp = {
                        'id': str(item['_id']['$oid']),
                        'transformationName': item['name'],
                        'deleted': item['deleted'],
                        'schema':item['schema'],
                        'transformationLevel': item['transformation_level'],
                        'updatedAt': datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S')
                    }
                    custom_trans_lists.append(temp)
            
            transformation_lists = {
                'predefined': predefined_trans_lists,
                'custom': custom_trans_lists
            }

            return ({'status':'success','data':transformation_lists})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    