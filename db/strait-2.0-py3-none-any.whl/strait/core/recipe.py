import time,shutil 
from json import loads, dumps
from datetime import datetime
import strait.core.dataset as dataset
from strait.environment import load_env
import strait.core.recipes.history as history
import strait.core.recipes.prepare as prepare
from os import path,getcwd,makedirs,environ
import strait.pipeline.recipe as pipelineRecipe
import strait.pipeline.dataset as pipelineDataset
import strait.core.helper.recipe_helper as recipe_helper
import strait.core.recipes.custom_recipe as custom_recipe
import strait.core.helper.dataset_helper as dataset_helper
import strait.core.helper.transformation_helper as transformation_helper
from strait.core.model.schema import RecipeSchema, DatasetSchema, FileSchema, TransformationSchema, HistorySchema, CatalogSchema

# Calling Enviroment Function
load_env()

class Recipe:
    def __init__(self, catalog_key=None, project_key=None, dataset_key=None, recipe_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API    
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API    
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = eval(environ.get('DATASET_KEY',None)) 
        else: # For API    
            self.dataset_key = dataset_key

        if recipe_key is None: # For Notebook or Custom Recipe
            self.recipe_key = environ.get('RECIPE_KEY',None) 
        else: # For API     
            self.recipe_key = recipe_key 
        
        self.recipe_schema  = RecipeSchema

    # Creating recipe
    def create(self, **kwargs):
        try:
            if self.catalog_key is None and self.project_key is None and self.dataset_key is None:
                if "request_from" in kwargs:
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'Missing required parameters'})
                    else: # For Notebook
                        return ('Missing required parameters')
                else: # For Notebook
                    return ('Missing required parameters')
            else:
                # If key is not there in the data
                if 'key' not in kwargs:
                    resp = recipe_helper.generate_key(kwargs["name"])
                    if resp['status'] == 'error':
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return resp
                        else: # For Notebook
                            return resp['message']
                    else:
                        recipe_key = resp['key']
                else:
                    recipe_key = kwargs['recipe_key']
                self.recipe_key = recipe_key
                # Checking whether target key exists or not
                if 'target_key' not in kwargs:
                    resp = recipe_helper.generate_key(kwargs["target_name"])
                    if resp['status'] == 'error':
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return resp
                        else: # For Notebook
                            return resp['message']
                    else:
                        target_key = resp['key']
                else:
                    target_key = kwargs['target_key']
                # Checking recipe type exists or not
                if 'recipe_type' not in kwargs:
                    recipe_type = 'prepare'
                else:
                    recipe_type = kwargs['recipe_type']
                
                datasetObj  = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key,dataset_key=target_key)
                if "request_from" in kwargs and kwargs['request_from'] in ['api']:
                    datasetResp = datasetObj.create(name=kwargs["target_name"],key=target_key,is_build=False,request_from='api')
                else:
                    datasetResp = datasetObj.create(name=kwargs["target_name"],key=target_key,is_build=False)
                if datasetResp['status']=='error':
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return datasetResp
                    else: # For Notebook
                        return datasetResp['message']
                
                # Fetching operation from file schema
                file_lists = FileSchema.objects(dataset_key=self.dataset_key[0], catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json()
                file_lists = list(loads(file_lists))
                if len(file_lists)>0:
                    operation = file_lists[0]['operation']
                else:
                    # Default Sampling
                    default_records = environ.get('DEFAULT_RECORD_COUNT',None)
                    operation = {
                        'sampling': {
                            "name":"first",
                            "column_name":"",
                            "records": int(default_records),
                            "ratio":""
                        },
                        'freeze_column_index': [],
                        'filters': [],
                        'sorting': [],
                        'column_index': [],
                        'hide_column': [],
                        'date_format':[]
                    }
                
                schema = self.recipe_schema(name=kwargs["name"].strip(), 
                                        key = recipe_key,
                                        source_key = self.dataset_key, 
                                        target_key = datasetResp["data"]["datasetKey"],
                                        project_key = self.project_key,
                                        catalog_key = self.catalog_key,
                                        recipe_type = recipe_type,
                                        operation   = operation
                                    ).save()

                # Pipeline Recipe Create
                pipelineObj = pipelineRecipe.Recipe(self.catalog_key,self.project_key,self.dataset_key,self.recipe_key)
                pipeline_resp = pipelineObj.create()
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api':
                        if kwargs['recipe_type']=='custom': # For Custom
                            custom_obj =  custom_recipe.CustomRecipe(self.dataset_key, datasetResp["data"]["datasetKey"], self.recipe_key, self.project_key, self.catalog_key)
                            custom_resp = custom_obj.get_output() 
                            return ({'status':'success', 'recipeKey': self.recipe_key, 'custom_content':custom_resp,'recipe_type':recipe_type})
                        else: # For Prepare
                            return recipe_helper.recipe_response(schema)
                    else:  # For Notebook
                        return schema.key
                else: # For Notebook
                    return schema.key
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return str(e) 
    
    # Updating recipe
    def update(self, **kwargs):
        try:
            if self.catalog_key is None and self.project_key is None and self.dataset_key is None and self.recipe_key is None:
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'Missing required parameters'})
                    else: # For Notebook
                        return ('Missing required parameters')
                else: # For Notebook
                    return ('Missing required parameters')
            else:
                # Checking whether project name already exists or not
                if kwargs['name']!="":
                    recipe_lists = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, deleted=False).to_json()
                    if len(list(loads(recipe_lists))) > 0:
                        for item in list(loads(recipe_lists)):
                            if kwargs['name'].strip() == item['name'].strip() and item['key'] != self.recipe_key:
                                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                    return ({'status': 'error', 'message': 'recipe name already exists'})
                                else: # For Notebook
                                    return ('recipe name already exists')
                    else:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status': 'error', 'message': 'project key is invalid'})
                        else: # For Notebook
                            return ('project key is invalid')
                else:
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':"error","message":"name is required"})
                    else: # For Notebook
                        return ('name is required')
                
                # Updating data into recipe collection
                recipe_resp = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key=self.recipe_key, deleted=False).modify(
                                    new=True,
                                    set__name = kwargs['name'].strip(),
                                    set__updated_at = datetime.now()
                                )
                
                # Pipeline Recipe Create
                pipelineObj = pipelineRecipe.Recipe(self.catalog_key,self.project_key,self.dataset_key,self.recipe_key)
                pipeline_resp = pipelineObj.update()
                
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': # For API
                        return recipe_helper.recipe_response(recipe_resp)
                    else:  # For Notebook
                        return recipe_resp.key
                else: # For Notebook
                    return recipe_resp.key
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return str(e)
            
    # Delete recipe
    def delete(self, **kwargs):
        try:
            if self.catalog_key is None and self.project_key is None and self.dataset_key is None and self.recipe_key is None:
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'Missing required parameters'})
                    else: # For Notebook
                        return ('Missing required parameters')
                else: # For Notebook
                    return ('Missing required parameters')
            else:
                recipe_lists = self.recipe_schema.objects(key=self.recipe_key, source_key=self.dataset_key, catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json()
                recipe_lists = list(loads(recipe_lists))
                
                target_keys = []
                target_keys.append(recipe_lists[0]['target_key'])
                
                # Pipeline Recipe Create
                pipelineObj = pipelineRecipe.Recipe(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key)
                pipeline_resp = pipelineObj.update(delete=True)
                # Deleting data into recipe collection
                recipe_resp = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key=self.recipe_key, deleted=False).modify(
                                    new=True,
                                    set__deleted = True,
                                    set__updated_at = datetime.now()
                                )
                
                # Checking whether any history schema data exists or not
                history_lists = HistorySchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, recipe_key=self.recipe_key, deleted=False).to_json()
                history_lists = list(loads(history_lists))
                if len(history_lists)>0:
                    # Updating data into history schema
                    history_obj  = HistorySchema.objects(source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, recipe_key=self.recipe_key, deleted=False).modify(
                        new=True,
                        set__deleted = True,
                        set__updated_at = datetime.now()
                    )
                    
                for item in target_keys:
                    # Pipeline Dataset Update
                    pipelineObj = pipelineDataset.Dataset(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=item)
                    pipeline_resp = pipelineObj.update(delete=True)
                    
                    # Updating data into dataset
                    datasetObj  = DatasetSchema.objects(key=item, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                        new=True,
                        set__deleted = True,
                        set__updated_at = datetime.now()
                    )

                    # Checking file data exists or not by dataset key
                    file_lists = FileSchema.objects(dataset_key=item, catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json()
                    file_lists = list(loads(file_lists))
                    if len(file_lists)>0:
                        # Updating File schema
                        fileObj  = FileSchema.objects(dataset_key=item, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                            new=True,
                            set__deleted = True,
                            set__updated_at = datetime.now()
                        )
                    
                    # Updating data into data catalog
                    catalog_lists = CatalogSchema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, deleted=1, projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).to_json()
                    catalog_lists = list(loads(catalog_lists))
                    dataset_lists = catalog_lists[0]['projects'][0]['datasets']
                    dataset_counter = 0
                    for dataset_details in dataset_lists:
                        if dataset_details['key'] == item:
                            dataset_lists[dataset_counter]['deleted'] = True
                        dataset_counter = dataset_counter + 1
                    updatedResponse = CatalogSchema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update_one(set__projects__S__datasets=dataset_lists)
                    
                    recipe_lists = self.recipe_schema.objects(source_key=item, catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json()
                    recipe_lists = list(loads(recipe_lists))
                    # Checking whether recipe exists or not
                    if len(recipe_lists)>0:
                        # Taking all target key to be deleted
                        for i in recipe_lists:
                            target_keys.append(i['target_key'])
                            # Pipeline Recipe Create
                            pipelineObj = pipelineRecipe.Recipe(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=item,recipe_key=i['key'])
                            pipeline_resp = pipelineObj.update(delete=True)
                            # Deleting data into recipe collection
                            recipe_resp = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=item, key=i['key'], deleted=False).modify(
                                                new=True,
                                                set__deleted = True,
                                                set__updated_at = datetime.now()
                                            )
                            
                            # Checking whether any history schema data exists or not
                            history_lists = HistorySchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=item, recipe_key=i['key'], deleted=False).to_json()
                            history_lists = list(loads(history_lists))
                            if len(history_lists)>0:
                                # Updating data into history schema
                                history_obj  = HistorySchema.objects(source_key=item, project_key=self.project_key, catalog_key=self.catalog_key, recipe_key=i['key'], deleted=False).modify(
                                    new=True,
                                    set__deleted = True,
                                    set__updated_at = datetime.now()
                                )
                                
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': 
                        if 'call_from' in kwargs and kwargs['call_from'] in ['delete_project']:
                            resp = recipe_helper.recipe_response(recipe_resp)
                            if resp['status'] in ['error']:
                                return resp
                            return ({'status':'success','dataset_key':target_keys,'data':resp['data']})
                        else:
                            return recipe_helper.recipe_response(recipe_resp)
                    else:  # For Notebook
                        return recipe_resp.key
                else: # For Notebook
                    return recipe_resp.key
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return str(e)
    
    # Fetching list of recipe based on catalog,project & dataset
    def lists(self, **kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                # Fetching data from projects collection by project and catalog key
                recipe_lists = self.recipe_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,deleted=False).to_json()
                recipe_lists = list(loads(recipe_lists))
                recipe_list  = []  
                for item in recipe_lists:
                    if "request_from" in kwargs:
                        if kwargs['request_from']=='api':  # For API 
                            tempObj = {
                                'recipeKey' : item['key'],
                                'name' : item['name'].strip(),
                                'recipeType': item['recipe_type'],
                                'isRecipeBuild': item['is_build'],
                                'updatedAt' : datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S')
                            }
                            recipe_list.append(tempObj)
                        else: # For Notebook
                            recipe_list.append(item['name'].strip())
                    else: # For Notebook
                        recipe_list.append(item['name'].strip())

                if "request_from" in kwargs:
                    if kwargs['request_from'] == 'api': # For API   
                        return ({'status':"success",'data':recipe_list})
                    else: # For Notebook
                        return recipe_list
                else: # For Notebook
                    return recipe_list
            else:
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': # For API  
                        return ({'status':'error','message':'Missing required parameters'})
                    else: # For Notebook
                        return ('Missing required parameters')
                else: # For Notebook
                    return ('Missing required parameters')
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return str(e)

    # Fetching recipe details by recipe key
    def get_recipe_info(self, **kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None and self.recipe_key is not None:
                # Fetching history lists by recipe key
                historyObj   = history.History(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key)
                response = historyObj.lists()
                if response['status']=='error':
                    return response
                # Fetching Recipe lists by recipe key
                recipe = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key = self.recipe_key, deleted=False)[0]
                data = {
                    "catalogKey": recipe.catalog_key,
                    "projectKey": recipe.project_key,
                    "recipeKey" : recipe.key,
                    "sourceKey" : recipe.source_key,
                    "targetKey" : recipe.target_key,
                    "history": response['history_lists']
                }
                return ({'status':'success','data':data})
            else:
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': # For API  
                        return ({'status':'error','message':'Missing required parameters'})
                    else: # For Notebook
                        return ('Missing required parameters')
                else: # For Notebook
                    return ('Missing required parameters')
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return str(e)
    
    # Run Recipe
    def run(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None and self.recipe_key is not None:
                
                # Fetching history lists by recipe key
                historyObj = history.History(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key)
                response = historyObj.lists()
                if response['status']=='error':
                    if "request_from" in kwargs and kwargs['request_from']=='api':  # For API
                        return response
                    else: # For NoteBook
                        return response['message']
                
                # Fetching dataset_key and target_key from recipe by recipe key
                recipe = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key = self.recipe_key, deleted=False)[0]
                #dataset_key = recipe.source_key
                target_key = recipe.target_key
                
                base_path = environ.get('STORAGE',None)
                # Making dataset folder to store respective dataset inside that
                dataset_dir = path.join(base_path,self.catalog_key,self.project_key,'datasets',target_key)
                if not path.exists(dataset_dir):
                    makedirs(dataset_dir)
                
                # Making history folder to store respective dataset recipe file inside that
                history_dir = path.join(base_path,self.catalog_key,self.project_key,'datasets',target_key,'history')
                if not path.exists(history_dir):
                    makedirs(history_dir)
                version = environ.get('APIVERSION',None)
                # Preparing preview path
                preview_path = '/api/'+version+'/dataset/'+target_key+'/preview?token='+kwargs['token']
                
                # Calling dataset for fetching datasource source part
                datasetObj = DatasetSchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, key=self.dataset_key, deleted=False)[0]
                
                # Fetching Data Frame
                dataset_obj = dataset.Dataset(self.catalog_key,self.project_key,self.dataset_key)
                data_frame  = dataset_obj.get_dataframe(sampling_name='all',request_from='api')
                if data_frame['status']=='error':
                    if "request_from" in kwargs and kwargs['request_from']=='api':  # For API
                        return data_frame
                    else: # For NoteBook
                        return data_frame['message']
                else:
                    data_frame = data_frame['dataFrame']
                
                # Storing history length
                history_len = len(response['history_lists'])
                if history_len>0:
                    # Retriving all the step before and including active 
                    history_lists = []
                    temp_history_len = 0
                    # Fetching the active index from history list
                    for item in response['history_lists']:
                        history_lists.append(item) 
                        if item['active']:
                            break
                        else:
                            temp_history_len += 1 
                    
                    column_name_lists = []
                    if history_len != temp_history_len: # If there is some steps 
                        # Running the history
                        for item in history_lists:
                            transformation_data = TransformationSchema.objects(key=item['transformationKey'],deleted=False).to_json()
                            transformation_data = list(loads(transformation_data)) 
                            if len(transformation_data)==0:
                                if "request_from" in kwargs and kwargs['request_from']=='api': # For API
                                    return ({'status':'error','message':'Transformation key is invalid'})
                                else:  # For NoteBook
                                    return ("Transformation id is invalid")
                            else:
                                transformation_data = transformation_data[0]
                            
                                schema = item['schema']
                                '''
                                if 'column_name' in schema:
                                    column_name_lists.append(schema['column_name'])
                                for item in schema.values():
                                    if item in list(data_frame.columns):
                                        column_name_lists.append(item)
                                '''
                                schema['data_frame'] = data_frame 
                                
                                # Executing Code
                                exec_resp = transformation_helper.execute_code(file_path=transformation_data['path'],function_name=transformation_data['function_name'],schema=schema, request_from="api")
                                if exec_resp['status'] == 'error':
                                    if "request_from" in kwargs and kwargs['request_from']=='api':  # For API
                                        return exec_resp
                                    else: # For NoteBook
                                        return exec_resp['message']
                                
                                data_frame = exec_resp['data_frame']  
                    else: # Passing the source dataset as data frame to target dataset
                        pass
                    
                    # Storing target File
                    timestamp = int(round(time.time() * 1000))
                    file_name = target_key + "_" + str(timestamp) + ".csv"

                    # Converting the data frame to CSV
                    data_frame_to_csv = data_frame.to_csv(index=False)
                    temp_dir = path.join(dataset_dir, file_name)
                    # Generating the target file
                    fh = open(temp_dir, "w")
                    fh.write(data_frame_to_csv)
                    fh.close()
                else:
                    file_name   = datasetObj['datasource']['target']['filename']
                    fileObj     = FileSchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, deleted=False)[0]
                    metadata    = fileObj.metadata
                    # Copying source file and moving it to target location
                    target_file_path = path.join(base_path,self.catalog_key,self.project_key,'datasets',self.dataset_key,datasetObj['datasource']['target']['filename'])
                    shutil.copy2(target_file_path, dataset_dir)
                # Copying source file and moving it to target location
                source_file_path = path.join(base_path,self.catalog_key,self.project_key,'datasets',self.dataset_key,datasetObj['datasource']['source'][0]['filename'])
                shutil.copy2(source_file_path, dataset_dir)  
                datasource = {
                    "type" : "file",
                    "source" : [{
                        "from" : "recipe",
                        "filename" : datasetObj['datasource']['source'][0]['filename'],
                        "format" : datasetObj['datasource']['source'][0]['format']
                    }],
                    "target" : {
                        "to" : path.join(dataset_dir, file_name),
                        "filename" : file_name
                    }
                }
                # Updating data into dataset
                datasetObj  = DatasetSchema.objects(key=target_key,catalog_key=self.catalog_key,project_key=self.project_key,deleted=False).modify(
                    new=True,
                    set__datasource = datasource,
                    set__path = preview_path,
                    set__is_build = True,
                    set__updated_at = datetime.now()
                )
                
                # Updating recipe is_build to True
                recipeObj  = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key=self.recipe_key, deleted=False).modify(
                    new=True,
                    set__is_build = True,
                    set__updated_at = datetime.now()
                )
                
                meta = {}
                meta['source_name']     = [datasetObj.datasource['source'][0]['filename']]
                meta['source_format']   = [datasetObj.datasource['source'][0]['format']]
                meta['target_name']     = file_name
                meta['path']            = preview_path
                meta['columns']         = data_frame.columns.tolist()
                meta['row_count']       = data_frame.shape[0]
                
                # Fetching dataset_key and target_key from recipe by recipe key
                file_data = FileSchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=target_key,deleted=False).to_json()
                file_data = loads(file_data)
                if len(file_data)==0:
                    # Default Sampling
                    default_records = environ.get('DEFAULT_RECORD_COUNT',None)
                    operation = {
                        'sampling': {
                            "name":"first",
                            "column_name":"",
                            "records": int(default_records),
                            "ratio":""
                        },
                        'freeze_column_index': [],
                        'filters': [],
                        'sorting': [],
                        'column_index': [],
                        'hide_column': [],
                        'date_format':[]
                    }
                    fileObj = FileSchema(dataset_key=target_key,metadata=meta,catalog_key=self.catalog_key,project_key=self.project_key,operation=operation)
                    fileObj.save()
                else:
                    # Updating data into dataset
                    fileObj = FileSchema.objects(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=target_key, deleted=False).modify(
                        new=True,
                        set__metadata = meta,
                        set__updated_at = datetime.now()
                    )
                
                arguments = {
                    "catalog_key": self.catalog_key,
                    "project_key": self.project_key,
                    "dataset_key": target_key
                    #"recipe_key": self.recipe_key # Recipe key is of source dataset we are passing which it should not be
                }
                result = dataset_helper.store_whole_meta(arguments)
                
                # Pipeline Update Target Dataset
                pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,target_key)
                pipeline_resp = pipelineObj.update()
                return dataset_helper.dataset_response(dataset=datasetObj)
            else:
                if "request_from" in kwargs:
                    if kwargs['request_from']=='api': # For API  
                        return ({'status':'error','message':'Missing required parameters'})
                    else: # For Notebook
                        return ('Missing required parameters')
                else: # For Notebook
                    return ('Missing required parameters')
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return str(e)
    