
class Exception(Exception):
    pass