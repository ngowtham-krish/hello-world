from os import environ
from sys import exc_info
from json import loads, dumps
from datetime import datetime 
from strait.core.dataset import Dataset
import strait.core.helper.dataset_helper as dataset_helper
from strait.core.model.schema import FileSchema, RecipeSchema

class Filter:
    def __init__(self, catalog_key=None, project_key=None, dataset_key=None, recipe_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API    
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = dataset_key 
        
        if recipe_key is None: # For Notebook or Custom Recipe
            self.recipe_key = environ.get('RECIPE_KEY',None) 
        else: # For API   
            self.recipe_key = recipe_key 
        
        self.file_schema = FileSchema
        self.recipe_schema = RecipeSchema

    def set_filters(self,**kwargs):
        try:
            if self.catalog_key is None or self.project_key is None or self.dataset_key is None:
                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                    return ({'status':'error','message':'Missing required parameters'})
                else: # For Notebook
                    return 'Missing required parameters'
            else:
                # Checking whether sampling or filter has been changes
                is_sampling_change = False
                is_filter_change = False
                
                operation = {
                    'filters': [],
                    'sorting': [],
                    'freeze_column_index': [],
                    'sampling': {},
                    'column_index': [],
                    'hide_column': [],
                    'date_format':[]
                }
                
                if self.recipe_key is None:
                    # Fetching Wrangling schema
                    file_obj = self.file_schema.objects(dataset_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).to_json()
                    file_obj = loads(file_obj)
                    data     = file_obj[0]['operation']
                else:
                    recipe_obj = self.recipe_schema.objects(key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).to_json()
                    recipe_obj = loads(recipe_obj)
                    data       = recipe_obj[0]['operation']
                
                # Have to prepare filters for date and have to add to two parameters data_type, format in case of date column only
                if 'filters' in kwargs.keys() and kwargs['filters'] is not None:
                    is_filter_change = True
                    filters = []
                    if len(kwargs['filters'])>0:
                        for item in kwargs['filters']:
                            if item['operator'] in ['ok','not_ok','empty']:
                                temp = {
                                    'column_name': item['column_name'],
                                    'operator': item['operator'],
                                    'catalog_key': self.catalog_key,
                                    'project_key': self.project_key,
                                    'dataset_key': self.dataset_key,
                                    'recipe_key': self.recipe_key
                                }
                                filters.append(temp)
                                if len(kwargs['filters'])==1:
                                    is_filter_change = False
                            else:
                                column_info_data = dataset_helper.column_info(recipe_key=self.recipe_key, dataset_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, column_name=item['column_name'])
                                if column_info_data['status'] in ['error']:
                                    return column_info_data
                                if len(column_info_data['data'])>0:
                                    column_info_data = column_info_data['data'][0]
                                    data_types = column_info_data['data_types']
                                    if data_types['type'] in ['date','timestamp']:
                                        if item['operator'] in ['in_between']:
                                            temp = {
                                                'column_name': item['column_name'],
                                                'operator': item['operator'],
                                                'start': item['start'],
                                                'end': item['end'],
                                                'data_type': data_types['type'],
                                                'format': data['date_format'][0]
                                            }
                                        else:
                                            temp = {
                                                'column_name': item['column_name'],
                                                'operator': item['operator'],
                                                'value': item['value'],
                                                'data_type': data_types['type'],
                                                'format': data['date_format'][0]
                                            }
                                        filters.append(temp)
                                    else:
                                        filters.append(item)
                        operation['filters'] = filters
                    else:
                        operation['filters'] = kwargs['filters']
                else:
                    operation['filters'] = data['filters']

                if 'freeze_column_index' in kwargs.keys() and kwargs['freeze_column_index'] is not None:
                    operation['freeze_column_index'] = kwargs['freeze_column_index']
                else:
                    operation['freeze_column_index'] = data['freeze_column_index']

                if 'sorting' in kwargs.keys() and kwargs['sorting'] is not None:
                    operation['sorting'] = kwargs['sorting']
                else:
                    operation['sorting'] = data['sorting']
                
                if 'sampling' in kwargs.keys() and kwargs['sampling'] is not None:
                    is_sampling_change = True
                    operation['sampling'] = kwargs['sampling']
                else:
                    operation['sampling'] = data['sampling']
                
                if 'column_index' in kwargs.keys() and kwargs['column_index'] is not None:
                    operation['column_index'] = kwargs['column_index']
                else:
                    operation['column_index'] = data['column_index']
                
                if 'hide_column' in kwargs.keys() and kwargs['hide_column'] is not None:
                    operation['hide_column'] = kwargs['hide_column']
                else:
                    operation['hide_column'] = data['hide_column']
                
                if 'date_format' in kwargs.keys() and kwargs['date_format'] is not None:
                    operation['date_format'] = kwargs['date_format']
                else:
                    if 'date_format' in data:
                        operation['date_format'] = data['date_format']
                
                if len(data)>0: # Data Exists (Update)
                    if self.recipe_key is None:
                        file_obj = self.file_schema.objects(dataset_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                            new=True, 
                            set__operation  = operation,
                            set__updated_at = datetime.now()
                        )
                    else:
                        recipe_obj = self.recipe_schema.objects(key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                            new=True, 
                            set__operation  = operation,
                            set__updated_at = datetime.now()
                        )

                    # Re calculating metadata in case of filters/sampling get changes
                    if 'filters' in kwargs.keys() and kwargs['filters'] is not None and 'sampling' in kwargs.keys() and kwargs['sampling'] is not None:
                        # Preparing Metadata
                        arguments = {
                            "catalog_key": self.catalog_key,
                            "project_key": self.project_key,
                            "dataset_key": self.dataset_key
                        }

                        if self.recipe_key is None:
                            arguments['recipe_key'] = self.recipe_key

                        res = dataset_helper.store_whole_meta(arguments)

                    # For Previeing the data
                    dataset_obj = Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                    dataset_resp= dataset_obj.preview(format="json", page_no=1, recipe_key=self.recipe_key, request_from=kwargs['request_from'],call_from='set_filters')
                    if dataset_resp['status'] in ['error']:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return dataset_resp
                        else: # For Notebook
                            return dataset_resp['message']
                    
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        if 'is_data_frame_empty' in dataset_resp and dataset_resp['is_data_frame_empty'] in ['no']: # Calling Metadata only if it has some data
                            if is_filter_change is True or is_sampling_change is True:
                                # Preparing Metadata
                                arguments = {
                                    "catalog_key": self.catalog_key,
                                    "project_key": self.project_key,
                                    "dataset_key": self.dataset_key,
                                    "recipe_key": self.recipe_key,
                                    "sampling": operation['sampling']
                                }
                                res = dataset_helper.store_whole_meta(arguments)

                        return ({'status': "success", 'data': dataset_resp['data'],'columns':dataset_resp['columns'],'row_count':dataset_resp['row_count'],'operation':operation})
                    else: # For Notebook
                        dataset_resp
                else:
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'catalog/project/dataset key is invalid'})
                    else: # For Notebook
                        return ("catalog/project/dataset key is invalid")
        except Exception as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)+ " at line "+str(exc_tb.tb_lineno)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e)+ " at line "+str(exc_tb.tb_lineno))
            else: # Fot Notebook
                return ("Exception: "+ str(e)+ " at line "+str(exc_tb.tb_lineno))

    def get_filters(self,**kwargs):
        try:
            if self.catalog_key is None or self.project_key is None or self.dataset_key is None:
                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                    return ({'status':'error','message':'Missing required parameters'})
                else: # For Notebook
                    return 'Missing required parameters'
            else:
                if self.recipe_key is None:
                    file_obj = self.file_schema.objects(dataset_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).to_json()
                    file_obj = loads(file_obj)
                    data     = file_obj[0]['operation']
                else:
                    recipe_obj = self.recipe_schema.objects(key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).to_json()
                    recipe_obj = loads(recipe_obj)
                    data       = recipe_obj[0]['operation']
            
                if len(data)>0: # Data Exists (Update)
                    response_data = {
                        'filters':data['filters'],
                        'sorting':data['sorting'],
                        'hide_column': data['hide_column'],
                        'freeze_column_index':data['freeze_column_index'],
                        'sampling':data['sampling'],
                        'column_index':data['column_index'],
                        'date_format':[]
                    }
                    if 'date_format' in data:
                        response_data['date_format'] = data['date_format']
                     
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'success','data':response_data})
                    else: # For Notebook
                        return response_data
                else:
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'catalog/project/dataset key is invalid'})
                    else: # For Notebook
                        return 'catalog/project/dataset key is invalid'
                    
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
        
        