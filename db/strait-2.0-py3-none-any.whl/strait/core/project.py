from os import environ
from json import loads, dumps
from datetime import datetime
import strait.core.dataset as dataset
import strait.core.helper.project_helper as project_helper
import strait.core.helper.catalog_helper as catalog_helper
from strait.core.model.schema import CatalogSchema,ProjectSchema,DatasetSchema,RecipeSchema

class Project:

    def __init__(self,catalog_key=None, project_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key
        
        self.catalog_schema = CatalogSchema
        self.project_schema = ProjectSchema
    
    # Create Project 
    def create(self,**kwargs):
        try:
            print("--- Inside create project ----"+str(self.catalog_key))
            if self.catalog_key is not None:
                if 'name' not in kwargs or kwargs['name'] is None:
                    return ({'status':'error','message':'project name is required'})
                else:
                    name = ""
                    key  = ""
                    description = ""
                    tags = []
                    updated_at = datetime.now()
                    created_at = datetime.now()
                    
                    # Validating project name exists or not
                    print("--- Calling project_name_exists ---")
                    project_resp = project_helper.project_name_exists(catalog_key=self.catalog_key, name=kwargs['name'])
                    if project_resp['status'] in ['error']:
                        return project_resp
                    project_name_len = len(project_resp['data'])
                    print("project_name_len "+str(project_name_len))
                    if project_name_len != 0:
                        name = kwargs['name'].strip()+"_"+str(project_name_len+1)
                    else:
                        name = kwargs['name'].strip()
                                
                    if self.project_key is None:
                        resp = catalog_helper.generate_key(name)
                        if resp['status'] in ['error']:
                            return resp
                        self.project_key = resp['key']
                    elif 'key' in kwargs.keys():
                        if kwargs['key'] != None:
                            self.project_key = kwargs['key']
                    
                    if 'description' in kwargs.keys():
                        if kwargs['description'] != None:
                            description = kwargs['description'].strip()
                    
                    if 'tags' in kwargs.keys():
                        if kwargs['tags'] != None:
                            tags = kwargs['tags'].split(",")

                    if 'created_at' in kwargs.keys():
                        if kwargs['created_at'] != None:
                            created_at = kwargs["created_at"]
                            
                    if 'updated_at' in kwargs.keys():
                        if kwargs['updated_at'] != None:
                            updated_at = kwargs["updated_at"]
                    print("---- name ----"+str(name))
                    print("--- self.project_key ---"+str(self.project_key))
                    projectObj = self.project_schema(name=name,key=self.project_key,catalog_key=self.catalog_key, description=description, tags=tags, created_at =created_at, updated_at=updated_at)
                    projectObj.save()
                    print("--- After create call ---")
                    project_helper.create_dataset_folder(self.catalog_key,projectObj.key)
                    print("--- kwargs['request_from'] -----"+str(kwargs['request_from']))
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        print("Inside API call")
                        return project_helper.project_response(projectObj)
                    else: # For Notebook
                        print("Inside Notebook call")
                        return projectObj.key
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"catalog name is required"})
                else: # For Notebook
                    return "catalog name is required"
        
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))
            
    # Update Project
    def update(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                # validating projectKey exists or not
                resp = project_helper.validate_project(self.catalog_key,self.project_key)
                if resp['status'] == 'error':
                    return resp
                
                name = ""
                description = ""
                tags = []

                if 'name' in kwargs.keys() and kwargs['name'] is not None:
                    # Validating project name exists or not
                    project_resp = project_helper.project_name_exists(catalog_key=self.catalog_key, name=kwargs['name'])
                    if project_resp['status'] in ['error']:
                        return project_resp
                    project_name_len = len(project_resp['data'])
                    print("project_name_len "+str(project_name_len))
                    if project_name_len != 0:
                        name = kwargs['name'].strip()+"_"+str(project_name_len+1)
                    else:
                        name = kwargs['name'].strip()
                
                if 'description' in kwargs.keys():
                    if kwargs['description'] != None:
                        description = kwargs['description'].strip()
                
                if 'tags' in kwargs.keys():
                    if kwargs['tags'] != None:
                        tags = kwargs['tags'].split(",")
                
                '''
                # Checking whether project name already exists or not
                if name!="":
                    project_list = self.project_schema.objects(catalog_key=self.catalog_key,deleted=False).to_json()
                    if len(list(loads(project_list))) > 0:
                        for item in list(loads(project_list)):
                            if name == item['name'] and item['key'] != self.project_key:
                                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                    return ({'status': 'error', 'message': 'project name already exists'})
                                else: # For Notebook
                                    return "'project name already exists'"
                    else:
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return ({'status': 'error', 'message': 'project key is invalid'})
                        else: # For Notebook
                            return ('project key is invalid')
                '''

                # Fetching data from projects collection by project and catalog key
                project_details = self.project_schema.objects(key=self.project_key,catalog_key=self.catalog_key,deleted=False).to_json()
                project_details = list(loads(project_details))[0]
                if name == "":
                    name = project_details['name']
                if description == "":
                    description = project_details['description']
                if len(tags) == 0:
                    tags = project_details['tags']

                # Updating data into projects collection
                project_resp = self.project_schema.objects(key=self.project_key,catalog_key=self.catalog_key,deleted=False).modify(
                                    new=True,
                                    set__name = name,
                                    set__description = description,
                                    set__tags = tags,
                                    set__updated_at = datetime.now()
                                )

                # Updating data into data catalog
                #catalogDetails = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}})
                #project_lists = list(loads(dumps(catalogDetails[0]['projects'])))
                catalog_lists = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, deleted=1, projects=1).to_json() # {'$elemMatch': {'key': self.project_key,'deleted':False}}
                catalog_lists = list(loads(catalog_lists))
                project_lists = catalog_lists[0]['projects']
                counter = 0
                for item in project_lists:
                    if item['key'] == self.project_key:
                        project_lists[counter]['name'] = name
                    counter = counter + 1
                updatedResponse = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update(set__projects=project_lists)
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return project_helper.project_response(project_resp)
                else: # For Notebook
                    return project_resp.key
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'message':"catalog/project key is required"})
                else: # For Notebook
                    return ("catalog/project key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))
    
    # Delete Project
    def delete(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                # validating projectKey exists or not
                resp = project_helper.validate_project(self.catalog_key,self.project_key)
                if resp['status'] == 'error':
                    return resp

                # Updating data into projects collection
                project_resp = self.project_schema.objects(key=self.project_key,catalog_key=self.catalog_key,deleted=False).modify(
                                    new=True,
                                    set__deleted = True,
                                    set__updated_at = datetime.now()
                                )

                # Updating data into data catalog
                catalog_lists = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, deleted=1, projects=1).to_json() # {'$elemMatch': {'key': self.project_key,'deleted':False}}
                catalog_lists = list(loads(catalog_lists))
                project_lists = catalog_lists[0]['projects']
                counter = 0
                for project_details in project_lists:
                    if project_details['key'] == self.project_key:
                        project_lists[counter]['deleted'] = True
                    counter = counter + 1
                updatedResponse = CatalogSchema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update_one(set__projects=project_lists)
                
                # Updating data into dataset schema 
                dataset_lists = DatasetSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,deleted=False).to_json()
                dataset_lists = loads(dataset_lists)
                # Checking whether dataset exists or not
                if len(dataset_lists)>0:
                    dataset_keys = []
                    for item in dataset_lists:
                        dataset_keys.append(item['key'])
                    for item in dataset_keys:
                        dataset_obj = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=item)
                        resp = dataset_obj.delete(request_from='api',call_from='delete_project')
                        if resp['status'] in['error']:
                            return resp 
                        else:
                            for item in dataset_keys:
                                if item in resp['dataset_key']:
                                    dataset_keys.remove(item)

                    '''
                    dataset_resp = DatasetSchema.objects(project_key=self.project_key,catalog_key=self.catalog_key,deleted=False).update(
                                set__deleted = True,
                                set__updated_at = datetime.now()
                            )
                    
                    for item in dataset_keys:
                        recipe_lists = RecipeSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,source_key=item,deleted=False).to_json()
                        recipe_lists = list(loads(recipe_lists))
                        # Checking whether recipe exists or not
                        if len(recipe_lists)>0:
                            recipe_resp = RecipeSchema.objects(project_key=self.project_key,catalog_key=self.catalog_key,source_key=item,deleted=False).update(
                                set__deleted = True,
                                set__updated_at = datetime.now()
                            )
                    '''

                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    #return project_helper.project_response(project_resp) 
                    return ({'status':'success','message':'project '+str(self.project_key.replace("_"," "))+' deleted successfully'}) 
                else: # For Notebook
                    return 'project '+str(self.project_key.replace("_"," "))+' deleted successfully'  
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'message':"catalog/project key is required"})
                else: # For Notebook
                    return ("catalog/project key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))

    # Project Lists
    def lists(self,**kwargs):
        try:
            if self.catalog_key!=None:
                # Fetching data from projects collection by project and catalog key
                project_lists = self.project_schema.objects(catalog_key=self.catalog_key,deleted=False).to_json()
                project_lists = list(loads(project_lists))
                project_list  = []  
                for item in project_lists:
                    tempObj = {
                        'projectKey' : item['key'],
                        'name' : item['name'].strip(),
                        'deleted' : item['deleted'],
                        'tags' : item['tags'],
                        'updatedAt' : datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S')
                    }
                    project_list.append(tempObj)
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"success",'data':project_list})
                else: # For Notebook
                    pass
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'message':"catalog key is required"})
                else: # For Notebook
                    return ("catalog key is required") 
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))    