from strait.celery_app import celery_app
# from strait.core.helper.dataset_helper import df_column_uniquify, column_menu, metadata
from json import loads , dump, dumps
from strait.core.model.schema import  FileSchema, ColumnInfoSchema
from strait.environment import load_env
load_env()
from pandas import read_csv
from strait.core.model.config import *
import strait.core.dataset as dataset
import strait.core.helper.dataset_helper as ds_helper
import strait.core.helper.catalog_helper as ct_helper
from os import path,makedirs
import pyarrow

from datetime import datetime

@celery_app.task
def metadata_task(args):
    if 'path' in args and args["path"] != None:
        data_frame = read_csv(args["path"])
    else:
        dataset_d = dataset.Dataset(args["catalog_key"], args["project_key"], args["dataset_key"])
        if "recipe_key" in args and args["recipe_key"] is not None:
            data_frame = dataset_d.preview(recipe_key= args["recipe_key"],request_from='notebook')
        else:
            data_frame = dataset_d.preview(request_from='notebook')
    resp = ds_helper.df_column_uniquify(data_frame)
    if resp['status'] == 'error':
        return resp
    data_frame = resp['data_frame']
    res = predict_types(args, data_frame)

@celery_app.task
def column_level_task(args, col):
    _id = {}
    if 'path' in args and args["path"] != None:
        data_frame = read_csv(args["path"])
    else:
        dataset_d = dataset.Dataset(args["catalog_key"], args["project_key"], args["dataset_key"])
        if "recipe_key" in args and args["recipe_key"] is not None:
            data_frame = dataset_d.preview(recipe_key= args["recipe_key"],request_from='notebook')
        else:
            data_frame = dataset_d.preview(request_from='notebook')
    resp = ds_helper.meta_data.predict_types_new(data_frame, _id, col)
    oknotok = resp["ok_notok"]
    del resp["ok_notok"]
    base_path = environ.get('STORAGE',None)
    # Making catalog folder to store respective projects inside that
    dataset_dir = path.join(base_path,args["catalog_key"],args["project_key"],'datasets',args["dataset_key"])
    ok_not_ok_dir = path.join(dataset_dir,'ok_not_ok')
    if not path.exists(ok_not_ok_dir):
        makedirs(ok_not_ok_dir) 
    response = ct_helper.generate_key(col.strip())
    key = response['key']
    target_filename = "%s_oknotok"%key
    if "recipe_key" in args and args["recipe_key"] is not None:
        target_filename = target_filename +"_" +args["recipe_key"]
    target_file_name = target_filename + ".json"
    path_dir = path.join(ok_not_ok_dir, target_file_name)
    
    with open(path_dir, 'w') as metadata_file:
        dump(oknotok, metadata_file)
    if "recipe_key" in args and args["recipe_key"] is not None:
        columnObj = ColumnInfoSchema.objects(column_name=str(col), recipe_key=args["recipe_key"] , dataset_key=args["dataset_key"] ,catalog_key= args["catalog_key"],project_key=args["project_key"]).to_json()     
    else:
        columnObj = ColumnInfoSchema.objects(column_name=str(col), dataset_key=args["dataset_key"] ,catalog_key= args["catalog_key"],project_key=args["project_key"]).to_json()
    
    if len(loads(columnObj)) == 0:
        if "recipe_key" in args and args["recipe_key"] is not None:
            col_obj = ColumnInfoSchema(column_name=str(col), oknotok=path_dir, recipe_key=args["recipe_key"], dataset_key=args["dataset_key"] ,catalog_key= args["catalog_key"],project_key=args["project_key"], metadata=resp)
            col_obj.save()
        else:
            col_obj = ColumnInfoSchema(column_name=str(col), oknotok=path_dir, dataset_key=args["dataset_key"] ,catalog_key= args["catalog_key"],project_key=args["project_key"], metadata=resp)
            col_obj.save()
    else:
        if "recipe_key" in args and args["recipe_key"] is not None:
            modify = ColumnInfoSchema.objects(column_name=str(col), recipe_key=args["recipe_key"], dataset_key=args["dataset_key"] ,catalog_key= args["catalog_key"],project_key=args["project_key"]).modify(
                new=True,
                set__oknotok = path_dir,
                set__metadata = resp,
                set__updated_at = datetime.now()
            )
        else:
            modify = ColumnInfoSchema.objects(column_name=str(col), dataset_key=args["dataset_key"] ,catalog_key= args["catalog_key"],project_key=args["project_key"]).modify(
            new=True,
            set__oknotok = path_dir,
            set__metadata = resp,
            set__updated_at = datetime.now()
        )

def predict_types(args, df):
    a = datetime.now()
    for col in df.columns:
        column_level_task.delay(args, col)
