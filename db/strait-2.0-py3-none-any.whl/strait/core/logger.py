import logging

class StraitLog:

    def __init__(self):
        logging.basicConfig(filename='app.log', filemode='w', format='%(name)s - %(levelname)s - %(message)s')
    
    def warning(self, msg):
        logging.warning(msg)
    
    def info(self, msg):
        logging.info(msg)
    
    def error(self, msg):
        logging.error(msg)


