import random
import pandas as pd 
import numpy as np
from os import environ

class Sampling:

    # Sampling for first N number of records
    def first_n_records(self,dataframe,n=500):
        """ Takes the first N rows of the dataset. Dataframe is required parameter and n is optioanl """
        return dataframe.head(n)
   
    # Sampling for last N number of records
    def last_n_records(self,dataframe, n=500):
        """ Takes the last N rows of the dataset. Dataframe is required parameter and n is optioanl """
        return dataframe.tail(n)
   
    # Sampling for random N number of records
    def random_n_records(self,dataframe, n=500, replace=False, random_state=None):
        """ Randomly selectes N number of rows from the dataset. Dataframe is required parameter and n is optioanl """
        return dataframe.sample(n=n, replace=replace, random_state = random_state)
   
    # Sampling for random N percentage/ratio of records
    def random_approx_ratio(self,dataframe, ratio=2,replace=False, random_state=None):
        """ Randomly selects approximately X% of the rows. Dataframe is required parameter and ratio is optioanl """
        percent = (ratio/100)
        return dataframe.sample(frac=percent, replace=replace, random_state = random_state)
   
    # Sampling for stratified N number of records
    def stratified_nb_records(self,dataframe,column_name,records=500):
        """ Randomly selects N rows, ensuring that the repartition of values in a column is respected in the sampling. Ensures that all modalities of the column appear in the output. May return a few more than N rows. Dataframe, column name are required parameters and n is optional"""
        total_record= dataframe.shape[0]
        if records >= total_record:
            return dataframe
        unique_list = dataframe[column_name].unique()
        temp_df     = pd.DataFrame()
        data_frame  = pd.DataFrame()
        i           = 0 
        for val in unique_list:
            temp_df.loc[i,'ratio']   = dataframe[dataframe[column_name] == val].shape[0]/total_record
            temp_df.loc[i, 'value']  = val
            if temp_df.loc[i,'ratio'] * records < 1:
                temp_df.loc[i, 'nb_rec'] = 1
            else:
                temp_df.loc[i, 'nb_rec'] = temp_df.loc[i,'ratio'] * records
            temp_df['nb_rec']        = temp_df['nb_rec'].astype(int)
            df2        = dataframe[dataframe[column_name] == val]
            sampled_df = pd.DataFrame()
            if df2.empty == False:
                sampled_df = df2.sample(n = temp_df.loc[i, 'nb_rec'])
            data_frame = pd.concat([data_frame, sampled_df], axis = 0)
            i +=1
        return data_frame
    
    # Sampling for stratified N percentage/ratio of records
    def stratified_nb_ratio(self,dataframe,column_name,percentage=2):
        """ Randomly selects X% of the rows, ensuring that the repartition of values in a column is respected in the sampling. Ensures that all modalities of the column appear in the output. May return a bit more than X% rows. Dataframe, column name are required parameters and ratio is optional"""
        total_record = dataframe.shape[0]
        nb_rec  = (percentage * total_record) / 100
        if percentage >= 100:
            return dataframe
        unique_list = dataframe[column_name].unique()
        temp_df     = pd.DataFrame()
        data_frame  = pd.DataFrame()
        i           = 0 
        for val in unique_list:
            temp_df.loc[i,'ratio']   = dataframe[dataframe[column_name] == val].shape[0]/total_record
            temp_df.loc[i, 'value']  = val
            if temp_df.loc[i,'ratio'] * percentage < 1:
                temp_df.loc[i, 'nb_rec'] = 1
            else:
                temp_df.loc[i, 'nb_rec'] = temp_df.loc[i,'ratio'] * nb_rec
            temp_df['nb_rec'] = temp_df['nb_rec'].astype(int)
            df2        = dataframe[dataframe[column_name] == val]
            sampled_df = pd.DataFrame()
            if df2.empty == False:
                sampled_df = df2.sample(n = temp_df.loc[i, 'nb_rec'])
            data_frame = pd.concat([data_frame, sampled_df], axis = 0)
            i +=1
        return data_frame
    
    # Sampling for rebalance N number of records
    def rebalance_nb_records(self,dataframe,column_name,records=500):
        """ Randomly selects approximately N rows, trying to rebalance equally all modalities of a column. Does not oversample, only undersample (so some rare modalities may remain under-represented). Dataframe, column name are required parameters and records is optional"""
        if records >= dataframe.shape[0]:
            return dataframe
        unique_list = dataframe[column_name].unique()
        unique_list_len = len(unique_list)
        if (records / unique_list_len) < 1:
            sampling_n  = 1
        else:
            sampling_n = int(records / unique_list_len)
        data_frame  = pd.DataFrame()
        if len(unique_list) > 0:
            for val in unique_list:
                temp_df    = dataframe[dataframe[column_name] == val]
                if temp_df.shape[0] < sampling_n:
                    sampling_n = temp_df.shape[0]
                sampled_df = pd.DataFrame()
                if temp_df.empty==False:
                    sampled_df = temp_df.sample(n = sampling_n)
                data_frame = pd.concat([data_frame, sampled_df], axis = 0)
        return data_frame
    
    # Sampling for rebalance N percentage/ratio of records
    def rebalance_nb_ratio(self,dataframe,column_name,ratio=2):
        """ Randomly selects approximately X% of the rows, trying to rebalance equally all modalities of a column. Does not oversample, only undersample (so some rare modalities may remain under-represented). Rebalancing is not exact. Dataframe, column name are required parameters and ratio is optional"""
        if ratio >= 100:
            return dataframe
        total_record= int((dataframe.shape[0] * ratio) / 100)
        unique_list = dataframe[column_name].unique()
        unique_list_len = len(unique_list)
        if (total_record / unique_list_len) < 1:
            sampling_n  = 1
        else:
            sampling_n  = int(total_record / unique_list_len)
        data_frame  = pd.DataFrame()
        if len(unique_list) > 0:
            for val in unique_list:
                temp_df    = dataframe[dataframe[column_name] == val]
                if temp_df.shape[0] < sampling_n:
                    sampling_n = temp_df.shape[0]
                sampled_df = pd.DataFrame()
                if temp_df.empty==False:
                    sampled_df = temp_df.sample(n = sampling_n)
                data_frame = pd.concat([data_frame, sampled_df], axis = 0)
        return data_frame

    # Sampling for rebcolumn value subsetalance N number of records
    def column_value_subset(self,dataframe,column_name,nb_rec=500):
        """ Randomly selects a subset of values and chooses all rows with these values, in order to obtain approximately N rows. This is useful for selecting a subset of customers, for example.  Dataframe, column name are required parameters and records is optional"""
        final_df = pd.DataFrame()
        if nb_rec > dataframe.shape[0]:
            return dataframe
        unique_list = np.nan_to_num(dataframe[column_name].unique())
        no_of_unique = len(unique_list)
        if no_of_unique == 1:
            temp_df = pd.DataFrame()
            value = unique_list[0]
            temp_df = dataframe[dataframe[column_name] == value]
            if temp_df.empty == False:
                final_df = temp_df.sample(n = nb_rec)
        else:
            rand_num = np.random.randint(no_of_unique)
            while (rand_num == 0):
                rand_num = np.random.randint(no_of_unique)
            subset_values = random.sample(list(unique_list), rand_num)
            nb_rec_array = np.random.multinomial(nb_rec, [1/rand_num]*rand_num, size=1)
            obj = {'value' : list(subset_values), 'num_of_rec' : list(nb_rec_array[0])}
            df_nb_rec = pd.DataFrame.from_dict(obj)
            sampled_df = pd.DataFrame()
            for val in df_nb_rec['value']:
                df2 = dataframe[dataframe[column_name] == val]
                if df2.empty == False:
                    temp_array = list(df_nb_rec[df_nb_rec['value'] == val]['num_of_rec'])
                    if df2.shape[0] > temp_array[0]:
                        sample_size = temp_array[0]
                    else:
                        sample_size = df2.shape[0]
                    sampled_df = df2.sample(n = sample_size)
                final_df = pd.concat([final_df, sampled_df], axis = 0)
        return final_df 
    
    # Method for to get the sampling based on the sampling name passed
    def get_sample_data(self, dataframe,sampling_data={}):
        """ Get sampling data based on sampling name passed. If sampling name is blank then default sampling will be taken """
        records = int(environ.get('DEFAULT_RECORD_COUNT',None))
        ratio   = int(environ.get('DEFAULT_SAMPING_RATIO',None))
        
        if len(sampling_data)==0: # If sampling data is empty
            return self.first_n_records(dataframe,n=records)
        else:
            if sampling_data['name'] == "first":
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.first_n_records(dataframe,records)
                else:    
                    return self.first_n_records(dataframe,sampling_data['records'])
            elif sampling_data['name'] == 'last':
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.last_n_records(dataframe,records)
                else:    
                    return self.last_n_records(dataframe,sampling_data['records'])
            elif sampling_data['name'] == 'random_records':
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.random_n_records(dataframe,records)
                else:
                    return self.random_n_records(dataframe,sampling_data['records'])
            elif sampling_data['name'] == 'random_ratio':
                if sampling_data['ratio']=='' or sampling_data['ratio'] is None:
                    return self.random_approx_ratio(dataframe,ratio)
                else:
                    return self.random_approx_ratio(dataframe,sampling_data['ratio'])
            elif sampling_data['name'] == 'stratified_records':
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.stratified_nb_records(dataframe,sampling_data['column_name'],records)
                else:
                    return self.stratified_nb_records(dataframe,sampling_data['column_name'],sampling_data['records'])
            elif sampling_data['name'] == 'stratified_ratio':
                if sampling_data['ratio']=='' or sampling_data['ratio'] is None:
                    return self.stratified_nb_ratio(dataframe,sampling_data['column_name'],ratio)
                else:
                    return self.stratified_nb_ratio(dataframe,sampling_data['column_name'],sampling_data['ratio'])
            elif sampling_data['name'] == 'rebalance_records':
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.rebalance_nb_records(dataframe,sampling_data['column_name'],records)
                else:
                    return self.rebalance_nb_records(dataframe,sampling_data['column_name'],sampling_data['records'])
            elif sampling_data['name'] == 'rebalance_ratio':
                if sampling_data['ratio']=='' or sampling_data['ratio'] is None:
                    return self.rebalance_nb_ratio(dataframe,sampling_data['column_name'],ratio)
                else:
                    return self.rebalance_nb_ratio(dataframe,sampling_data['column_name'],sampling_data['ratio'])
            elif sampling_data['name'] == 'column_value_subset':
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.column_value_subset(dataframe,sampling_data['column_name'],records)
                else:
                    return self.column_value_subset(dataframe,sampling_data['column_name'],sampling_data['records'])
            else:
                if sampling_data['records']=='' or sampling_data['records'] is None:
                    return self.first_n_records(dataframe,records)
                else:    
                    return self.first_n_records(dataframe,sampling_data['records'])
     