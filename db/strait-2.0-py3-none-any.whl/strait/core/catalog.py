from os import environ
from json import loads, dumps
from datetime import datetime
from strait.core.model.schema import CatalogSchema
import strait.core.helper.catalog_helper as catalog_helper

class Catalog:

    def __init__(self, catalog_key=None, project_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key
        
        self.catalog_schema = CatalogSchema
        
    # Creating Catalog
    def create_catalog(self, **kwargs):
        try:
            if 'name' in kwargs and kwargs['name'] is not None:
                if self.catalog_key is None:
                    resp = catalog_helper.generate_key(kwargs['name'].strip())
                    if resp['status'] in ['error']:
                        return resp
                    self.catalog_key = resp['key']
                catalogObj = self.catalog_schema(name=kwargs['name'].strip(),key=self.catalog_key)
                catalogObj.save()
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return catalog_helper.catalog_response(catalogObj)
                else: # For Notebook
                    return str(catalogObj.key)
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']:
                    return ({'status':'error','message':'catalog name is required'})
                else: # For Notebook
                    return ("catalog name is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))

    # Update Catalog
    def update_catalog(self,**kwargs):
        try:
            if self.catalog_key is not None and self.catalog_key != '' :
                name = None
                if 'name' in kwargs.keys():
                    if kwargs['name'] != None:
                        name = kwargs['name'].strip()
                
                # Name can be duplicate key should be unique
                '''
                catalog_lists = []
                # Checking whether catalog name already exists
                if name != None:
                    catalog_lists = self.catalog_schema.objects(deleted=False).to_json()
                    if len(list(loads(catalog_lists))) > 0:
                        for item in list(loads(catalog_lists)):
                            if name == item['name'] and item['key'] != catalog_key:
                                return ({'status': 'error', 'message': 'catalog name already exists'})
                    else:
                        return ({'status': 'error', 'message': 'catalog key is invalid'})
                '''
                
                # Fetching Catalog Details
                catalog_details = self.catalog_schema.objects(key=self.catalog_key,deleted=False).to_json()
                catalog_details = list(loads(catalog_details))
                
                if name==None:
                    name = catalog_details[0]['name']
                
                # Updating data into data catalog
                catalogObj  = self.catalog_schema.objects(key=self.catalog_key).modify(
                    new=True,
                    set__name = name,
                    set__updated_at = datetime.now()
                )
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']:
                    return catalog_helper.catalog_response(catalogObj)
                else:
                    return str(catalogObj.key)
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']:
                    return ({'status':"error",'messsage':"catalog name is required"})
                else:
                    return ("catalog name is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))

    # Delete Catalog
    def delete_catalog(self,**kwargs):
        try:
            if self.catalog_key is not None and self.catalog_key != '' :
                # Updating data into data catalog
                catalogObj  = self.catalog_schema.objects(key=self.catalog_key).update(
                    set__deleted = True,
                    set__updated_at = datetime.now()
                )
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':'success','message':'catalog '+str(self.catalog_key.replace("_"," "))+' deleted successfully'}) 
                else: # For Notebook
                    return 'catalog '+str(self.catalog_key.replace("_"," "))+' deleted successfully'
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"catalog key is required"})
                else: # For Notebook
                    return ("catalog key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))

    # Catalog Lists
    def catalog_lists(self,**kwargs):
        try:
            # Fetching catalog Lists
            catalog_list  = self.catalog_schema.objects(deleted=False).to_json()
            catalog_list  = list(loads(catalog_list))
            catalog_resp  = [] 
            if len(catalog_list)>0:
                for item in catalog_list:
                    temp = {
                        'name': item['name'].strip(),
                        'key': item['key'],
                        'deleted': item['deleted']
                    }
                    catalog_resp.append(temp)
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status':'success','data':catalog_resp})
            else:
                pass
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))
    
    # Create Experiment
    def create_experiment(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                experimentId = None
                experimentName = None
                if 'experimentId' in kwargs.keys() and kwargs['experimentId'] is not None:
                    experimentId = kwargs['experimentId']
                
                if 'experimentName' in kwargs.keys() and kwargs['experimentName'] is not None:
                    experimentName = kwargs['experimentName'].strip()
                
                data = {
                    'id' : experimentId if experimentId!=None else "",
                    'name' : experimentName if experimentName!=None else "",
                    'deleted' : False 
                }

                catalog_lists = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).to_json()
                #catalog_lists = CatalogSchema.objects(key=catalog_key,deleted=False,projects={'$elemMatch': {'key': project_key,'deleted':False}}).to_json()
                catalog_lists = list(loads(catalog_lists))
                experiment_lists = catalog_lists[0]['projects'][0]['experiments']
                experiment_lists.append(data)
                updatedResponse = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update_one(set__projects__S__experiments=experiment_lists)
                if updatedResponse:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({'status':"success",'message':"Experiment created successfully"})
                    else: # For Notebook
                        return ("Experiment created successfully")
                else:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({'status':"error","message":"Some error while creating experiment in catalog"})
                    else: # For Notebook
                        return ("Some error while creating experiment in catalog")
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"catalog and project key is required"})
                else:
                    return ("catalog and project key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))
    
    # Update Experiment
    def update_experiment(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                experimentId = None
                experimentName = None
                if 'experimentId' in kwargs.keys():
                    if kwargs['experimentId'] != None:
                        experimentId = kwargs['experimentId']
                
                if 'experimentName' in kwargs.keys():
                    if kwargs['experimentName'] != None:
                        experimentName = kwargs['experimentName'].strip()
                
                if experimentId!=None:
                    catalog_lists = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).to_json()
                    catalog_lists = list(loads(catalog_lists))
                    experiment_lists = catalog_lists[0]['projects'][0]['experiments']
                    counter = 0
                    flag = 0
                    for item in experiment_lists:
                        if item['id']==experimentId:
                            flag = 1
                            if experimentName!=None:
                                experiment_lists[counter]['name'] = experimentName
                        counter = counter + 1 

                    if flag == 1:
                        updatedResponse = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update_one(set__projects__S__experiments=experiment_lists)
                        if updatedResponse:
                            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                return ({'status':"success",'message':"Experiment updated successfully"})
                            else: # For Notebook
                                return ("Experiment updated successfully")
                        else:
                            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                return ({'status':"error",'message':"Some error while creating experiment in catalog"})
                            else: # For Notebook
                                return ("Some error while creating experiment in catalog")
                    else:
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return ({'status':"error",'message':"experimentId is invalid or does not exists"})
                        else: # For Notebook
                            return ("experimentId is invalid or does not exists")
                else:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({'status':"error",'message':"experimentId is required"})
                    else: # For Notebook
                        return ("experimentId is required")
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"catalog and project key is required"})
                else:
                    return ("catalog and project key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))

    # Delete Experiment
    def delete_experiment(self,**kwargs):
        try:
            if self.catalog_key!=None and self.project_key!=None: 
                experimentId = kwargs['experimentId']
                catalog_lists = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).to_json()
                #catalog_lists = CatalogSchema.objects(key=catalog_key,deleted=False,projects={'$elemMatch': {'key': project_key,'deleted':False}}).to_json()
                catalog_lists = list(loads(catalog_lists))
                experiment_lists = catalog_lists[0]['projects'][0]['experiments']
                counter = 0
                flag = 0
                for item in experiment_lists:
                    if item['id']==experimentId:
                        flag = 1
                        experiment_lists[counter]['deleted'] = True
                    counter = counter + 1 
                
                if flag == 1:
                    updatedResponse = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update_one(set__projects__S__experiments=experiment_lists)
                    if updatedResponse:
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return ({'status':"success",'message':"Experiment deleted successfully"})
                        else: # For Notebook
                            return ("Experiment deleted successfully")
                    else:
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return ({'status':"error","message":"Some error while creating experiment in catalog"})
                        else: # For Notebook
                            return ("Some error while creating experiment in catalog")
                else:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({"status":"error","message":"experimentId is invalid or does not exists"})
                    else: # For Notebook
                        return ("experimentId is invalid or does not exists")
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"catalog and project key is required"})
                else: # For Notebook
                    return("catalog and project key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))

    # Experiment Lists
    def experiment_list(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None:
                catalog_lists = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).to_json()
                catalog_lists = list(loads(catalog_lists))
                experiment_lists = catalog_lists[0]['projects'][0]['experiments']
                exp_lists = []
                for item in experiment_lists:
                    tempObj = {
                        'id': item['id'],
                        'name': item['name'].strip()
                    }
                    exp_lists.append(tempObj)
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"success",'data':exp_lists})
                else: # For Notebook
                    pass
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"catalog and project key is required"})
                else: # For Notebook
                    return ("catalog and project key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For Notebook
                return ("Exception: "+str(e))
