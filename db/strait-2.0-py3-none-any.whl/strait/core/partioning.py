
class Partioning:

    def __init__(self ):
        pass