from os import environ
from strait.environment import load_env
from strait.core.providers import API, File, FTP, HDFS, SQL, NoSQL

# Calling Enviroment Function
load_env()

class Connectors:
    def __init__(self,catalog_key=None, project_key=None, dataset_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = dataset_key 
        
    
    def NoSQL(self, config):
        return NoSQL()
    
    def HDFS(self, config):
        return HDFS()
    
    def FTP(self, config):
        return FTP()
    
    # For File (CSV/XLS/XLSX)
    def FileSystem(self,**kwargs):
        if self.catalog_key is not None and self.catalog_key is not None and self.catalog_key is not None:
            if 'file_type' in kwargs and kwargs['file_type'] is not None:
                if kwargs['source_type'] in ["file",'predicted','custom']:
                    file_object = File(self.catalog_key,self.project_key,self.dataset_key)
                    config = {
                        "source_type":kwargs['file_type'],
                        "type": "file",
                        "source": [{
                            "from": kwargs['source_type'],
                            "filename": "",
                            "format": ""
                        }],
                        "target": {
                            "to": "",
                            "filename": "",
                            "format": ""
                        }
                    }
                    if kwargs['source_type'] in ['predicted']:
                        config['add_to_pipeline'] = False
                    if kwargs['file_type'] in ['csv']: # For CSV 
                        if 'file' in kwargs and kwargs['file'] is not None:
                            file_obj      = kwargs['file']
                            file_type = file_obj.filename.split(".")
                            config["type"] = kwargs['source_type']
                            config["source"][0]["filename"] = file_obj.filename
                            config["source"][0]["format"] = file_type[1]
                            res = file_object.from_csv(config=config, 
                                                       header_column_exists=kwargs['header_column_exists'], 
                                                       file=file_obj,
                                                       skip_lines=kwargs['skip_lines'],
                                                       delimiter=kwargs['delimiter'])
                            return res
                        else:
                            return ({'status':'error','message':'file is required'})
                    elif kwargs['file_type'] in ['xls','xlsx']: # For XLSX/XLS
                            file_obj      = kwargs['file']
                            config["type"] = kwargs['source_type']
                            res = file_object.from_xls(sheet=kwargs['sheet'], 
                                                       config=config, 
                                                       header_column_exists=kwargs['header_column_exists'], 
                                                       file=file_obj,
                                                       file_type=kwargs['file_type'],
                                                       skip_lines=kwargs['skip_lines'],
                                                       given_sheet_name=kwargs['given_sheet_name'])
                            return res
                    elif kwargs['source_type'] in ['custom']: # For Data Frame
                        res = file_object.from_custom(config=config, 
                                                      header_column_exists=kwargs['header_column_exists'], 
                                                      data_frame=kwargs['data_frame'],
                                                      skip_lines=kwargs['skip_lines'])
                        return res
                    '''
                    elif kwargs['source_type'] in ['file_path']:
                        config['source'][0]['from'] = 'upload'
                        res = file_object.from_filepath(config=config, header_column_exists=kwargs['header_column_exists'], file=file_obj)
                        return res 
                    '''
                else:
                    return ({'status':'error','message':'Source type is required'})
            else:
                return ({'status':'error','message':'File type is required'})
        else:
            return ({'status':'error','message':'Missing required parameters'})

    def sql(self, **kwargs):
        print("--- Inside sql in connectors methods -----")
        if 'table_details' in kwargs and kwargs['table_details'] is not None:
            table_details = kwargs['table_details']
            sql_object = SQL(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
            config = {
                "source_type":kwargs['database_engine'],
                "type": "database",
                "source": [{
                    "from": kwargs['database_engine'],
                    "filename": table_details['data'],
                    "schema": table_details['schema'],
                    "format": kwargs['file_extension']
                }],
                "target": {
                    "to": "",
                    "filename": "",
                    "format": ""
                }
            }
            print("---- config ----")
            print(config)
            res = sql_object.save(config=config, table_details=kwargs['table_details'], file_extension=kwargs['file_extension'])
            return res
        else:
            return ({'status':'error','message':'Missing required parameters'})
    

    def API(self, config):
        return API()
    
