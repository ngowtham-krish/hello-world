

class HDFS:

    def __init__(self):
        print("Initializing HDFS Connector")
        raise NotImplementedError