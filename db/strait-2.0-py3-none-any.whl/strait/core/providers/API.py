
class API:

    def __init__(self):
        print("Initializing API Connector")
        raise NotImplementedError