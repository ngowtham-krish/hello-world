import time, shutil
import pandas as pd
from pyarrow import csv, parquet, Table
from strait.environment import load_env
import strait.core.providers.storage as storage
from os import path, getcwd, makedirs, environ, rename, remove
import strait.core.helper.dataset_helper as dataset_helper

# Calling Enviroment Function
load_env()

class File:

    def __init__(self,catalog_key=None, project_key=None, dataset_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = dataset_key
        
    # For Custom/Data Frame    
    def from_custom(self, **kwargs):
        data_frame = kwargs['data_frame']
        config = kwargs['config']
        # Writing Source File

        file_path_obj  = storage.Storage(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
        file_path_resp = file_path_obj.save(data_frame=data_frame, 
                                            header_column_exists=kwargs['header_column_exists'], 
                                            file_type='custom',
                                            skip_lines=kwargs['skip_lines'])
        if file_path_resp['status'] in ['error']:
            return file_path_resp

        config["source"][0]["filename"] = file_path_resp['source_file_name']
        config["source"][0]["format"]   = file_path_resp['source_file_type']
        config["target"]["filename"]    = file_path_resp['target_file_name']
        config["target"]["to"]          = file_path_resp['target_file_path']
        config["target"]["format"]      = file_path_resp['target_file_type']
        return ({'status':'success', 'config':config,'row_count':file_path_resp['row_count']}) 
    
    # For CSV
    def from_csv(self,**kwargs):
        config = kwargs['config']
        file_obj = kwargs['file']
        file_path_obj  = storage.Storage(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
        file_path_resp = file_path_obj.save(file=file_obj,
                                            header_column_exists=kwargs['header_column_exists'],
                                            file_type='csv',
                                            skip_lines=kwargs['skip_lines'],
                                            delimiter=kwargs['delimiter'])
        if file_path_resp['status'] in ['error']:
            return file_path_resp

        config["source"][0]["filename"] = file_path_resp['source_file_name']
        config["source"][0]["format"]   = file_path_resp['source_file_type']
        config["target"]["filename"]    = file_path_resp['target_file_name']
        config["target"]["to"]          = file_path_resp['target_file_path']
        config["target"]["format"]      = file_path_resp['target_file_type']
        return ({'status':'success', 'config':config,'row_count':file_path_resp['row_count']}) 

    # For XLSX/XLS
    def from_xls(self,**kwargs):
        config = kwargs['config']
        file_obj = kwargs['file']
        file_path_obj  = storage.Storage(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
        file_path_resp = file_path_obj.save(file=file_obj, 
                                            sheet=kwargs['sheet'], 
                                            header_column_exists=kwargs['header_column_exists'], 
                                            file_type=kwargs['file_type'], 
                                            skip_lines=kwargs['skip_lines'],
                                            given_sheet_name=kwargs['given_sheet_name'])
        if file_path_resp['status'] in ['error']:
            return file_path_resp
        
        config["source"][0]["filename"] = file_path_resp['source_file_name']
        config["source"][0]["format"]   = file_path_resp['source_file_type']
        config["target"]["filename"]    = file_path_resp['target_file_name']
        config["target"]["to"]          = file_path_resp['target_file_path']
        config["target"]["format"]      = file_path_resp['target_file_type']
        return ({'status':'success', 'config':config,'row_count':file_path_resp['row_count']}) 

    # From File path
    def from_filepath(self,config,source):
        timestamp        = int(round(time.time() * 1000))
        file_path        = path.abspath(source['file'])
        temp_file_path   = file_path.split('\\')
        temp_file_name   = temp_file_path[-1].split('.')
        source_file_name = temp_file_name[0] + "-"+ str(timestamp) +"."+ temp_file_name[1]
        temp_file_path   = shutil.copy2(file_path, self.path)
        source_file_path = path.join(self.path,source_file_name)
        rename(temp_file_path,source_file_path)
        df = pd.read_csv(source_file_path, encoding="utf-8")
        # Extracting the row count
        row_count    = df.shape[0]
        # Checking whether a data frame has any duplicate column
        resp = dataset_helper.df_column_uniquify(df)
        if resp['status']=='error':
            return resp
        df = resp['data_frame']

        if 'header_col_exists' in source and source['header_col_exists']: # If header column exists
            # Modifying column name from unnamed to column
            un_named_list= [df.columns.get_loc(col) for col in df if col.startswith('Unnamed:')]
            data_frame  = df
            for item in un_named_list:
                data_frame = data_frame.rename(columns={'Unnamed: '+str(item):'Column: '+str(item)})
        else: # If header column does not exists
            column_count = df.shape[1]
            column_names = []
            for item in range(1,(column_count+1)):
                column_names.append('Column: '+str(item))
            data_frame = pd.read_csv(source_file_path, encoding="utf-8",names=column_names)
        table = Table.from_pandas(data_frame)
        target_file_name  = temp_file_name[0] + "-"+ str(timestamp) +".parquet"
        parquet.write_table(table, path.join(self.path, target_file_name))
        config["source"]["filename"] = source_file_name
        config["target"]["filename"] = target_file_name
        config["target"]["to"]       = path.join(self.path, target_file_name)
        # Removing the temp file
        remove(file_path)
        return ({'status':'success', 'config':config,'row_count':row_count}) 
       
