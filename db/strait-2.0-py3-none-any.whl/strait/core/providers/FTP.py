

class FTP:

    def __init__(self):
        print("Initializing FTP Connector")
        raise NotImplementedError