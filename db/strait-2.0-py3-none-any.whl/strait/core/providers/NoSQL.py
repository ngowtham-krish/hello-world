

class NoSQL:

    def __init__(self):
        print("Initializing NoSQL Connector")
        raise NotImplementedError