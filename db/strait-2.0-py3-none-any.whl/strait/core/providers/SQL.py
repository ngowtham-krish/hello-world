import shutil
from strait.environment import load_env
import strait.core.helper.dataset_helper as dataset_helper
from os import path, getcwd, makedirs, environ, rename, remove

# Calling Enviroment Function
load_env()

class SQL:

    def __init__(self,**kwargs):
        print("--- kwargs ----")
        print(kwargs)
        if 'catalog_key' in kwargs and  kwargs['catalog_key'] is not None: 
            self.catalog_key = kwargs['catalog_key']
        else:
            self.catalog_key = environ.get('CATALOG_KEY',None) 
            
        if 'project_key' in kwargs and  kwargs['project_key'] is not None:
            self.project_key = kwargs['project_key']
        else: 
            self.project_key = environ.get('PROJECT_KEY',None)     

        if 'dataset_key' in kwargs and  kwargs['dataset_key'] is not None:
            self.dataset_key = kwargs['dataset_key']
        else:   
            self.dataset_key = environ.get('DATASET_KEY',None) 
        
        self.storage_type = environ.get('STORAGE_TYPE',None)

    def save(self,**kwargs):
        try:
            print("--- Inside save of sql methods ----")
            if 'config' in kwargs and kwargs['config'] is not None:
                config = kwargs['config']
                if self.storage_type in ['docker']:
                    file_path = kwargs['table_details']
                    # Fetching NiFi path for moving source file path
                    path_resp = dataset_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='nifi')
                    if path_resp['status'] in ['error']:
                        return path_resp
                    nifi_dir = path_resp['file_path']
                    file_name = file_path['data']
                    schema_name = file_path['schema']
                    source_file_path = path.join(nifi_dir,file_name)
                    print("---- source_file_path -----")
                    print(source_file_path)
                    source_schema_path = path.join(nifi_dir,schema_name)
                    print("---- source_schema_path -----")
                    print(source_schema_path)
                    
                    # Creating dataset file path
                    path_resp = dataset_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                    if path_resp['status'] in ['error']:
                        return path_resp
                    dataset_dir = path_resp['file_path']
                    target_file_path = path.join(dataset_dir,file_name)
                    print("---- target_file_path -----")
                    print(target_file_path)
                    target_schema_path = path.join(dataset_dir,schema_name)
                    print("---- target_schema_path -----")
                    print(target_schema_path)
                    print("--- Moving source file path to target file path ---")
                    shutil.move(source_file_path, target_file_path)
                    print("--- Moving schema file path to target file path ---")
                    shutil.move(source_schema_path, target_schema_path)

                    config["target"]["filename"]    = file_name
                    config["target"]["to"]          = target_file_path
                    config["target"]["format"]      = kwargs['file_extension']
                    print("---Before return config is ")
                    print(config)
                    return ({'status':'success', 'config':config,'row_count':int(file_path['row_count'])}) 
            else:
                return ({'status':'error','message':'Missing required parameters'})
        except Exception as e:
            return ({'status': 'error', 'message':"Exception: "+ str(e)})    
    