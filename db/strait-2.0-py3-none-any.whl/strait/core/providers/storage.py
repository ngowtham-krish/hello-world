import time, shutil, csv
import pandas as pd
import numpy as np
from strait.environment import load_env
import strait.core.helper.dataset_helper as dataset_helper
import strait.core.helper.catalog_helper as catalog_helper
from os import path, getcwd, makedirs, environ, rename, remove

# Calling Enviroment Function
load_env()

class Storage:

    def __init__(self,catalog_key=None, project_key=None, dataset_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = dataset_key
        
        self.storage_type = environ.get('STORAGE_TYPE',None)
    
    def save(self,**kwargs):
        try:
            if self.storage_type in ['docker']:
                path_resp = dataset_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                if path_resp['status'] in ['error']:
                    return path_resp
                dataset_dir     = path_resp['file_path']
                uploaded_sheet_name = ""

                # When File is passed
                if 'file_type' in kwargs and kwargs['file_type'] is not None:
                    delimiter = ","
                    if kwargs['file_type'] in ['csv','xls','xlsx']:
                        # Storing source file 
                        if 'file' in kwargs and kwargs['file'] is not None:
                            file_obj        = kwargs['file']
                            fileName        = file_obj.filename.split('.')
                            timestamp       = int(round(time.time() * 1000))
                            source_file_type= fileName[1]
                            file_name       = fileName[0]
                            source_file_name= fileName[0] + "-"+ str(timestamp) + "." + fileName[1]
                            source_file_path= path.join(dataset_dir, source_file_name)
                            source_file_path_for_xlsx = source_file_path
                            file_obj.save(source_file_path)
                        
                        if 'delimiter' in kwargs and kwargs['delimiter'] is not None:
                            delimiter = kwargs['delimiter']
                    
                    if kwargs['file_type'] in ['xls','xlsx']: 
                        sheet           = kwargs['sheet']
                        resp            = catalog_helper.generate_key(sheet.name)
                        if resp['status'] in ['error']:
                            return resp 
                        sheet_name      = resp['key']
                        file_name       = sheet.name
                        timestamp       = int(round(time.time() * 1000))
                        source_file_type= "csv"
                        source_file_name= sheet_name + "-" + str(timestamp) + "." + source_file_type
                        source_file_path= path.join(dataset_dir, source_file_name)
                        with open(source_file_path, "w",newline='') as file:
                            writer = csv.writer(file, delimiter = ",")
                            if 'given_sheet_name' in kwargs and kwargs['given_sheet_name'] is not None:
                                # Adding the name of uploaded sheet name
                                if len(kwargs['given_sheet_name'])>0:
                                    given_sheet_name = kwargs['given_sheet_name']
                                    index = given_sheet_name.index(file_name)
                                    for i in range(0,index):
                                        uploaded_sheet_name = uploaded_sheet_name + str(given_sheet_name[i])
                                        if i != index-1:
                                            uploaded_sheet_name = uploaded_sheet_name + ", "
                            #csv_out = unicodecsv.writer(fh, encoding='utf-8')
                            if sheet.ncols == 0 and sheet.nrows == 0:
                                remove(source_file_path)
                                remove(source_file_path_for_xlsx)
                                if uploaded_sheet_name != "":
                                    return ({'status': 'error', 'message':"Sheet "+uploaded_sheet_name+" uploaded successfully but cannot upload empty "+str(file_name)+" sheet"})
                                else:
                                    return ({'status': 'error', 'message':"cannot upload empty "+str(file_name)+" sheet"})
                            else:
                                header = [cell.value for cell in sheet.row(0)]
                                writer.writerow(header)
                                for row_idx in range(1, sheet.nrows):
                                    #row = [int(cell.value) if isinstance(cell.value, float) else cell.value for cell in sheet.row(row_idx)]
                                    row = [cell.value for cell in sheet.row(row_idx)]
                                    writer.writerow(row)
                    
                    if kwargs['file_type'] in ['custom']:
                        if 'data_frame' in kwargs and kwargs['data_frame'] is not None:
                            df              = kwargs['data_frame']
                            csv_data        = df.to_csv(index=False)
                            timestamp       = int(round(time.time() * 1000))
                            source_file_type= "csv"
                            file_name       = self.dataset_key
                            source_file_name= self.dataset_key + "-"+ str(timestamp) + ".csv"
                            source_file_path= path.join(dataset_dir, source_file_name)
                            source_file     = open(source_file_path, "w")
                            source_file.write(csv_data)
                            source_file.close()

                    # If file type is CSV then fetching the data as data frame
                    df = pd.read_csv(source_file_path, encoding="utf-8",sep=delimiter)
                
                # Skip Line Logic
                if 'skip_lines' in kwargs and kwargs['skip_lines'] is not None:
                    df = df[kwargs['skip_lines']:]
                
                if df.empty:
                    # Removing the source file
                    remove(source_file_path)
                    if kwargs['file_type'] in ['xls','xlsx']:
                        remove(source_file_path_for_xlsx)
                        if uploaded_sheet_name != "":
                            return ({'status': 'error', 'message':"Sheet "+uploaded_sheet_name+" uploaded successfully but cannot upload empty "+str(file_name)+" sheet"})
                        else:
                            return ({'status': 'error', 'message':"cannot upload empty "+str(file_name)+" sheet"})
                    elif kwargs['file_type'] in ['csv']:
                        return ({'status': 'error', 'message':"cannot upload empty "+str(file_name)+" file"})
                    elif kwargs['file_type'] in ['custom']:
                        return ({'status': 'error', 'message':"data frame is empty"})
                
                # Extracting the row count
                row_count = df.shape[0]

                # Checking whether a data frame has any duplicate column
                resp = dataset_helper.df_column_uniquify(df)
                if resp['status']=='error':
                    return resp
                df = resp['data_frame']

                if 'header_column_exists' in kwargs and kwargs['header_column_exists'] in [True]: # If header column exists
                    # Modifying column name from unnamed to column
                    un_named_list= [df.columns.get_loc(col) for col in df if col.startswith('Unnamed:')]
                    data_frame  = df
                    for item in un_named_list:
                        data_frame = data_frame.rename(columns={'Unnamed: '+str(item):'Column: '+str(item)})
                else: # If header column does not exists
                    column_count = df.shape[1]
                    column_names = []
                    for item in range(1,(column_count+1)):
                        column_names.append('Column: '+str(item))
                    data_frame = pd.read_csv(source_file_path, encoding="utf-8",names=column_names)

                # Replacing any NaN/None Value to Empty String
                data_frame.replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN'], value=np.nan, inplace=True)
                data_frame.fillna("", inplace = True)

                data_frame_to_csv   = data_frame.to_csv(index=False)
                target_file_type    = "csv"
                timestamp           = int(round(time.time() * 1000))
                target_file_name    = file_name + "-"+ str(timestamp) +"."+target_file_type
                target_file_path    = path.join(dataset_dir,target_file_name)
                
                fh = open(target_file_path, "w")
                fh.write(data_frame_to_csv)
                fh.close()
                return ({"status":'success',
                        'source_file_name':source_file_name,
                        'source_file_path':source_file_path,
                        'source_file_type':source_file_type,
                        'target_file_name':target_file_name,
                        'target_file_path':target_file_path,
                        'target_file_type':target_file_type,
                        'row_count':row_count
                })
            elif self.storage_type in ['hdfs']:
                pass
        except pd.io.common.EmptyDataError as e:
            remove(source_file_path)
            return ({'status': 'error', 'message':"Exception: cannot upload empty data file"})
        except Exception as e:
            return ({'status': 'error', 'message':"Exception: "+ str(e)})
        