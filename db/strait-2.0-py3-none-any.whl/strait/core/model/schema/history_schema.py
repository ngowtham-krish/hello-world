from mongoengine import *
from datetime import datetime

class HistorySchema(Document):
    recipe_key  = StringField(required = True)
    catalog_key = StringField()
    project_key = StringField()
    source_key  = ListField()
    target_name = StringField()
    deleted     = BooleanField(default=False)
    operation   = DictField()
    active      = BooleanField(default=False)
    sampling    = DictField()
    #order      = IntField()
    created_at  = DateTimeField(default=datetime.now())
    updated_at  = DateTimeField(default=datetime.now())
    owners      = ListField()
    meta = {'collection': 'recipe_history'}