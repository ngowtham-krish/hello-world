from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class ColumnMenuSchema(Document):
    # catalog_key       = StringField()
    schema              = DictField()
    created_at          = DateTimeField(default=datetime.now())
    updated_at          = DateTimeField(default=datetime.now())
    created_by          = StringField()
    updated_by          = StringField()
    owners              = ListField()
    column_menu_type    = StringField(default="custom")
    visible             = StringField(default="user")
    deleted             = BooleanField(default= False)
    meta                = {'collection': 'column_menu'}

 