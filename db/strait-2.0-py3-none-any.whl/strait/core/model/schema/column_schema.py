from mongoengine import *
from mongoengine import signals
from datetime import datetime
from strait.core.model.schema import CatalogSchema
from json import loads, dumps

class ColumnInfoSchema(Document):
    column_name  = StringField(max_length=200, required=True)
    project_key  = StringField()
    catalog_key  = StringField()
    dataset_key  = StringField()
    recipe_key   = StringField(default=None)
    metadata     = DictField()
    is_recipe    = BooleanField(default = False)
    created_at   = DateTimeField(default=datetime.now())
    updated_at   = DateTimeField(default=datetime.now())
    oknotok      = StringField()
    created_by   = StringField()
    updated_by   = StringField()
    owners       = ListField()
    deleted      = BooleanField(default= False)
    meta         = {'collection': 'columninfo'}




