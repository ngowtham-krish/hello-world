from mongoengine import *
from mongoengine import signals
from datetime import datetime

class CatalogSchema(DynamicDocument):
    name      = StringField(max_length=200, required=True)
    key       = StringField()
    deleted   = BooleanField(default= False)
    projects   = ListField()
    created_by = StringField()
    created_at = DateTimeField(default=datetime.now())
    updated_at = DateTimeField(default=datetime.now())
    meta = {'collection': 'catalogs'}

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        # Checking whether dataset key already exists or not
        if 'key' in document:
            response = sender.objects(key=document.key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Catalog name already exists")
        
        '''
        # Catalog name can be duplicate key should be unique
        # Checking whether dataset name already exists or not
        if 'name' in document:
            response = sender.objects(name=document.name,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Catalog name already exists")
        '''
# Checking whether Dataset name already exists before saving data into project 
signals.pre_save.connect(CatalogSchema.pre_save, sender = CatalogSchema)




