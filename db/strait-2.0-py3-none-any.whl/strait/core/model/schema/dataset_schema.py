from mongoengine import *
from mongoengine import signals
from datetime import datetime
from strait.core.model.schema import CatalogSchema
from json import loads, dumps

class DatasetSchema(Document):
    name         = StringField(max_length=200, required=True)
    key          = StringField()
    description  = StringField()
    tags         = ListField()
    project_key  = StringField()
    catalog_key  = StringField()
    datasource   = DictField()
    path         = StringField()
    is_build     = BooleanField(default= True)
    created_at   = DateTimeField(default=datetime.now())
    updated_at   = DateTimeField(default=datetime.now())
    created_by   = StringField()
    updated_by   = StringField()
    owners       = ListField()
    deleted      = BooleanField(default= False)
    meta = {'collection': 'strait-datasets'}

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        # Checking catalogId and projectId association exists or not 
        #response = CatalogSchema.objects.filter(id=document.catalog_id,deleted=False).fields(projects={'$elemMatch': {'id': document.project_id,'deleted':False}})
        
        # Checking whether dataset key already exists or not
        if 'key' in document:
            response = sender.objects(key=document.key,catalog_key=document.catalog_key,project_key=document.project_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Dataset name already exists")
        
        # Checking whether dataset name already exists or not
        if 'name' in document:
            response = sender.objects(name=document.name,catalog_key=document.catalog_key,project_key=document.project_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Dataset name already exists")
            
    @classmethod
    def post_save(cls, sender, document, **kwargs):
        requestFor = dict(**kwargs)
        if 'created' in requestFor: # Creating the dataset inside data catalog
           # Preparing data to pass to data catalog to create dataset
           data = {
               'id' : str(document.id),
               'name' : document.name,
               'key':document.key,
               'deleted': False,
               'metadata' : {
                   'source_name' : "",
                   'source_format': "",
                   'target_name' : "",
                   'columns'    : [],
                   'data_types'  : [],
                   'path': document['path'] if 'path' in document else ""
                }
           }
           catalogDetails = CatalogSchema.objects.filter(key=document.catalog_key,deleted=False).fields(projects={'$elemMatch': {'key': document.project_key,'deleted':False}})
           datasets = list(catalogDetails[0]['projects'][0]['datasets'])
           datasets.append(data)
           updatedResponse = CatalogSchema.objects(key=document.catalog_key,deleted=False,projects={'$elemMatch': {'key': document.project_key,'deleted':False}}).update_one(set__projects__S__datasets=datasets)
           return updatedResponse 
           
# Checking whether Dataset name already exists before saving data into dataset 
signals.pre_save.connect(DatasetSchema.pre_save, sender = DatasetSchema)

# Storing data into data catalog        
signals.post_save.connect(DatasetSchema.post_save, sender = DatasetSchema)



