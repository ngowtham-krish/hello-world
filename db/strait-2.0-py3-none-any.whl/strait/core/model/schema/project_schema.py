from mongoengine import *
from mongoengine import signals
from datetime import datetime
from strait.core.model.schema import CatalogSchema
from json import loads, dumps

class ProjectSchema(Document):
    name = StringField(max_length=200, required=True)
    key = StringField()
    deleted = BooleanField(default= False)
    catalog_key = StringField()
    description = StringField()
    tags = ListField()
    created_at = DateTimeField(default=datetime.now())
    updated_at = DateTimeField(default=datetime.now())
    meta = {'collection': 'projects'}

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        # Checking whether dataset key already exists or not
        if 'key' in document:
            response = sender.objects(key=document.key,catalog_key=document.catalog_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Project name already exists")
        
        # Checking whether dataset name already exists or not
        if 'name' in document:
            response = sender.objects(name=document.name,catalog_key=document.catalog_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Project name already exists")
            
    @classmethod
    def post_save(cls, sender, document, **kwargs):
        requestFor = dict(**kwargs)
        if 'created' in requestFor: # Creating the dataset inside data catalog
           # Preparing data to pass to data catalog to create dataset
           data = {
               'id' : str(document.id),
               'name' : document.name,
               'key':document.key,
               'deleted': False,
               "datasets":[],
               "experiments":[]
           }
           catalogDetails = CatalogSchema.objects(key=document.catalog_key,deleted=False)
           project_lists = list(catalogDetails[0]['projects'])
           project_lists.append(data)
           updatedResponse = CatalogSchema.objects(key=document.catalog_key,deleted=False).update_one(set__projects=project_lists)
           return updatedResponse 
           
# Checking whether Project name already exists before saving data into project 
signals.pre_save.connect(ProjectSchema.pre_save, sender = ProjectSchema)

# Storing data into data catalog        
signals.post_save.connect(ProjectSchema.post_save, sender = ProjectSchema)

