from mongoengine import *
from mongoengine import signals
from datetime import datetime
from strait.core.model.schema.catalog_schema import CatalogSchema
from json import loads, dumps

class FileSchema(DynamicDocument):
    catalog_key     = StringField()
    project_key     = StringField()
    dataset_key     = StringField()
    metadata        = DictField()
    created_at      = DateTimeField(default=datetime.now())
    updated_at      = DateTimeField(default=datetime.now())
    deleted         = BooleanField(default= False)
    meta_data       = FileField()
    operation       = DictField()
    #freeze_col_index = ListField(default=[])
    #filters  = ListField(default=[])
    #sorting  = ListField(default=[])
    #sampling = DictField()
    #col_index = ListField(default=[])
    #hide_column = ListField(default=[])
    meta = {'collection': 'strait-files'}

    @classmethod
    def post_save(cls, sender, document, **kwargs):
        requestFor = dict(**kwargs)
        
        if 'created' in requestFor: # update the dataset inside data catalog
            # Preparing data to pass to data catalog to create dataset
            catalogDetails  = CatalogSchema.objects.filter(key=document['catalog_key'],deleted=False).fields(projects={'$elemMatch': {'key': document['project_key'],'deleted':False}})
            datasetsDetails = list(loads(dumps(catalogDetails[0]['projects'][0]['datasets'])))
            
            counter = 0
            for item in datasetsDetails:
                if item['key'] == document.dataset_key:
                    # doc = loads(document.meta_data.read())
                    doc = document.metadata
                    # print("Doc in File Schema",doc)
                    datasetsDetails[counter]['metadata']['source_name']     =   doc['source_name']
                    datasetsDetails[counter]['metadata']['source_format']   =   doc['source_format']
                    datasetsDetails[counter]['metadata']['target_name']     =   doc['target_name']
                    datasetsDetails[counter]['metadata']['columns']         =   doc['columns'] if "columns" in doc else None
                    datasetsDetails[counter]['metadata']['data_types']      =   doc['data_types'] if "data_types" in doc else None 
                    datasetsDetails[counter]['metadata']['path']            =   doc['path']
                counter = counter + 1
            
            updatedResponse = CatalogSchema.objects(key=document['catalog_key'],deleted=False,projects={'$elemMatch': {'key': document['project_key'],'deleted':False}}).update(set__projects__S__datasets=datasetsDetails)
            return updatedResponse 
           
signals.post_save.connect(FileSchema.post_save, sender = FileSchema)
