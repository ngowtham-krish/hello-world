from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class TransformationSchema(Document):
    name         = StringField(max_length=200, required=True)
    key          = StringField()
    description  = StringField(default="")
    tags         = ListField(default=[])
    # catalog_key  = StringField()
    # project_key  = StringField()
    engine       = StringField(default="python")
    path         = StringField()
    schema       = ListField()
    function_name = StringField()
    transformation_level= StringField(default="column")
    transformation_type= StringField(default="custom")
    preview_column = BooleanField(default= False)
    #new_column_name = StringField() # Replace column name 
    created_at   = DateTimeField(default=datetime.now())
    updated_at   = DateTimeField(default=datetime.now())
    created_by   = StringField()
    updated_by   = StringField()
    owners       = ListField()
    visible      = StringField(default="user")
    deleted      = BooleanField(default= False)
    meta         = {'collection': 'strait-transformation'}

 