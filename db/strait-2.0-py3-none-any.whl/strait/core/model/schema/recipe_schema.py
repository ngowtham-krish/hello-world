from mongoengine import *
from mongoengine import signals
from datetime import datetime
from json import loads, dumps

class RecipeSchema(Document):
    name        = StringField(max_length=200, required=True)
    key         = StringField()
    catalog_key = StringField()
    project_key = StringField()
    source_key  = ListField()
    target_key  = StringField()
    recipe_type = StringField()
    deleted     = BooleanField(default=False)
    is_build    = BooleanField(default=False)
    owners      = ListField()
    #sampling   = DictField()
    operation   = DictField()
    created_at  = DateTimeField(default=datetime.now())
    updated_at  = DateTimeField(default=datetime.now())
    meta = {'collection': 'recipes'}

    @classmethod
    def pre_save(cls, sender, document, **kwargs):
        # Checking whether recipe key already exists or not
        if 'key' in document:
            response = sender.objects(key=document.key,catalog_key=document.catalog_key,project_key=document.project_key,source_key=document.source_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Recipe name already exists")
        
        # Checking whether recipe name already exists or not
        if 'name' in document:
            response = sender.objects(name=document.name,catalog_key=document.catalog_key,project_key=document.project_key,source_key=document.source_key,deleted=False)
            if len(response) > 0 :
                raise ValidationError("Recipe name already exists")
    
# Checking whether Recipe name already exists before saving data into recipe schema 
signals.pre_save.connect(RecipeSchema.pre_save, sender = RecipeSchema)
