import pandas as pd
from json import loads
import strait.core.helper.metadata as meta_data

class Analysis:
    def __init__(self, *args):
        obj = dict(*args)
        self.data_frame = obj['data_frame']
    
    def analyze(self,column_name):
        try:
            metadata = meta_data.predict_types(self.data_frame[[column_name]],20,True)
            metadata = loads(metadata)
            if 'columns' not in metadata or 'data_types' not in metadata or 'histogram' not in metadata:
                return ({'status':"error",'message':"Some error while building metadata"})    
            
            column_data = metadata['histogram'][column_name]
            not_ok_lists= metadata['ok_not_ok'][column_name]['not_ok']
            data = {}
            not_ok_data = []
            unquie_data = []
            unquie_count = 0
            row_count = self.data_frame.shape[0]
            not_ok_count = len(metadata['ok_not_ok'][column_name]['not_ok'])
            empty_count = len(metadata['ok_not_ok'][column_name]['empty'])
            ok_count = row_count - (not_ok_count+empty_count)
            i = 0
            for item in column_data['label']:
                data[item] = column_data['value'][i]
                # Unquie data
                if column_data['value'][i] == 1:
                    unquie_data.append(item)
                    unquie_count += 1
                i += 1
            # Not ok data
            for item in not_ok_lists:
                not_ok_data.append(self.data_frame[column_name][item])
            not_ok_data = list(dict.fromkeys(not_ok_data))
            summary = {
                'valid': {'count':ok_count,'percentage':metadata['data_types'][0]['ok']},
                'unquie': {'count':unquie_count},
                'invalid': {'count':not_ok_count,'percentage':metadata['data_types'][0]['not_ok']},
                'empty': {'count':empty_count,'percentage':metadata['data_types'][0]['empty']}
            }
            
            response = {
                'data' : data,
                'summary': summary,
                'invalid_lists': not_ok_data,
                'unquie_data': unquie_data
            }
            return ({'status':'success','categorical':response})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
