import copy
import pandas as pd
import numpy as np
from sys import exc_info
from datetime import datetime
from json import loads, dumps, dump
from os import path, getcwd,environ
from strait.environment import load_env
import strait.core.sampling as sampling
import strait.core.recipe as recipe
import strait.core.dataframe as dataFrame
import strait.core.datasource as dataSource
import strait.pipeline.dataset as pipelineDataset
import strait.pipeline.recipe as pipelineRecipe
import strait.core.helper.catalog_helper as catalog_helper
import strait.core.helper.dataset_helper as dataset_helper
import strait.core.helper.wrangling_helper as wrangling_helper
from strait.core.model.schema import DatasetSchema, FileSchema, CatalogSchema, HistorySchema, RecipeSchema, ColumnInfoSchema

# Calling Enviroment Function
load_env()

class Dataset:

    def __init__(self, catalog_key=None, project_key=None, dataset_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = dataset_key 
        
        self.catalog_schema     = CatalogSchema
        self.dataset_schema     = DatasetSchema
        self.file_schema        = FileSchema
        self.recipe_schema      = RecipeSchema
        self.history_schema     = HistorySchema
        self.columninfo         = ColumnInfoSchema
        self.datasource = dataSource.DataSource()
        self.dataFrame  = dataFrame.DataFrame()
        self.sampling   = sampling.Sampling()

    # Dataset Delete
    def delete(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key!=None:
                target_keys = []
                recipe_lists = self.recipe_schema.objects(source_key=self.dataset_key, catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json()
                recipe_lists = list(loads(recipe_lists))
                # Checking whether recipe exists or not
                if len(recipe_lists)>0:
                    # Taking all recipe key associated with passed dataset keys
                    for i in recipe_lists:
                        recipe_obj = recipe.Recipe(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, recipe_key=i['key'])
                        if 'call_from' in kwargs and kwargs['call_from'] is not None:
                            recipe_del_resp = recipe_obj.delete(request_from='api',call_from=kwargs['call_from'])
                            target_keys = recipe_del_resp['dataset_key']
                        else:
                            recipe_del_resp = recipe_obj.delete(request_from='api')
                        if recipe_del_resp['status'] in ['error']:
                            return recipe_del_resp
                
                # Pipeline Dataset Update
                pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,self.dataset_key)
                pipeline_resp = pipelineObj.update(delete=True)
                # Updating data into dataset
                datasetObj  = self.dataset_schema.objects(key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                    new=True,
                    set__deleted = True,
                    set__updated_at = datetime.now()
                )
                # Checking file data exists or not by dataset key
                file_lists = self.file_schema.objects(dataset_key=self.dataset_key, catalog_key=self.catalog_key, project_key=self.project_key, deleted=False).to_json()
                file_lists = list(loads(file_lists))
                fileObj = None
                if len(file_lists)>0:
                    # Updating File schema
                    fileObj  = self.file_schema.objects(dataset_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                        new=True,
                        set__deleted = True,
                        set__updated_at = datetime.now()
                    )
                
                # Updating data into data catalog
                catalog_lists = CatalogSchema.objects.filter(key=self.catalog_key,deleted=False).fields(key=1, name=1, deleted=1, projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).to_json()
                catalog_lists = list(loads(catalog_lists))
                dataset_lists = catalog_lists[0]['projects'][0]['datasets']
                dataset_counter = 0
                for dataset_details in dataset_lists:
                    if dataset_details['key'] == self.dataset_key:
                        dataset_lists[dataset_counter]['deleted'] = True
                    dataset_counter = dataset_counter + 1
                updatedResponse = CatalogSchema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update_one(set__projects__S__datasets=dataset_lists)
                if 'call_from' in kwargs and kwargs['call_from'] in ['delete_project']:
                    resp = dataset_helper.dataset_response(dataset=datasetObj,file=fileObj)
                    if resp['status'] in ['error']:
                        return resp
                    return ({'status':'success','dataset_key':target_keys,'data':resp['data']})
                else:
                    return dataset_helper.dataset_response(dataset=datasetObj,file=fileObj)
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'message':"dataset key is required"})
                else:  # For Notebook
                    return "dataset key is required"
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))

    # Dataset Lists
    def lists(self, **kwargs):
        try:
            #data = dict(*args)
            if self.catalog_key!=None and self.project_key!=None:
                dataset_lists = self.dataset_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key,deleted=False).to_json()
                dataset_lists = loads(dataset_lists)
                dataset_details = []
                if len(dataset_lists)>0:
                    if 'request_from' in kwargs and kwargs['request_from'] is not None:
                        if kwargs['request_from']=='api': # For API response will have name and datasetId
                            for item in dataset_lists:
                                temp = {
                                    'key': item['key'],
                                    'name': item['name'].strip(),
                                    'tags': item['tags'] if len(item['tags']) > 0 else [],
                                    'updatedAt': datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S')
                                }
                                dataset_details.append(temp)
                            return ({'status':'success','data':dataset_details})
                        else: # For Notebook the response will have only dataset key
                            for item in dataset_lists:
                                dataset_details.append(item['key'])
                            return dataset_details 
                    else: # For Notebook the response will have only dataset key
                        for item in dataset_lists:
                            dataset_details.append(item['key'])
                        return dataset_details
                else:
                    return ({"status":"success","data":[]})    
            else:
                if 'request_from' in kwargs:
                    if kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':"Missing required parameters"})   
                    else: # For Notebook
                        return ("Missing required parameters")   
                else: # For Notebook
                    return ("Missing required parameters")   
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))        
            
    # For getting the data frame
    def get_dataframe(self,**kwargs):
        try:
            if self.catalog_key is None and self.project_key is None and self.dataset_key is None: 
                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                    return ({'status':"error",'message':'Missing required parameters'})
                else: # For Notebook 
                    return ("Missing required parameters")
            dataset = None
            if self.dataset_key is not None:
                dataset_resp = dataset_helper.get_dataset(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key)

                if dataset_resp['status'] == 'error':
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return dataset_resp
                    else: # For Notebook 
                        return dataset_resp['message']
                dataset = dataset_resp['dataset']
                
            if dataset!=None:
                target_file_name = None
                if len(dataset['datasource'])>0:
                    target_file_name = dataset['datasource']["target"]['filename']
                else:
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'file does not exists'})
                    else: # For Notebook 
                        return ("File does not exists")
                base_path = environ.get('STORAGE',None)
                path_dir = path.join(base_path,self.catalog_key,self.project_key,'datasets',self.dataset_key, target_file_name)
                if not path.exists(path_dir):
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'file path is invalid or does not exists'})
                    else: # For Notebook  
                        return ('file path is invalid or does not exists')

                # Reading file from CSV
                data_frame = pd.read_csv(path_dir,encoding = "ISO-8859-1")
                # Checking Sampling
                if 'sampling_name' in kwargs and kwargs['sampling_name'] is not None:
                    sampling = kwargs['sampling_name']
                else: # Default
                    sampling = "all"

                # Checking Sampling Data
                if 'sampling' in kwargs and kwargs['sampling'] is not None:
                    sampling_data = kwargs['sampling']
                else: # Default
                    sampling_data = {}
                
                if sampling=='all':
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({"status":"success","dataFrame":data_frame})        
                    else: # For Notebook  
                        return data_frame
                else:
                    # Checking whether column name exists or not
                    if len(sampling_data)>0:
                        if sampling_data['name'] in ['stratified_records','stratified_ratio','rebalance_records','rebalance_ratio','column_value_subset']:
                            if sampling_data['column_name'] not in list(data_frame.columns):
                                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                    return ({"status":"error","message":"column name is invalid"})
                                else: # For Notebook   
                                    return ("column name is invalid")    
                    
                    file_data = self.file_schema.objects(dataset_key=self.dataset_key,project_key=self.project_key,catalog_key=self.catalog_key, deleted=False).to_json()
                    file_data = loads(file_data)
                    row_count = file_data[0]['metadata']['row_count']
                    if 'name' in sampling_data:
                        # Checking sampling records count
                        if sampling_data['name'] in ['first','last','random_records','stratified_records','rebalance_records','column_value_subset']:
                            if 'records' in sampling_data and sampling_data['records']!='':
                                if sampling_data['records'] > int(row_count):
                                    sampling_data['records'] = int(row_count)
                        
                        # Checking sampling ratio 
                        if sampling_data['name'] in ['random_ratio','stratified_ratio','rebalance_ratio']:
                            if 'ratio' in sampling_data and sampling_data['ratio']!='':
                                if sampling_data['ratio'] > 100:
                                    sampling_data['ratio'] = 100
                    
                    data_frame    = self.sampling.get_sample_data(data_frame,sampling_data)    
                    
                    # Checking whether data frame is empty or not
                    if data_frame.empty:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status':'error','message':'No record to render'})
                        else: # For Notebook  
                            return ('data frame is empty')    
                            
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For 
                        return ({"status":"success","dataFrame":data_frame})
                    else: # For Notebook   
                        return data_frame    
            else:
                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                    return ({'status':'error','message':'datasetid is invalid'})
                else: # For Notebook  
                    return ('datasetid is invalid')
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))
        
    # Previewing Dataset
    def preview(self,**kwargs):
        try:
            if self.dataset_key is not None and self.catalog_key is not None and self.project_key is not None:
                supported_format = ['csv', 'json']
                if 'recipe_key' in kwargs.keys() and kwargs['recipe_key'] is not None:
                    # Fetching Operation Details from Recipe Schema
                    recipe_data = self.recipe_schema.objects(catalog_key=self.catalog_key,project_key=self.project_key, source_key=self.dataset_key, key=kwargs['recipe_key'], deleted=False).to_json()
                    recipe_data = loads(recipe_data)
                    sampling    = recipe_data[0]['operation']['sampling'] 
                    filters     = recipe_data[0]['operation']['filters']
                    sorting     = recipe_data[0]['operation']['sorting']
                    hide_column = recipe_data[0]['operation']['hide_column']
                    freeze_column_index  = recipe_data[0]['operation']['freeze_column_index']
                else:
                    # Fetching Operation Details from File Schema
                    file_data   = self.file_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, deleted=False).to_json()
                    file_data   = loads(file_data)
                    sampling    = file_data[0]['operation']['sampling'] 
                    filters     = file_data[0]['operation']['filters']
                    sorting     = file_data[0]['operation']['sorting']
                    hide_column = file_data[0]['operation']['hide_column']
                    freeze_column_index  = file_data[0]['operation']['freeze_column_index']
                
                # If recipeKey is passed then passing updated dataFrame
                if 'recipe_key' in kwargs.keys() and kwargs['recipe_key'] is not None:
                    # Checking whether any transformation already exists or not
                    history_details = self.history_schema.objects(recipe_key=kwargs['recipe_key'], source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted= False).to_json()
                    history_details = list(loads(history_details)) 
                    if len(history_details)>0: # If history has the records taking the data frame from the latest active steps
                        resp = wrangling_helper.checking_sampling(self.catalog_key,self.project_key,self.dataset_key,kwargs['recipe_key'],sampling,history_details)
                        if resp['status']=='error':
                            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                return resp
                            else: # For Notebook
                                return resp['message']
                        data_frame = resp['data_frame']
                    else:
                        # Passing source dataFrame
                        if len(sampling)==0:
                            data_frame = self.get_dataframe(sampling_name='first', request_from='api')
                        else:
                            if sampling['name'] == '':
                                data_frame = self.get_dataframe(sampling_name='first', request_from='api')
                            else:       
                                data_frame = self.get_dataframe(sampling_name=sampling['name'], request_from='api', sampling=sampling)
                        if data_frame['status']=='error':
                            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                return data_frame
                            else: # For Notebook
                                return data_frame['message']
                        data_frame = data_frame['dataFrame']
                else:
                    # Passing source dataFrame
                    if len(sampling)==0:
                        data_frame = self.get_dataframe(sampling_name='first', request_from='api')
                    else:
                        if sampling['name'] == '':
                            data_frame = self.get_dataframe(sampling_name='first', request_from='api')
                        else:       
                            data_frame = self.get_dataframe(sampling_name=sampling['name'], request_from='api', sampling=sampling)
                    if data_frame['status']=='error':
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return data_frame
                        else: # For Notebook
                            return data_frame['message']
                    data_frame = data_frame['dataFrame']

                row_count = data_frame.shape[0]
                columns   = data_frame.columns.tolist()
                data_frame_new = data_frame
                # Applying Filter Logic if exists (Have to think how to implement filters)
                if len(filters)>0:
                    response = dataset_helper.apply_filters(data_frame=data_frame, filters=filters, request_from=kwargs['request_from'])
                    if response['status'] == 'error': # For API
                        if 'request_from' in kwargs and kwargs['request_from']=='api':
                            return response
                        else: # For NoteBook
                            return response['message']
                    data_frame = response['data_frame']
                    row_count = data_frame.shape[0]
                    
                # Applying Sorting Logic if exists
                if len(sorting)>0:
                    column_names = []
                    order_by = []
                    for item in sorting:
                        if item['column_name'] not in list(data_frame.columns):
                            return ({'status':'error','message':'column name is invalid'})
                        else:
                            column_names.append(item['column_name'])
                            if item['order_by'].lower() == 'desc': # In Descending Order
                                order_by.append(False)
                            else: # In Ascending Order
                                order_by.append(True)
                    
                    if len(column_names) == len(order_by): # Both should be equal
                        data_frame = copy.deepcopy(data_frame)
                        data_frame.sort_values(by=column_names, ascending=order_by, inplace=True)

                # Applying Freeze column Logic if exists
                if len(freeze_column_index)>0:
                    freeze_col_name = data_frame.columns[freeze_column_index]
                    i = 0
                    for col_name in freeze_col_name:
                        df_col_data = data_frame_new[col_name]
                        if col_name not in data_frame.columns: # If column does not exists in current data frame
                            data_frame.insert(i, col_name,  df_col_data)
                        else: # If column exists in current data frame
                            df_col_data = data_frame[col_name]
                            data_frame.drop([col_name], axis = 1, inplace = True)
                            data_frame.insert(i, col_name,  df_col_data)
                        i += 1

                # Applying Hide column logic if exists
                if len(hide_column)>0:
                    column_names = data_frame.columns.values[hide_column]
                    data_frame.drop(column_names, axis = 1, inplace = True)

                # Checking whether row index is passed or not (To fetch ok and not ok value by index)
                try:
                    if 'row_index' in kwargs and kwargs['row_index'] is not None:
                        data_frame = data_frame.iloc[kwargs['row_index']] 
                except Exception as e:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({'status':"error",'message':"row index range is invalid"})
                    else: # For Notebook
                        return "row index range is invalid"
                
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    # Pagination
                    if 'page_no' in kwargs.keys() and kwargs['page_no'] is not None: # With pagination
                        page_no = kwargs['page_no']
                    else:
                        page_no = 0

                    resp = dataset_helper.pagination(data_frame,page_no,sampling,self.dataset_key,self.project_key,self.catalog_key)
                    if resp['status'] == 'error':
                        return resp 
                    data_frame = resp['data_frame']
                    
                    # Replacing any NaN/None Value to Empty String (otherwise in UI JSON Parse is not happening because of NaN presence)
                    data_frame.replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN',""], value=np.nan, inplace=True)
                    data_frame.fillna("", inplace = True)

                    # Checking whether data frame is empty or not
                    is_data_frame_empty = "no"
                    if data_frame.empty:
                        is_data_frame_empty = "yes"
                    
                    if 'format' in kwargs.keys():
                        if kwargs['format'] != None and kwargs['format'].lower() in supported_format:
                            if kwargs['format'] == 'json':  # JSON
                                data = data_frame.to_json(orient='records')
                            elif kwargs['format'] == 'csv':  # CSV
                                if kwargs['index']:
                                    data = data_frame.to_csv(index_label="index")
                                else:
                                    data = data_frame.to_csv(index=False)
                        else: # Default Format JSON
                            data = data_frame.to_json(orient='records')
                    else:  # Default Format JSON
                        data = data_frame.to_json(orient='records')
                    if 'call_from' in kwargs and kwargs['call_from'] in ['set_filters']:
                        return ({'status': "success", 'data': data,'columns':columns,'row_count':row_count,"is_data_frame_empty":is_data_frame_empty})
                    else:
                        return ({'status': "success", 'data': data,'columns':columns,'row_count':row_count})
                else: # For Notebook
                    return data_frame
            else:
                if 'request_from' in kwargs and kwargs['request_from'] is not None:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({'status': "error", 'message': "dataset key is required"})
                    else: # For Notebook
                        return "dataset key is required"
                else: # For Notebook
                    return "dataset key is required"
        except Exception as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)+ " at line "+str(exc_tb.tb_lineno)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e)+ " at line "+str(exc_tb.tb_lineno))
            else: # Fot Notebook
                return ("Exception: "+ str(e)+ " at line "+str(exc_tb.tb_lineno))

    # Metadata
    def metadata(self, **kwargs):
        try:
            if self.dataset_key is not None and self.project_key is not None and self.catalog_key is not None:
                recipe_key = kwargs["recipe_key"] if "recipe_key" in kwargs else None
                columnInfo = self.columninfo.objects(dataset_key=self.dataset_key, catalog_key=self.catalog_key ,project_key=self.project_key, deleted=False).to_json()
                column_json = loads(columnInfo)
                datatypes = []
                for x in column_json:
                    is_data_exists = 0
                    if recipe_key is not None and 'recipe_key' in x and x["recipe_key"] == recipe_key:
                        i = 0
                        for item in datatypes:
                            if x["metadata"]["datatypes"]['field'] == item['field']:
                                datatypes[i] = x["metadata"]["datatypes"]
                                is_data_exists = 1
                            i+=1
                    # Case where user want source dataset
                    if recipe_key is None and 'recipe_key' in x and x['recipe_key'] is not None:
                        pass
                    elif is_data_exists!=1:
                        # Skipping other recipe key which is not related to this dataset
                        if recipe_key is not None and 'recipe_key' in x and x['recipe_key'] is not None and recipe_key!=x['recipe_key']:
                            pass
                        else:
                            datatypes.append(x["metadata"]["datatypes"])
                #datatypes = [ x["metadata"]["datatypes"] for x in column_json if 'recipe_key' in x and x["recipe_key"] == recipe_key]
                datasetInfo = self.dataset_schema.objects(key=self.dataset_key, catalog_key=self.catalog_key ,project_key=self.project_key, deleted=False).to_json()
                datasetInfo = loads(datasetInfo)
                file_data = self.file_schema.objects(dataset_key=self.dataset_key, catalog_key=self.catalog_key ,project_key=self.project_key, deleted=False).first()
                if len(file_data) > 0 and len(datatypes)>0 and len(datasetInfo)>0:
                    return ({'status': "success", 'columns': file_data["metadata"]['columns'], 'data': datatypes,'datasetName':datasetInfo[0]['name']})
                else:
                    return ({'status':'error','message':'dataset key is invalid or does not exists'})
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status': "error", 'message': "dataset key is required"})
                else:
                    return ("dataset key is required")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))
    
    # Creating Dataset
    def create(self, **kwargs):
        try:
            updated_at = datetime.now()
            created_at = datetime.now()
            if 'description' in kwargs and kwargs['description'] is not None:
                description = kwargs['description'].strip()
            else:
                description = ""    
            
            if 'tags' in kwargs and kwargs['tags'] is not None:
                tags = kwargs['tags'].split(",")
            else:
                tags = []
            
            # Generating Key
            if self.dataset_key is not None:
                key = self.dataset_key
            else:
                response = catalog_helper.generate_key(kwargs['name'].strip())
                if response['status']=='error':
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return response
                    else: # For Notebook
                        return response['message']
                key = response['key']
            
            if 'is_build' in kwargs and kwargs['is_build'] is not None:
                if kwargs['is_build'] in [True,False]:
                    is_build = kwargs['is_build']
                else:
                    is_build = True
            else:
                is_build = True
            
            if 'created_at' in kwargs.keys():
                if kwargs['created_at'] != None:
                    created_at = kwargs["created_at"]

            if 'updated_at' in kwargs.keys():
                if kwargs['updated_at'] != None:
                    updated_at = kwargs["updated_at"]

            if is_build is True: # Creating dataset with File
                if 'data_source' in kwargs and kwargs['data_source'] is not None:
                    datasetObj = self.dataset_schema(name=kwargs['name'].strip(),key=key,project_key=self.project_key,catalog_key=self.catalog_key, description=description, tags=tags, datasource=kwargs['data_source'], is_build=is_build, created_at =created_at, updated_at=updated_at)
                    datasetObj.save()
                    dataset_id = str(datasetObj.id)
                    
                    dataset_resp = dataset_helper.get_dataset(catalog_key=self.catalog_key, project_key=self.project_key ,dataset_id=dataset_id)
                    
                    if dataset_resp['status']=='error':
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return dataset_resp
                        else:  # For Notebook
                            return dataset_resp['message']
                    dataset = dataset_resp['dataset']
                    self.dataset_key = dataset['key']
                    data_frame = self.get_dataframe(sampling_name='all',request_from='api')
                    
                    if data_frame['status'] == 'error':
                        if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                            return (data_frame)
                        else:  # For Notebook
                            return data_frame['message']
                    
                    # Version of API
                    version = environ.get('APIVERSION',None)
                    # Preview path
                    previewPath = '/api/'+version+'/dataset/'+key+'/preview?token='+kwargs['token']
                    
                    meta = {}
                    meta['source_name']     = datasetObj.datasource['source'][0]['filename']
                    meta['source_format']   = datasetObj.datasource['source'][0]['format'] or 'csv'
                    meta['target_name']     = datasetObj.datasource['target']['filename']
                    meta['path']            = previewPath
                    meta['columns']         = data_frame['dataFrame'].columns.tolist()
                    meta['row_count']       = data_frame['dataFrame'].shape[0]
                    
                    # Default Sampling
                    default_records = environ.get('DEFAULT_RECORD_COUNT',None)
                    operation = {
                        'sampling': {
                            "name":"first",
                            "column_name":"",
                            "records": int(default_records),
                            "ratio":""
                        },
                        'freeze_column_index': [],
                        'filters': [],
                        'sorting': [],
                        'column_index': [],
                        'hide_column': [],
                        'date_format':[]
                    }
                    
                    fileObj = self.file_schema(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=key, metadata=meta, operation=operation)
                    # with open(meta_path + "/metadata.json", 'rb') as meta:
                    #     fileObj.meta_data.put(meta)
                    fileObj.save()
                    
                    arguments = {
                        "catalog_key": self.catalog_key,
                        "project_key": self.project_key,
                        "dataset_key": self.dataset_key
                    }
                    
                    result = dataset_helper.store_whole_meta(arguments)
                    
                    # Update path in dataset schema
                    datasetObj = self.dataset_schema.objects(id=datasetObj.id,project_key=self.project_key,catalog_key=self.catalog_key).modify(new=True, set__path=previewPath)
                    
                    if 'source_type' in kwargs and kwargs['source_type'] is not None:
                        if kwargs['source_type']!='predicted':
                            # Pipeline Dataset Creation
                            pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,self.dataset_key)
                            pipeline_resp = pipelineObj.create()
                    
                    return dataset_helper.dataset_response(dataset=datasetObj)
            else:  # Creating dataset without file
                datasetObj = self.dataset_schema(name=kwargs['name'].strip(),key=key,project_key=self.project_key,catalog_key=self.catalog_key, description=description, tags=tags, path="",is_build=False)
                datasetObj.save()
                # Pipeline Dataset Creation
                pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,key)
                pipeline_resp = pipelineObj.create()
                return dataset_helper.dataset_response(dataset=datasetObj)
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))
    
    # Updating dataset
    def update(self, **kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
                description = None
                tags = None
                dataset_name = None
                add_to_pipeline = None
                if 'name' in kwargs and kwargs['name'] is not None:
                    dataset_name = kwargs['name'].strip()

                if 'description' in kwargs and kwargs['description'] is not None:
                    description = kwargs['description'].strip()
                
                if 'tags' in kwargs.keys() and kwargs['tags'] is not None:
                    tags = kwargs['tags'].split(",")
                
                # Fetching Dataset details by datasetId
                datasetObj          = self.dataset_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, key=self.dataset_key, deleted=False).to_json()
                datasetObj          = loads(datasetObj)
                if len(datasetObj)>0:
                    dataset_name    = dataset_name if dataset_name is not None else datasetObj[0]['name'] 
                    description     = description if description is not None else datasetObj[0]['description']
                    tags            = tags if tags is not None else datasetObj[0]['tags']  
                    data_source     = datasetObj[0]['datasource']
                    if 'pipeline' in kwargs.keys() and kwargs['pipeline'] in ['yes']:
                        if 'add_to_pipeline' in data_source:
                            data_source['add_to_pipeline'] = True
                        
                    if 'data_source' in kwargs and kwargs['data_source'] is not None: # If CSV/Data Frame Exists
                        ds = kwargs['data_source']
                        # Version of API
                        version = environ.get('APIVERSION',None)
                        
                        # Preview path
                        previewPath = '/api/'+version+'/dataset/'+self.dataset_key+'/preview?token='+kwargs['token']
                        
                        # Updating data into dataset
                        datasetObj  = self.dataset_schema.objects(key=self.dataset_key,project_key=self.project_key,catalog_key=self.catalog_key).modify(
                            new=True,
                            set__name = dataset_name,
                            set__description = description,
                            set__tags = tags,
                            set__datasource = ds,
                            set__path = previewPath,
                            set__is_build = True,
                            set__updated_at = datetime.now()
                        )
                        data_frame = self.get_dataframe(sampling_name='all',request_from='api')
                        if data_frame['status'] == 'error':
                            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                return (data_frame)
                            else:  # For Notebook
                                return data_frame['message']
                        
                        data = {}
                        data['columns']         = data_frame['dataFrame'].columns.tolist()
                        data['row_count']       = data_frame['dataFrame'].shape[0]
                        # Updating data into data catalog
                        catalogDetails  = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(projects={'$elemMatch': {'key': self.project_key,'deleted':False}})
                        datasetsDetails = list(loads(dumps(catalogDetails[0]['projects'][0]['datasets'])))
                        counter = 0
                        for item in datasetsDetails:
                            if item['key'] == self.dataset_key:
                                datasetsDetails[counter]['name'] = dataset_name

                            counter = counter + 1
                        updatedResponse = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update(set__projects__S__datasets=datasetsDetails)

                        # Create File Schema
                        data['source_name']     = datasetObj.datasource['source'][0]['filename']
                        data['source_format']   = datasetObj.datasource['source'][0]['format']
                        data['target_name']     = datasetObj.datasource['target']['filename']
                        data['path']            = previewPath

                        # Default Sampling
                        default_records = environ.get('DEFAULT_RECORD_COUNT',None)
                        operation = {
                            'sampling': {
                                "name":"first",
                                "column_name":"",
                                "records": int(default_records),
                                "ratio":""
                            },
                            'freeze_column_index': [],
                            'filters': [],
                            'sorting': [],
                            'column_index': [],
                            'hide_column': [],
                            'date_format':[]
                        }
                        
                        fileObj = self.file_schema(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, metadata=data, operation=operation)
                        fileObj.save()
                        arguments = {
                            "catalog_key": self.catalog_key,
                            "project_key": self.project_key,
                            "dataset_key": self.dataset_key
                        }
                        result = dataset_helper.store_whole_meta(arguments)
                        # Pipeline Dataset Update
                        pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,self.dataset_key)
                        pipeline_resp = pipelineObj.update()

                        return dataset_helper.dataset_response(dataset=datasetObj,file=fileObj)
                    else:  # Updating dataset without file
                        # Updating data into dataset
                        datasetObj  = self.dataset_schema.objects(key=self.dataset_key,project_key=self.project_key).modify(
                            new= True,
                            set__name = dataset_name,
                            set__description = description,
                            set__tags = tags,
                            set__datasource = data_source, 
                            set__updated_at = datetime.now()
                        )

                        # Updating data into data catalog 
                        catalogDetails  = self.catalog_schema.objects.filter(key=self.catalog_key,deleted=False).fields(projects={'$elemMatch': {'key': self.project_key,'deleted':False}})
                        datasetsDetails = list(loads(dumps(catalogDetails[0]['projects'][0]['datasets'])))
                        counter = 0
                        for item in datasetsDetails:
                            if item['key'] == self.dataset_key:
                                datasetsDetails[counter]['name'] = dataset_name

                            counter = counter + 1
                        updatedResponse = self.catalog_schema.objects(key=self.catalog_key,deleted=False,projects={'$elemMatch': {'key': self.project_key,'deleted':False}}).update(set__projects__S__datasets=datasetsDetails)
                        
                        # Pipeline Dataset Update
                        pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,self.dataset_key)
                        pipeline_resp = pipelineObj.update()
                        
                        return dataset_helper.dataset_response(dataset=datasetObj)
                else:
                    if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                        return ({'status':"error",'messsage':"dataset key is invalid"})
                    else:  # For Notebook
                        return "dataset key is invalid"
            else:
                if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                    return ({'status':"error",'messsage':"Missing required parameters"})
                else:  # For Notebook
                    return "Missing required parameters"
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))
