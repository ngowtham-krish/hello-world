import numpy as np
import pandas as pd
from os import environ
import importlib.util, copy
from json import loads, dumps
from datetime import datetime
from strait.environment import load_env
from strait.core.recipes.history import History
from strait.core.model.schema import TransformationSchema, ColumnInfoSchema
import strait.core.helper.dataset_helper as dataset_helper
import strait.core.helper.wrangling_helper as wrangling_helper
import strait.core.helper.transformation_helper as transformation_helper

# Calling Enviroment Function
load_env()

class Wrangling:
    def __init__(self,**kwargs):
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = kwargs['project_key']
        
        if 'dataset_key' in kwargs and kwargs['dataset_key'] is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = kwargs['dataset_key']
        
        if 'recipe_key' in kwargs and kwargs['recipe_key'] is None: # For Notebook or Custom Recipe
            self.recipe_key = environ.get('RECIPE_KEY',None) 
        else: # For API   
            self.recipe_key = kwargs['recipe_key']
        
        if 'data_frame' in kwargs:
            self.data_frame = kwargs['data_frame']
        
        if 'sampling' in kwargs:
            self.sampling = kwargs['sampling']
        
        if 'format' in kwargs:
            self.format = kwargs['format']
        
        self.transformation_schema = TransformationSchema
        self.current_history = dict()
     
    def preview(self,**kwargs):
        try:
            if 'transformation_key' in kwargs:
                transformation_data = self.transformation_schema.objects(key=kwargs['transformation_key'], owners=self.catalog_key, deleted=False).to_json()
                transformation_data = list(loads(transformation_data))
                if len(transformation_data)==0:
                    transformation_data = self.transformation_schema.objects(key=kwargs['transformation_key'], transformation_type='predefined', deleted=False).to_json()
                    transformation_data = list(loads(transformation_data))
                    if len(transformation_data)==0:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status':'error','message':'Transformation id is invalid'})
                        else: # For NoteBook
                            return 'Transformation id is invalid'
                
                # Fetching code file path
                transformation_data = transformation_data[0]
                file_path = transformation_data['path']
                original_data_frame = self.data_frame
                schema = kwargs['schema']
                schema['data_frame'] = copy.deepcopy(self.data_frame)
                message = "Performing "+str(transformation_data['name'].lower())
                if transformation_data['transformation_level'] in ['column']:
                    if 'column_name' in kwargs and kwargs['column_name'] is None:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status':'error','message':'column name is required'})
                        else: # For NoteBook
                            return 'column name is required'
                    elif 'column_name' in kwargs and kwargs['column_name'] is not None:
                        schema['column_name'] = kwargs['column_name']
                        message = message +" on "+ str(kwargs['column_name'].lower()) + " column"
                    
                    if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                        if transformation_data['preview_column'] in [True]:
                            #schema['preview_column_name'] = str(kwargs['column_name']) + "__preview__"
                            schema['preview_column_name'] = "__preview__"

                    #schema['data_frame'] = self.data_frame[schema['column_name']]
                    #temp_data_frame = self.data_frame[schema['column_name']]
                else: # Passing Whole Data frame incase transformation level is entire dataset
                    pass
                    #temp_data_frame = self.data_frame
                    #schema['data_frame'] = self.data_frame
                
                # Storing Information For Add Step
                self.current_history['operation'] = {
                    'transformation_key': transformation_data['key'],
                    'transformation_level': transformation_data['transformation_level'],
                    'schema': schema,
                    'function_name': transformation_data['function_name'],
                    'original_df_columns': list(self.data_frame.columns),
                    'message':message
                }
                # Executing Code
                resp = transformation_helper.execute_code(file_path=file_path,function_name=transformation_data['function_name'],schema=schema,request_from="api")
                if resp['status'] == 'error': # For API
                    if 'request_from' in kwargs and kwargs['request_from']=='api':
                        return resp
                    else: # For NoteBook
                        return resp['message']
                
                data_frame = resp['data_frame']
                '''
                # If the supply and output data frame count is same and if new column name is enable
                if len(original_data_frame.columns.tolist()) == len(data_frame.columns.tolist()):
                    # Checking transformation level is column or not
                    if transformation_data['transformation_level'] in ['column']:
                        if transformation_data['new_column_name'] is not None:
                            idx = data_frame.columns.get_loc(schema['column_name'])
                            if transformation_data['new_column_name'] == transformation_data['name']: # If user has not given the new column name then adding column name to it
                                new_column_name = schema['column_name']+"_"+transformation_data['new_column_name'] 
                            else:
                                new_column_name = transformation_data['new_column_name']
                            original_data_frame.insert(loc=idx+1, column=new_column_name, value=data_frame[schema['column_name']])
                            data_frame = original_data_frame 
                '''
                
                # Replacing any NaN/None Value to Empty String
                data_frame.replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN',""], value=np.nan, inplace=True)
                data_frame.fillna("", inplace = True)
                
                if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                    if 'preview_column_name' in schema and schema['preview_column_name'] is not None: # If preview column exists
                        data_frame_copy = copy.deepcopy(data_frame)
                        data_frame_copy.drop(schema['column_name'], axis=1, inplace = True)
                        data_frame_copy.rename(columns={schema['preview_column_name']:schema['column_name']}, inplace=True)
                        self.current_history['operation']['schema']['data_frame'] = data_frame_copy
                    else: # If preview column does not exists
                        self.current_history['operation']['schema']['data_frame'] = data_frame
                else: # For Notebook
                    self.current_history['operation']['schema']['data_frame'] = data_frame
                
                if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                    # Storing preview data into file
                    data_frame_to_csv = data_frame.to_csv(index=False)
                    path_response = wrangling_helper.preview_path(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, data=data_frame_to_csv,file_name=transformation_data['key'])
                    if path_response['status'] == 'error':
                        return path_response
                    preview_path = path_response['file_path']
                    # Preparing Metadata
                    arguments = {
                        'catalog_key': self.catalog_key,
                        'project_key': self.project_key,
                        'dataset_key': self.dataset_key,
                        'recipe_key': self.recipe_key,
                        'sampling': self.sampling,
                        'path':preview_path
                    }
                    if transformation_data['transformation_level'] in ['column']:
                        if transformation_data['key'] in ['remove_column','trim_consecutive_whitespace','move_column']:
                            pass
                        else:
                            if 'original_df_columns' in self.current_history['operation'] and self.current_history['operation']['original_df_columns'] is not None:
                                transform_df_columns = list(data_frame.columns)
                                original_df_columns = list(self.data_frame.columns)
                                if len(original_df_columns)!=len(transform_df_columns):
                                    temp = []
                                    for item in transform_df_columns:
                                        if item not in original_df_columns:
                                            temp.append(item)
                                    
                                    for item in temp:
                                        resp = dataset_helper.store_column_meta(arguments,item)
                                else:
                                    if transformation_data['key'] in ['rename_column']:
                                        resp = dataset_helper.store_column_meta(arguments,schema['new_column_name'])
                                    else:
                                        resp = dataset_helper.store_column_meta(arguments,schema['column_name'])
                    else:
                        resp = dataset_helper.store_whole_meta(arguments)
                    return wrangling_helper.wrangling_response(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, recipe_key=self.recipe_key, data_frame=data_frame, format=self.format)
                else: # For Note Book
                    return data_frame
            else:
                if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                    return ({'status':'error','message':'Transformation id is required'})
                else: # For NoteBook
                    return 'Transformation id is required'
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For NoteBook
                return str(e)
    
    def add(self,**kwargs):
        try:
            if self.catalog_key is None and self.project_key is None and self.dataset_key is None and self.recipe_key is None:
                if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                    return ({'status':'error','message':'Missing required parameters'})
                else: # For Note Book
                    return "Missing required parameters"
            else:
                # Logic to do
                # Remove preview column need to be added and again metadata calculation is needed 
                history_obj = History(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key)
                history_resp= history_obj.create(parameters=self.current_history['operation'],sampling=self.sampling)
                if history_resp['status'] == 'error':
                    if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                        return history_resp
                    else: # For NoteBook
                        return history_resp['message']
                else:
                    if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                        return wrangling_helper.wrangling_response(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, recipe_key=self.recipe_key, data_frame=history_resp['data_frame'], format=self.format)
                    else: # For Note Book
                        return history_resp['data_frame']
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For NoteBook
                return str(e)
        
    # Clearing current history and operation and passing data frame
    def cancel(self,**kwargs):
        try:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                # Preparing Metadata
                arguments = {
                    'catalog_key': self.catalog_key,
                    'project_key': self.project_key,
                    'dataset_key': self.dataset_key,
                    'recipe_key': self.recipe_key
                }
                if self.current_history['operation']['transformation_level'] in ['column']:
                    resp = dataset_helper.store_column_meta(arguments,self.current_history['operation']['schema']['column_name'])
                else:
                    resp = dataset_helper.store_whole_meta(arguments)
                self.current_history = {}
                return wrangling_helper.wrangling_response(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, recipe_key=self.recipe_key, data_frame=self.data_frame, format=self.format)
            else: # For Note Book
                return self.data_frame
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For NoteBook
                return str(e)
 
    # Entire Dataset
    def entire_dataset(self,**kwargs):
        try:
            if 'transformation_key' in kwargs and kwargs['transformation_key'] is not None:
                transformation_data = self.transformation_schema.objects(key=kwargs['transformation_key'], owners=self.catalog_key, deleted=False).to_json()
                transformation_data = list(loads(transformation_data))
                if len(transformation_data)==0:
                    transformation_data = self.transformation_schema.objects(key=kwargs['transformation_key'], transformation_type='predefined', deleted=False).to_json()
                    transformation_data = list(loads(transformation_data))
                    if len(transformation_data)==0:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status':'error','message':'Transformation id is invalid'})
                        else: # For NoteBook
                            return 'Transformation id is invalid'
                
                # Fetching code file path
                transformation_data = transformation_data[0]
                file_path = transformation_data['path']
                schema = kwargs['schema']
                schema['data_frame'] = copy.deepcopy(self.data_frame)
                message = "Performing "+str(transformation_data['name'].lower())
                
                # Storing Information For Add Step
                operation = {
                    'transformation_key': transformation_data['key'],
                    'transformation_level': transformation_data['transformation_level'],
                    'schema': schema,
                    'function_name': transformation_data['function_name'],
                    'message':message
                }
                
                # Executing Code
                resp = transformation_helper.execute_code(file_path=file_path,function_name=transformation_data['function_name'],schema=schema,request_from="api")
                if resp['status'] == 'error': # For API
                    if 'request_from' in kwargs and kwargs['request_from']=='api':
                        return resp
                    else: # For NoteBook
                        return resp['message']
                
                data_frame = resp['data_frame']
                
                # Replacing any NaN/None Value to Empty String
                data_frame.replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN',""], value=np.nan, inplace=True)
                data_frame.fillna("", inplace = True)
                
                operation["schema"]["data_frame"] = data_frame
                # Remove preview column need to be added and again metadata calculation is needed 
                history_obj = History(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key)
                history_resp= history_obj.create(parameters=operation,sampling=self.sampling)
                
                if history_resp['status'] == 'error':
                    if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                        return history_resp
                    else: # For NoteBook
                        return history_resp['message']
                else:              
                    if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                        # Storing preview data into file
                        data_frame_to_csv = data_frame.to_csv(index=False)
                        path_response = wrangling_helper.preview_path(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, data=data_frame_to_csv,file_name=transformation_data['key'])
                        if path_response['status'] == 'error':
                            return path_response
                        preview_path = path_response['file_path']
                        # Preparing Metadata
                        arguments = {
                            'catalog_key': self.catalog_key,
                            'project_key': self.project_key,
                            'dataset_key': self.dataset_key,
                            'recipe_key': self.recipe_key,
                            'sampling': self.sampling,
                            'path':preview_path
                        }
                        resp = dataset_helper.store_whole_meta(arguments)
                        return wrangling_helper.wrangling_response(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, recipe_key=self.recipe_key, data_frame=data_frame, format=self.format)
                    else: # For Note Book
                        return data_frame
            else:
                if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                    return ({'status':'error','message':'Transformation id is invalid'})
                else: # For NoteBook
                    return ("Transformation id is invalid")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For NoteBook
                return str(e)

    def delete(self, **kwargs):
        try:
            if 'history_id' in kwargs and kwargs['history_id'] is not None:
                history_obj = History(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key)
                history_resp= history_obj.delete(kwargs['history_id'])
                return ({'status':'success','data': history_resp})
            else:
                if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For UI
                    return ({'status':'error','message':'History id is invalid'})
                else: # For NoteBook
                    return ("History id is invalid")
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For NoteBook
                return str(e)

    # For Filtering okNotOk, Histogram
    def filters(self,**kwargs):
        try:
            if 'request' in kwargs and kwargs['request'] is not None:
                request = kwargs['request']
                if 'okNotOk' in request.form and request.form['okNotOk'] is not None:
                    ok_not_ok = request.form['okNotOk'].lower()
                    column_name = request.form['columnName']
                    if self.recipe_key is None:
                        column_info_data = ColumnInfoSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,column_name=column_name).to_json()
                        column_info_data = list(loads(column_info_data))
                    else:
                        column_info_data = ColumnInfoSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,recipe_key=self.recipe_key,column_name=column_name).to_json()
                        column_info_data = list(loads(column_info_data))
                        if len(column_info_data) == 0:
                            column_info_data = ColumnInfoSchema.objects(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key,column_name=column_name).to_json()
                            column_info_data = list(loads(column_info_data))
                    if len(column_info_data)>0:
                        ok_not_ok_path = column_info_data[0]['oknotok']
                        f = open(ok_not_ok_path, "r")
                        ok_not_ok_data = f.read()
                        ok_not_ok_data = loads(ok_not_ok_data)
                        index = None
                        if ok_not_ok in ['ok','not_ok','empty']:
                            if ok_not_ok in ['ok']:
                                if len(ok_not_ok_data['ok'])>0:
                                    index = ok_not_ok_data['ok']
                            elif ok_not_ok in ['not_ok']:
                                if len(ok_not_ok_data['not_ok'])>0:
                                    index = ok_not_ok_data['not_ok']
                            elif ok_not_ok in ['empty']:
                                if len(ok_not_ok_data['empty'])>0:
                                    index = ok_not_ok_data['empty']
                        if index is not None:
                            data_frame = self.data_frame.iloc[index] 
                        else:
                            row_count = self.data_frame.shape[0] + 1
                            data_frame = self.data_frame.iloc[row_count:]
            
                return wrangling_helper.wrangling_response(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, recipe_key=self.recipe_key, data_frame=data_frame, format=self.format)
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] == 'api': # For API
                return ({'status': 'error', 'message': str(e)})
            else: # For NoteBook
                return str(e)