import time
from os import path, environ
from xlrd import open_workbook
from json import loads, dumps, dump
from strait.environment import load_env
import strait.core.connectors as connectors
import strait.core.dataset as dataset
import strait.core.helper.catalog_helper as catalog_helper
import strait.core.helper.dataset_helper as dataset_helper
import strait.nifi.helper.process_group_helper as process_group_helper
from strait.core.model.schema import DatasetSchema

# Calling Enviroment Function
load_env()

class DataSource:

    def __init__(self,catalog_key=None, project_key=None, dataset_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = catalog_key

        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = project_key

        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = dataset_key 

    # For Creating the dataset        
    def create_dataset(self,**kwargs):
        try:
            print("--- Inside create dataset of datasource methods -----")
            if self.catalog_key is not None and self.project_key is not None :
                if 'request_from' in kwargs and kwargs['request_from'] is not None:
                    if kwargs['request_from'] in ['api']:
                        request_from = 'api'
                    else:
                        request_from = 'notebook'
                else:
                    request_from = 'notebook'
                
                # Cheking if key is temp then not allowing user because it is a reserve key
                if self.dataset_key in ['temp','nifi']:
                    return ({'status':"error",'message':"dataset name already exists"})
                
                # For File
                if 'file' in kwargs and kwargs['file'] is not None:
                    file_obj = kwargs['file']
                    
                    if 'source_type' in kwargs and kwargs['source_type'] is not None:
                        source_type = "file" # Default
                        if kwargs['source_type'] in ["upload",'predicted','custom']:
                            if kwargs['source_type'] in ["upload"]:
                                source_type = "file"
                            else:
                                source_type = kwargs['source_type']
                        
                        if source_type in ['file','predicted']:
                            file_type = file_obj.filename.split(".")
                            if file_type[1] in ['xls','xlsx']: # For XLSX/XLS
                                path_resp = dataset_helper.create_file_path(catalog_key=self.catalog_key, project_key=self.project_key, return_type='temp')
                                if path_resp['status'] in ['error']:
                                    return path_resp
                                
                                dataset_dir     = path_resp['file_path']
                                fileName        = file_obj.filename.split('.')
                                timestamp       = int(round(time.time() * 1000))
                                source_file_name= fileName[0] + "-"+ str(timestamp) + "." + fileName[1]
                                source_file_path= path.join(dataset_dir, source_file_name)
                                file_obj.save(source_file_path)

                                wb = open_workbook(source_file_path)
                                sheet_name = []
                                
                                # Total sheet count
                                sheet_count = wb.nsheets
                                
                                # Adding all the sheet name of XLS into sheet_name variables
                                sheet_name = wb.sheet_names()
                                
                                # Validating the user given sheet name is correct or not by sheet_name variables
                                if 'sheet_name' in kwargs and kwargs['sheet_name'] is not None:
                                    given_sheet_name = kwargs['sheet_name'].split(',')
                                    # Checking whether sheet name is valid or not
                                    if len(given_sheet_name)>0:
                                        for item in given_sheet_name:
                                            if item not in sheet_name:
                                                return ({'status':'error','message':"Sheet name is invalid"})
                                else: # All Sheet
                                    given_sheet_name = sheet_name
                                
                                # Checking whether in header column name is exists or not 
                                header_column_exists = []
                                if 'header_column_exists' in kwargs and kwargs['header_column_exists'] is not None:
                                    header_column_exists = kwargs['header_column_exists'].split(',')
                                    i = 0
                                    for item in header_column_exists:
                                        if item in [False,'false','FALSE','False']:
                                            header_column_exists[i] = False
                                        else:
                                            header_column_exists[i] = True
                                        i = i + 1
                                else: # Default Assuming Header Exists
                                    for item in given_sheet_name:
                                        header_column_exists.append(True)
                                
                                # Skip First N number rows
                                skip_lines = []
                                if 'skip_lines' in kwargs and kwargs['skip_lines'] is not None:
                                    skip_lines = kwargs['skip_lines'].split(',')
                                    j = 0
                                    for i in skip_lines: 
                                        if (int(i) < 0):
                                            skip_lines[j] = 0
                                        else:
                                            skip_lines[j] = int(i)
                                            '''
                                            if ((int(i)-1)<0):
                                                skip_lines[j] = int(i)
                                            else:
                                                skip_lines[j] = int(i) - 1
                                            '''
                                        j +=1
                                else: # Default Assuming Skip 0 rows
                                    for item in given_sheet_name:
                                        skip_lines.append(0)
                                
                                # From the given sheet name get the index XLSX/XLS sheet (To Do)
                                sheet_index = []
                                for item in given_sheet_name:
                                    sheet_index.append(sheet_name.index(item))
                                
                                j = 0
                                # Adding sheet names
                                #for i in range(0, sheet_count):
                                for i in sheet_index:
                                    sheet = wb.sheet_by_index(i) # Pass sheet to storage
                                    if sheet.name in given_sheet_name:
                                        dataset_name = sheet.name.strip()
                                        # Checking whether dataset name already exists or not
                                        dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_name=dataset_name,request_from='create')
                                        if dataset_resp['status'] in ['error']:
                                            return dataset_resp
                                        
                                        dataset_name_len = len(dataset_resp['data'])
                                        print("dataset_name_len "+str(dataset_name_len))
                                        if dataset_name_len != 0:
                                            dataset_name = dataset_name+"_"+str(dataset_name_len)
                                        
                                        # Generating dataset key based on sheet name
                                        response = catalog_helper.generate_key(dataset_name)
                                        if response['status']=='error':
                                            if 'request_from' in kwargs and kwargs['request_from'] in ['api']: # For API
                                                return response
                                            else: # For Notebook
                                                return response['message']
                                        # Checking whether dataset name already exists or not
                                        dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=response['key'])
                                        if dataset_resp['status'] in ['error']:
                                            return dataset_resp
                                        self.dataset_key = response['key']

                                        dataset_info = self.from_file(file=file_obj, 
                                                                      sheet=sheet, 
                                                                      source_type=source_type, 
                                                                      header_column_exists=header_column_exists[j],
                                                                      file_type=file_type[1],
                                                                      skip_lines=skip_lines[j],
                                                                      given_sheet_name=given_sheet_name)
                                        if dataset_info['status'] in ['error']:
                                            if request_from in ['api']: # For API
                                                return dataset_info
                                            else: # For Notebook
                                                return dataset_info['message']
                                        j = j + 1
                                        data_source = dataset_info['config']
                                        if 'source' not in data_source and 'target' not in data_source:
                                            if request_from in ['api']: # For API
                                                return ({'status':"error",'message':"Some error occur while uploading file"})
                                            else:  # For Notebook
                                                return "Some error occur while uploading file"
                                        
                                        dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                                        dataset_resp    = dataset_obj.create(name=dataset_name, description=kwargs['description'], tags=kwargs['tags'],is_build=True,data_source=data_source,source_type=source_type,token=kwargs['token'],request_from=request_from)
                                        # To return the first sheet response
                                        if sheet.name == given_sheet_name[0]:
                                            first_sheet_resp = dataset_resp
                                return first_sheet_resp

                            elif file_type[1] in ['csv']: # For CSV
                                dataset_name = kwargs['name'].strip()
                                # Checking whether dataset name already exists or not
                                dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_name=dataset_name,request_from='create')
                                if dataset_resp['status'] in ['error']:
                                    return dataset_resp
                                
                                dataset_name_len = len(dataset_resp['data'])
                                print("dataset_name_len "+str(dataset_name_len))
                                if dataset_name_len != 0:
                                    dataset_name = dataset_name+"_"+str(dataset_name_len)
                                
                                if 'key' in kwargs and kwargs['key'] is not None:
                                    key = kwargs['key']
                                else:
                                    response = catalog_helper.generate_key(dataset_name)
                                    if response['status']=='error':
                                        return response
                                    key = response['key']
                                
                                # Checking whether dataset name already exists or not
                                dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=key)
                                if dataset_resp['status'] in ['error']:
                                    return dataset_resp
                                self.dataset_key = key
                                
                                # Checking whether delimiter exists or not 
                                delimiter = "," # Default
                                if 'delimiter' in kwargs and kwargs['delimiter'] is not None:
                                    delimiter = kwargs['delimiter']
                                
                                # Checking whether in header column name is exists or not 
                                header_column_exists = True # Default
                                if 'header_column_exists' in kwargs and kwargs['header_column_exists'] is not None:
                                    if kwargs['header_column_exists'] in [False,'false','FALSE','False']:
                                        header_column_exists = False
                                    else:
                                        header_column_exists = True
                                
                                # Checking whether skip N rows exists or not 
                                skip_lines = 0 # Default
                                if 'skip_lines' in kwargs and kwargs['skip_lines'] is not None:
                                    if int(kwargs['skip_lines'])<0:
                                        skip_lines = 0
                                    else:
                                        skip_lines = int(kwargs['skip_lines'])
                                        '''
                                        if (int(kwargs['skip_lines'])-1)<0:
                                            skip_lines = 0
                                        else:
                                            skip_lines = int(kwargs['skip_lines']) - 1 
                                        '''
                                dataset_info = self.from_file(file=file_obj, 
                                                              source_type=source_type, 
                                                              header_column_exists=header_column_exists,
                                                              file_type=file_type[1],
                                                              skip_lines=skip_lines,
                                                              delimiter=delimiter)
                                if dataset_info['status'] in ['error']:
                                    if request_from in ['api']: # For API
                                        return dataset_info
                                    else: # For Notebook
                                        return dataset_info['message']
                                
                                data_source = dataset_info['config']
                                if 'source' not in data_source and 'target' not in data_source:
                                    if request_from in ['api']: # For API
                                        return ({'status':"error",'message':"Some error occur while uploading file"})
                                    else:  # For Notebook
                                        return "Some error occur while uploading file"
                                
                                dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                                dataset_resp    = dataset_obj.create(name=kwargs["name"].strip(), 
                                                                     description=kwargs['description'], 
                                                                     tags=kwargs['tags'],
                                                                     is_build=True,
                                                                     data_source=data_source,
                                                                     source_type=source_type,
                                                                     token=kwargs['token'],
                                                                     request_from=request_from)
                                return dataset_resp
                elif 'data_frame' in kwargs and kwargs['data_frame'] is not None: # For Notebook (When data frame is passed)
                    # Checking whether in header column name is exists or not 
                    header_column_exists = True # Default
                    if 'header_column_exists' in kwargs and kwargs['header_column_exists'] is not None:
                        if kwargs['header_column_exists'] in [False,'false','FALSE','False']:
                            header_column_exists = kwargs['header_column_exists']
                        else:
                            header_column_exists = True
                    
                    # Checking whether skip N rows exists or not 
                    skip_lines = 0 # Default
                    if 'skip_lines' in kwargs and kwargs['skip_lines'] is not None:
                        if int(kwargs['skip_lines'])<0:
                            skip_lines = 0
                        else:
                            skip_lines = int(kwargs['skip_lines'])
                            '''
                            if (int(kwargs['skip_lines']) - 1)<0:
                                skip_lines = 0
                            else:
                                skip_lines = int(kwargs['skip_lines']) - 1
                            ''' 
                    
                    source_type = "custom" # Default
                    dataset_info = self.from_file(data_frame=kwargs['data_frame'], 
                                                  source_type=source_type, 
                                                  header_column_exists=header_column_exists,
                                                  file_type='custom',
                                                  skip_lines=skip_lines)
                    if dataset_info['status'] in ['error']:
                        if request_from in ['api']: # For API
                            return dataset_info
                        else: # For Notebook
                            return dataset_info['message']
                    
                    data_source = dataset_info['config']
                    if 'source' not in data_source and 'target' not in data_source:
                        if request_from in ['api']: # For API
                            return ({'status':"error",'message':"Some error occur while uploading file"})
                        else:  # For Notebook
                            return "Some error occur while uploading file"
                    
                    dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                    dataset_resp    = dataset_obj.create(name=kwargs["name"].strip(), 
                                                         description=kwargs['description'], 
                                                         tags=kwargs['tags'],
                                                         is_build=True,
                                                         data_source=data_source,
                                                         source_type=source_type,
                                                         token=kwargs['token'],
                                                         request_from=request_from)
                    return dataset_resp
                elif 'database_engine' in kwargs and kwargs['database_engine'] is not None and kwargs['database_engine'] in ['mysql','postgres']: # For SQL
                    print("--- Inside database_engine ---")
                    # Checking whether dataset name already exists or not
                    dataset_name = kwargs['name'].strip()
                    dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_name=dataset_name,request_from='create')
                    '''
                    if dataset_resp['status'] in ['error']:
                        while True: 
                            dataset_name = dataset_name +" "+ process_group_helper.random_string(8)  
                            dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_name=dataset_name,request_from='create')
                            if dataset_resp['status'] in ['success']:
                                break
                    '''
                    if dataset_resp['status'] in ['error']:
                        return dataset_resp
                    
                    dataset_name_len = len(dataset_resp['data'])
                    print("dataset_name_len "+str(dataset_name_len))
                    if dataset_name_len != 0:
                        dataset_name = dataset_name+"_"+str(dataset_name_len)
                        
                    if 'key' in kwargs and kwargs['key'] is not None:
                        key = kwargs['key']
                    else:
                        response = catalog_helper.generate_key(dataset_name.strip())
                        if response['status']=='error':
                            return response
                        key = response['key']
                    
                    # Checking whether dataset name already exists or not
                    dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=key)
                    if dataset_resp['status'] in ['error']:
                        return dataset_resp
                    self.dataset_key = key
                    
                    if 'table_details' in kwargs and kwargs['table_details'] is not None:
                        print("---- kwargs['table_details'] -------")
                        print(kwargs['table_details'])
                        dataset_info = self.from_sql(table_details=kwargs['table_details'], 
                                                    database_engine=kwargs['database_engine'], 
                                                    file_extension=kwargs['file_extension'])
                        print("--- dataset_info ----")
                        print(dataset_info)
                        data_source = dataset_info['config']
                        if 'source' not in data_source and 'target' not in data_source:
                            if request_from in ['api']: # For API
                                return ({'status':"error",'message':"Some error occur while uploading file"})
                            else:  # For Notebook
                                return "Some error occur while uploading file"
                        print("---- create dataset is getting called ----")
                        dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                        dataset_resp    = dataset_obj.create(name=dataset_name.strip(), 
                                                            is_build=True,
                                                            data_source=data_source,
                                                            source_type=kwargs['database_engine'],
                                                            token=kwargs['token'],
                                                            request_from=request_from)
                        return dataset_resp
            else:
                return ({'status':'error','message':'Missing required parameters'})
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))

    # For Updating the dataset
    def update_dataset(self,**kwargs):
        try:
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
                if 'request_from' in kwargs and kwargs['request_from'] is not None:
                    if kwargs['request_from'] in ['api']:
                        request_from = 'api'
                    else:
                        request_from = 'notebook'
                else:
                    request_from = 'notebook'
                
                if 'name' in kwargs and kwargs['name'] is not None:
                    if kwargs['name'].strip()!='':
                        # Checking whether dataset name already exists or not
                        dataset_resp = dataset_helper.dataset_name_exists(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key, dataset_name=kwargs['name'].strip(), request_from='update')
                        if dataset_resp['status'] in ['error']:
                            return dataset_resp
                
                if 'file' in kwargs and kwargs['file'] is not None: # Only CSV
                    file_obj = kwargs['file']
                    
                    if 'source_type' in kwargs and kwargs['source_type'] is not None:
                        source_type = "file" # Default
                        if kwargs['source_type'] in ["upload",'predicted','custom']:
                            if kwargs['source_type'] in ["upload"]:
                                source_type = "file"
                            else:
                                source_type = kwargs['source_type']
                        
                        if source_type in ['file','predicted']:
                            file_type = file_obj.filename.split(".")
                            if file_type[1] in ['csv']: # For CSV
                                # Checking whether delimiter exists or not 
                                delimiter = "," # Default
                                if 'delimiter' in kwargs and kwargs['delimiter'] is not None:
                                    delimiter = kwargs['delimiter']
                                
                                # Checking whether in header column name is exists or not 
                                header_column_exists = True # Default
                                if 'header_column_exists' in kwargs and kwargs['header_column_exists'] is not None:
                                    if kwargs['header_column_exists'] in [False,'false','FALSE','False']:
                                        header_column_exists = False
                                    else:
                                        header_column_exists = True
                                
                                # Checking whether skip N rows exists or not 
                                skip_lines = 0 # Default
                                if 'skip_lines' in kwargs and kwargs['skip_lines'] is not None:
                                    if int(kwargs['skip_lines'])<0:
                                        skip_lines = 0
                                    else:
                                        skip_lines = int(kwargs['skip_lines'])
                                        '''
                                        if (int(kwargs['skip_lines'])-1)<0:
                                            skip_lines = int(kwargs['skip_lines'])
                                        else:
                                            skip_lines = int(kwargs['skip_lines']) - 1 
                                        '''
                                
                                dataset_info = self.from_file(file=file_obj, 
                                                              source_type=source_type, 
                                                              header_column_exists=header_column_exists,
                                                              file_type=file_type[1],
                                                              skip_lines=skip_lines,
                                                              delimiter=delimiter)
                                
                                if dataset_info['status'] in ['error']:
                                    if request_from in ['api']: # For API
                                        return dataset_info
                                    else: # For Notebook
                                        return dataset_info['message']
                                
                                data_source = dataset_info['config']
                                if 'source' not in data_source and 'target' not in data_source:
                                    if request_from in ['api']: # For API
                                        return ({'status':"error",'message':"Some error occur while uploading file"})
                                    else:  # For Notebook
                                        return "Some error occur while uploading file" 
                                
                                dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                                dataset_resp    = dataset_obj.update(name=kwargs["name"], 
                                                                     description=kwargs['description'], 
                                                                     tags=kwargs['tags'], 
                                                                     is_build=True, 
                                                                     data_source=data_source, 
                                                                     source_type=source_type, 
                                                                     token=kwargs['token'], 
                                                                     request_from=request_from)
                                return dataset_resp
                elif 'data_frame' in kwargs and kwargs['data_frame'] is not None: # For Notebook (When data frame is passed)
                    source_type = "custom" # Default
                    # Checking whether in header column name is exists or not 
                    header_column_exists = True # Default
                    if 'header_column_exists' in kwargs and kwargs['header_column_exists'] is not None:
                        if kwargs['header_column_exists'] in [False,'false','FALSE','False']:
                            header_column_exists = kwargs['header_column_exists']
                        else:
                            header_column_exists = True
                    
                    # Checking whether skip N rows exists or not 
                    skip_lines = 0 # Default
                    if 'skip_lines' in kwargs and kwargs['skip_lines'] is not None:
                        if int(kwargs['skip_lines'])<0:
                            skip_lines = 0
                        else:
                            skip_lines = int(kwargs['skip_lines'])
                    
                    dataset_info = self.from_file(data_frame=kwargs['data_frame'], 
                                                  source_type=source_type, 
                                                  header_column_exists=header_column_exists,
                                                  file_type='custom',
                                                  skip_lines=skip_lines)
                    
                    if dataset_info['status'] in ['error']:
                        if request_from in ['api']: # For API
                            return dataset_info
                        else: # For Notebook
                            return dataset_info['message']
                    
                    data_source = dataset_info['config']
                    if 'source' not in data_source and 'target' not in data_source:
                        if request_from in ['api']: # For API
                            return ({'status':"error",'message':"Some error occur while uploading file"})
                        else:  # For Notebook
                            return "Some error occur while uploading file"
                    
                    dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                    dataset_resp    = dataset_obj.update(name=kwargs["name"].strip(), 
                                                         description=kwargs['description'], 
                                                         tags=kwargs['tags'], is_build=True, 
                                                         data_source=data_source, 
                                                         source_type=source_type, 
                                                         token=kwargs['token'], 
                                                         request_from=request_from)
                    return dataset_resp
                else: # Updating dataset without File
                    dataset_obj     = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=self.dataset_key)
                    dataset_resp    = dataset_obj.update(name=kwargs["name"].strip(), description=kwargs['description'], tags=kwargs['tags'], request_from=request_from)
                    return dataset_resp
            else:
                return ({'status':'error','message':'Missing required parameters'})
        except Exception as e:
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['api']: # For API
                    return ({'status': 'error', 'message':"Exception: "+ str(e)})
                else: # Fot Notebook
                    return ("Exception: "+ str(e))
            else: # Fot Notebook
                return ("Exception: "+ str(e))

    # For File (CSV/XLS/XLSX)
    def from_file(self,**kwargs):
        if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
            if 'file_type' in kwargs and kwargs['file_type'] is not None:
                if kwargs['file_type'] in ['xls','xlsx']:
                    connector_obj = connectors.Connectors(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key)
                    return connector_obj.FileSystem(file=kwargs['file'], sheet=kwargs['sheet'], source_type=kwargs['source_type'], header_column_exists=kwargs['header_column_exists'], file_type=kwargs['file_type'],skip_lines=kwargs['skip_lines'],given_sheet_name=kwargs['given_sheet_name'])
                if kwargs['file_type'] in ['csv']:
                    if 'file' in kwargs and kwargs['file'] is not None:
                        connector_obj = connectors.Connectors(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key)
                        return connector_obj.FileSystem(file=kwargs['file'], source_type=kwargs['source_type'], header_column_exists=kwargs['header_column_exists'], file_type=kwargs['file_type'],skip_lines=kwargs['skip_lines'],delimiter=kwargs['delimiter'])
                    else:
                        return ({'status':'error','message':'source is required'})
                if kwargs['file_type'] in ['custom']:
                    connector_obj = connectors.Connectors(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key)
                    return connector_obj.FileSystem(data_frame=kwargs['data_frame'], source_type=kwargs['source_type'], header_column_exists=kwargs['header_column_exists'], file_type=kwargs['file_type'],skip_lines=kwargs['skip_lines'])
            else:
                return ({'status':'error','message':'File type is required'})
        else:
            return ({'status':'error','message':'Missing required parameters'})
    
    def from_dict(self, *args):
        pass
    
    def from_sql(self, **kwargs):
        print("--- Inside from sql in datasource methods -----")
        print("catalog_key "+self.catalog_key+" project_key "+self.project_key+" dataset_key "+self.dataset_key)
        if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
            print("--- Inside if of from_sql ---")
            connector_obj = connectors.Connectors(catalog_key=self.catalog_key,project_key=self.project_key,dataset_key=self.dataset_key)
            return connector_obj.sql(table_details=kwargs['table_details'], database_engine=kwargs['database_engine'], file_extension=kwargs['file_extension'])
        else:
            return ({'status':'error','message':'Missing required parameters'})
    
    def from_nosql(self, *args):
        pass

    def from_hdfs(self, *args):
        pass
    
    def from_ftp(self, *args):
        pass
    
    def from_api(self, *args):
        pass
    
    def from_list(self, *args):
        pass