import importlib.util
import pandas as pd
from json import loads 
from sys import exc_info
import time, shutil, re, random, string
from os import path, getcwd, makedirs, environ, rename, remove
import strait.core.dataset as dataset
from strait.environment import load_env
import strait.auth.helper.validate as validate_helper
from strait.core.model.schema import TransformationSchema

# Calling Enviroment Function
load_env()

def validate_code(**kwargs):
    try:
        base_path = environ.get('STORAGE',None)
        # Fetching data frame when user has selected a specific dataset for validating the code
        if 'catalog_key' in kwargs and 'project_key' in kwargs and 'dataset_key' in kwargs and kwargs['catalog_key'] is not None and kwargs['project_key'] is not None and kwargs['dataset_key'] is not None:
            dataset_obj = dataset.Dataset(kwargs['catalog_key'],kwargs['project_key'],kwargs['dataset_key'])
            records = int(environ.get('DEFAULT_RECORD_COUNT',None))
            '''
            sampling={
                'name':'random_records',
                'records':records,
                'ratio':"",
                'column_name':""
            }
            '''
            df = dataset_obj.get_dataframe(sampling_name='all', request_from='notebook') #,sampling=sampling
        else: # Fetching Dummy Dataset From Root Folder
            soruce_file_path= path.join(base_path, 'titanic_data.csv')
            df = pd.read_csv(soruce_file_path,encoding="ISO-8859-1")
        
        # Adding data frame to schema
        schema = {
            'data_frame' : df
        }
        
        if 'column_name' in kwargs and kwargs['column_name'] is not None:
            schema['column_name'] = kwargs['column_name']
        
        if len(kwargs["schema"])==0:
            pass
        else:
            for i in kwargs["schema"]:
                schema[i["name"]] = i["value"]
        return execute_code(file_path=kwargs['file_path'],function_name=kwargs["function_name"], schema=schema, request_from=kwargs['request_from'])
    except Exception as e:
        return ({'status': 'error', 'message': str(e)})

def create_file_path(**kwargs):
    try:
        base_path = environ.get('STORAGE',None)
        if 'validate_code' in kwargs and kwargs['validate_code'] == True: # For Temp Path
            # Making catalog folder to store respective projects inside that
            catalog_dir = path.join(base_path,kwargs['catalog_key'])
            if not path.exists(catalog_dir):
                makedirs(catalog_dir) 
            
            # Creating temp folder to store custom transformation code
            temp_dir = path.join(catalog_dir,'temp_transformation')
            if not path.exists(temp_dir):
                makedirs(temp_dir)
            path_dir  = temp_dir
            timestamp = int(round(time.time() * 1000))
            source_file_name = validate_helper.random_string(10,'alpha_numeric') + "-"+ str(timestamp) + ".py"
        else: # Either Prepare or Custom Transformation
            # Checking catalog_key whether it is system admin
            system_admin = environ.get('SYSTEM_ADMIN',None)
            if kwargs['catalog_key'] in [system_admin]: # Predefined Transformation (System Admin)
                # Making predefined transformation folder to store transformation code which will accessible by all
                predefined_transformation = path.join(base_path,'predefined_transformation')
                if not path.exists(predefined_transformation):
                    makedirs(predefined_transformation)
                path_dir = predefined_transformation

            else: # Custom Transformation (Admin/Users)
                # Making catalog folder to store respective projects inside that
                catalog_dir = path.join(base_path,kwargs['catalog_key'])
                if not path.exists(catalog_dir):
                    makedirs(catalog_dir) 
                
                # Making custom transformation folder to store custom transformation code
                custom_transformation_dir = path.join(catalog_dir,'custom_transformation')
                if not path.exists(custom_transformation_dir):
                    makedirs(custom_transformation_dir)
                path_dir = custom_transformation_dir

            if kwargs['catalog_key'] in [system_admin]:
                source_file_name= kwargs['transformation_key'] + ".py"
            else:
                timestamp   = int(round(time.time() * 1000))
                source_file_name= kwargs['transformation_key'] + "-"+ str(timestamp) + ".py"
        soruce_file_path= path.join(path_dir, source_file_name)
        source_file     = open(soruce_file_path, "w")
        source_file.write(kwargs['code'])
        source_file.close()
        return ({'status':'success','file_path':soruce_file_path})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

def validate_transformation(**kwargs):
    try:
        if 'transformationId' in kwargs and kwargs['transformationId'] is not None:
            response = TransformationSchema.objects(id=kwargs['transformationId'],deleted=False).to_json()
            response = list(loads(response))
            if len(response)==0:
                return ({'status':"error",'message':"Transformation id is invalid"})
            else:
                return ({'status':"success",'data':response[0]})
        elif 'transformation_key' in kwargs and kwargs['transformation_key'] is not None:
            if 'request_from' in kwargs and kwargs['request_from'] in ['add_transformation']:
                system_admin = environ.get('SYSTEM_ADMIN',None)
                response = TransformationSchema.objects(key=kwargs['transformation_key'], transformation_type='predefined', deleted=False).to_json()
                response = list(loads(response))
                if len(response)>0:
                    return ({'status':'error','message':'Transformation name already exists'})

                if kwargs['catalog_key'] in [system_admin]:
                    response = TransformationSchema.objects(key=kwargs['transformation_key'], transformation_type='custom', deleted=False).to_json()
                    response = list(loads(response))
                    if len(response)>0:
                        return ({'status':'error','message':'Transformation name already exists'})
                else:
                    # If user trying to create with the same name 
                    response = TransformationSchema.objects(key=kwargs['transformation_key'], owners=kwargs['catalog_key'], transformation_type='custom', deleted=False).to_json()
                    response = list(loads(response))
                    if len(response)>0:
                        return ({'status':'error','message':'Transformation name already exists'})
                
                return ({'status':"success"})
            else:
                response = TransformationSchema.objects(key=kwargs['transformation_key'], owners=kwargs['catalog_key'], deleted=False).to_json()
                response = list(loads(response))
                if len(response)==0:
                    # Checking whether given transformation key is predefined or not
                    response = TransformationSchema.objects(key=kwargs['transformation_key'], transformation_type='predefined', deleted=False).to_json()
                    response = list(loads(response))
                    if len(response)==0:
                        return ({'status':"error",'message':"Transformation key is invalid"})
                    else:
                        response = response[0]
                else:
                    response = response[0]
                return ({'status':"success",'data':response})
    except Exception as e:
        return ({'status': 'error', 'message': str(e)})

def execute_code(**kwargs):
    try:
        if 'file_path' in kwargs and 'function_name' in kwargs and 'schema' in kwargs:
            spec = importlib.util.spec_from_file_location("module.name", kwargs['file_path'])
            model = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(model)
            func_name = kwargs["function_name"]
            model  = getattr(model, func_name)(kwargs['schema'])
            if 'status' in model and model['status'] in ['error']:
                if 'request_from' in kwargs and kwargs['request_from']=='api':
                    return model
                else:
                    return model['message']

            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status':'success','data_frame':model})
            else: # NoteBook
                return model
            '''
            if 'status' in model and model['status']=='error':
                return model
            else:
                return ({'status':'success','data_frame':model})
            '''
        else:
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status':'error','message':'Misssing required parameter'})
            else:
                return ("Misssing required parameter")
    except NameError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        #fname = path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        #print(exc_type, fname, exc_tb.tb_lineno)
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "NameError: " + str(e) + " at line "+ str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("NameError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except KeyError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "KeyError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("KeyError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except ValueError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "ValueError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("ValueError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except IndexError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "IndexError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("IndexError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except TypeError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "TypeError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("TypeError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except OverflowError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "OverflowError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("OverflowError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except IndentationError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "IndentationError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("IndentationError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except ZeroDivisionError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "ZeroDivisionError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("ZeroDivisionError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except ImportError as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "ImportError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("ImportError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    except Exception as e:
        exc_type, exc_obj, exc_tb = exc_info()
        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
            return ({'status': 'error', 'message': "Exception: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
        else: # NoteBook
            return  ("Exception: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
