import re
from json import loads
from bson import ObjectId
from strait.core.model.schema import CatalogSchema

def validate_catalog(catalogKey=None,catalogId=None):
    if catalogId!=None:
        response = CatalogSchema.objects(id=ObjectId(catalogId),deleted=False).to_json()
        key = "catalog id"
    elif catalogKey!=None:
        response = CatalogSchema.objects(key=catalogKey,deleted=False).to_json()
        key = "catalog key"
    response = list(loads(response))
    if len(response)==0:
        return ({'status':"error",'message': key+" is invalid or does not exists"})
    else:
        return ({'status':"success"})

def validate_catalog_project(catalogKey=None,projectKey=None):
    if catalogKey!=None and projectKey!=None:
        updatedResponse = CatalogSchema.objects(key=catalogKey,deleted=False,projects={'$elemMatch': {'key': projectKey,'deleted':False}}).to_json()
        resp = list(loads(updatedResponse))
        if len(resp)==0:
            return ({'status':"error",'message': "catalog or project key is invalid or does not exists"})
        else:
            return ({'status':"success"})
    else:
        return ({'status':"error","message": "catalog and project key is required"})

def catalog_response(catalog):
    if(catalog.id!=None):
        #'catalogId' : str(catalog.id),
        response = {
            'catalogKey': str(catalog.key),
            'name' : catalog.name,
            'deleted' : catalog.deleted,
            'updatedAt' : str(catalog.updated_at)
        }

        return ({'status':'success','data':response})
    else:
        return ({'status':'error','message':'Some error occur while creating catalog'})

# Generating key by Name
def generate_key(name):
    if name!=None and name!="":
        # Only allowing alphanumeric characters
        name = re.sub('[^a-zA-Z0-9 ]','', name)
        # Replacing space with underscore
        key = name.replace(" ", "_")
        return ({"status":"success",'key':key.lower()}) 
    else:
        return ({'status':"error",'message':"name is required"})
