import re
from json import loads
from bson import ObjectId
from os import path, environ, makedirs
from strait.core.model.schema import ProjectSchema

# Validate Project
def validate_project(catalogKey=None,projectKey=None,projectId=None):
    if catalogKey is not None:
        if projectId is not None:
            response = ProjectSchema.objects(id=ObjectId(projectId),catalog_key=catalogKey,deleted=False).to_json()
            key = "project id"
        elif projectKey is not None:
            response = ProjectSchema.objects(key=projectKey,catalog_key=catalogKey,deleted=False).to_json()
            key = "project key"
        response = list(loads(response))
        if len(response)==0:
            return ({'status':"error",'message': key+" is invalid or does not exists"})
        else:
            return ({'status':"success",'data':response})
    else:
        return ({'status':'error','message':'catalog key is required'})
    
def project_name_exists(**kwargs):
    try:
        if 'name' in kwargs and 'catalog_key' in kwargs and kwargs['name'] is not None and kwargs['catalog_key'] is not None:
            project_name_like = re.compile('.*'+str(kwargs['name'])+'.*')
            response = ProjectSchema.objects(name=project_name_like,catalog_key=kwargs['catalog_key'],deleted=False).to_json()
            response = list(loads(response))
            return ({'status':"success",'data':response})
        else:
            return ({'status':'error','message':'Missing required parameters'})
    except Exception as e:
            return ({'status':'error','message':str(e)})

# JSON Response
def project_response(project):
    print("--- Inside project_response -----")
    if(project.id!=None):
        #'projectId' : str(project.id),
        response = {
            'projectKey': project.key,
            'name' : project.name,
            'tags' : project.tags if len(project.tags)>0 else [],
            'description' : project.description if project.description!="" else "",
            'deleted' : project.deleted,
            'updatedAt' : str(project.updated_at)
        }

        return ({'status':'success','data':response})
    else:
        return ({'status':'error','message':'Some error occur while creating catalog'})

# Creating Dataset Folder Structure
def create_dataset_folder(catalog_key=None,project_key=None):
    if catalog_key is not None and project_key is not None:
        base_path = environ.get('STORAGE',None)
        # Making catalog folder to store respective projects inside that
        catalog_dir = path.join(base_path,catalog_key)
        if not path.exists(catalog_dir):
            makedirs(catalog_dir) 

        # Making project folder to store respective dataset inside that
        project_dir = path.join(catalog_dir,project_key,'datasets','temp')
        if not path.exists(project_dir):
            makedirs(project_dir)
        
        # Making project folder to store respective nifi data inside that
        nifi_dir = path.join(catalog_dir,project_key,'datasets','nifi')
        if not path.exists(nifi_dir):
            makedirs(nifi_dir)
        
        return ({'status':'success','project_path':project_dir})
    else:
        return ({'status':'error','message':'catalog/project key is required'})
