
import re, copy
import numpy as np
import pandas as pd
from json import dumps, loads
from datetime import datetime
from multiprocessing import cpu_count, Pool, Queue, Process
nCores = cpu_count()

__gender__ = ["male", "female", 'm', 'f']
__bool__ = ["true", "false","True",'False','TRUE','FALSE',True,False,'0','1',0,1]
__type__ = ["gender", "phone", "email", "url"]
url = "^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$"
email = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
phone = "^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$"

# Date Format
date_pattern1 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](0[1-9]|[1-9]|1[012])[/.-](\d{2,4})$"
date_pattern2 = '(\d{2,4})[/.-](0[1-9]|[1-9]|1[012])[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])$'
date_pattern3 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](\d{2,4})$"
date_pattern4 = "(\d{2,4})[/.-](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])$"
date_pattern5 = "(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](\d{2,4})$"
date_pattern6 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](\d{2,4})$"
date_pattern7 = "(\d{2,4})[/.-](January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])$"
date_pattern8 = "(January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](\d{2,4})$"

# Date Time in 24 hour format
date_time_24_format_pattern1 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](0[1-9]|[1-9]|1[012])[/.-](\d{2,4}) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"
date_time_24_format_pattern2 = '(\d{2,4})[/.-](0[1-9]|[1-9]|1[012])[/.-](0[1-9]|[1-9]|[12][0-9]|3[01]) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$'
date_time_24_format_pattern3 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](\d{2,4}) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"
date_time_24_format_pattern4 = "(\d{2,4})[/.-](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01]) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"
date_time_24_format_pattern5 = "(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](\d{2,4}) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"
date_time_24_format_pattern6 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](\d{2,4}) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"
date_time_24_format_pattern7 = "(\d{2,4})[/.-](January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01]) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"
date_time_24_format_pattern8 = "(January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](\d{2,4}) ([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$"

# Date Time in 12 hour format
date_time_12_format_pattern1 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](0[1-9]|[1-9]|1[012])[/.-](\d{2,4}) ([0-1]?[0-2]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"
date_time_12_format_pattern2 = '(\d{2,4})[/.-](0[1-9]|[1-9]|1[012])[/.-](0[1-9]|[1-9]|[12][0-9]|3[01]) ([0-1]?[0-2]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$'
date_time_12_format_pattern3 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](\d{2,4}) ([0-1]?[0-9]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"
date_time_12_format_pattern4 = "(\d{2,4})[/.-](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01]) ([0-1]?[0-9]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"
date_time_12_format_pattern5 = "(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](\d{2,4}) ([0-1]?[0-9]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"
date_time_12_format_pattern6 = "(0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](\d{2,4}) ([0-1]?[0-9]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"
date_time_12_format_pattern7 = "(\d{2,4})[/.-](January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01]) ([0-1]?[0-9]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"
date_time_12_format_pattern8 = "(January|February|March|April|May|June|July|August|September|October|November|December|january|february|march|april|may|june|july|august|september|october|november|december|JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER)[/.-](0[1-9]|[1-9]|[12][0-9]|3[01])[/.-](\d{2,4}) ([0-1]?[0-9]):[0-5][0-9](:[0-5][0-9])?(\s*[ap|AP][m|M])?$"

# Time Format
time_12_hour_pattern1 = "([0-1]?[0-9]):[0-5][0-9]:[0-5][0-9](\s*[ap|AP][m|M]?)" #'([0-9]{2}:[0-9]{2}:[0-9]{2})'
time_12_hour_pattern2 = "([0-1]?[0-9]):[0-5][0-9](\s*[ap|AP][m|M]?)"
time_24_hour_pattern = "([0-1]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]"

def typeof(value, native):
    if value is np.nan or value != value or value in [None,'none'] or value == '':
        return 'empty'
    elif type(value) == bool or str(value).lower() in __bool__:
        return 'boolean'
    elif type(value) == int or bool(re.match('^(\+|-)?[0-9]*$', str(value))):
        return 'integer'
    elif (type(value) == float and value == value) or bool(re.match("^(\+|-)?\d+?\.\d+?$", str(value))):
        return 'decimal'
    elif native == False and str(value).lower() in __gender__:
        return 'gender'
#     elif re.match(url, str(value)) != None:
#         return 'url'
#     elif re.search(phone, str(value)) != None:
#         return 'phone'
    elif native == False and re.match(email, str(value)) != None:
        return 'email'
    elif native == False and (re.search(time_12_hour_pattern1, str(value)) != None or re.search(time_12_hour_pattern2, str(value)) != None or re.search(time_24_hour_pattern, str(value)) != None):
        return 'timestamp'
    elif native == False and (re.match(date_pattern1, str(value)) != None or re.match(date_pattern2, str(value)) != None or re.match(date_pattern3, str(value)) != None or re.match(date_pattern4, str(value)) != None or re.match(date_pattern5, str(value)) != None or re.match(date_pattern6, str(value)) != None or re.match(date_pattern7, str(value)) != None or re.match(date_pattern8, str(value)) != None or re.match(date_time_24_format_pattern1, str(value)) != None or re.match(date_time_24_format_pattern2, str(value)) != None or re.match(date_time_24_format_pattern3, str(value)) != None or re.match(date_time_24_format_pattern4, str(value)) != None or re.match(date_time_24_format_pattern5, str(value)) != None or re.match(date_time_24_format_pattern6, str(value)) != None or re.match(date_time_24_format_pattern7, str(value)) != None or re.match(date_time_24_format_pattern8, str(value)) != None or re.match(date_time_12_format_pattern1, str(value)) != None or re.match(date_time_12_format_pattern2, str(value)) != None or re.match(date_time_12_format_pattern3, str(value)) != None or re.match(date_time_12_format_pattern4, str(value)) != None or re.match(date_time_12_format_pattern5, str(value)) != None or re.match(date_time_12_format_pattern6, str(value)) != None or re.match(date_time_12_format_pattern7, str(value)) != None or re.match(date_time_12_format_pattern8, str(value)) != None):
        return 'date'
    elif native == False and type(value) == str:
        return 'string'
    else:
        return 'string'

def data_type(datatypes):
    __type__ = ["gender", "phone", "email", "url", "string"]
    data_types = []
    
    for cols in datatypes.columns:
        data_type = {}
        data_type['field'] = cols
        data_type['predicted_type'] = datatypes[cols].value_counts().idxmax()
        if data_type['predicted_type'] == 'empty':
            try:
                data_type['predicted_type'] = datatypes[cols].value_counts().keys()[1]
            except:
                data_type['predicted_type'] = 'string'
        #if data_type['predicted_type'] == 'boolean' and datatypes[cols].nunique() != 1 and datatypes[cols].value_counts().keys()[1] != 'empty':
        #    data_type['predicted_type'] = datatypes[cols].value_counts().keys()[1]

        if data_type['predicted_type'] in __type__:
            data_type['original_type'] = 'string'
        else:
            data_type['original_type'] = data_type['predicted_type']
        data_type['type'] = data_type['original_type']

        if data_type['original_type'] == 'string':
            data_type['identified'] = "categorical"
        else:
            data_type['identified'] = "non-categorical"
        data_type['empty'] = round((datatypes[cols][datatypes[cols] == 'empty'].shape[0] / datatypes[cols].shape[0]) * 100, 2)
        if datatypes[cols].value_counts().idxmax() != 'empty':
            data_type['ok'] = round((datatypes[cols][datatypes[cols] == datatypes[cols].value_counts().idxmax()].shape[0] / datatypes[cols].shape[0]) * 100, 2)
        elif int(data_type['empty']) == 50:
            data_type['ok'] = round((datatypes[cols][datatypes[cols] == datatypes[cols].value_counts().keys()[1]].shape[0] / datatypes[cols].shape[0]) * 100, 2)
        else:
            data_type['ok'] = 0.0
        
        if data_type['ok'] == 0.0:
            temp = datatypes[cols].value_counts().keys().tolist()
            if len(temp)>=2:
                if temp[0] in ['empty']:
                    data_type['ok'] = round((datatypes[cols][datatypes[cols] == datatypes[cols].value_counts().keys()[1]].shape[0] / datatypes[cols].shape[0]) * 100, 2)
        
        data_type['not_ok'] = round(100 - abs((data_type['empty'] + data_type['ok'])), 2)
        data_type['id'] = ''
        if data_type['original_type'] in ['integer','decimal','date']:
            data_type['min_value'] = ""
            data_type['max_value'] = ""
        data_types.append(data_type)
    return data_types

def ok_notok(datatypes):
    ok_notok = {}
    for cols in datatypes.columns:
        empty = datatypes[cols].index[datatypes[cols] == 'empty'].tolist()
        ok    = datatypes[cols].index[(datatypes[cols] != 'empty') & (datatypes[cols] == datatypes[cols].value_counts().keys()[0])].tolist()
        if len(ok)==0:
            temp = datatypes[cols].value_counts().keys().tolist()
            if len(temp)>=2:
                if temp[0] in ['empty']:
                    ok = datatypes[cols].index[(datatypes[cols] != 'empty') & (datatypes[cols] == datatypes[cols].value_counts().keys()[1])].tolist()
                    notok = []
            else:
                notok = datatypes[cols].index[(datatypes[cols] != 'empty') & (datatypes[cols] != datatypes[cols].value_counts().keys()[0])].tolist()
        else:
            notok = datatypes[cols].index[(datatypes[cols] != 'empty') & (datatypes[cols] != datatypes[cols].value_counts().keys()[0])].tolist()
        ok_notok = {'empty': empty, 'not_ok': notok,'ok':ok}
    return ok_notok

def specific_col_into_freq_func(df, colname, top=0,sort_by_value=False,data_types=None):
    data_frame = df
    return_json = {}
    freq_df = data_frame[colname].value_counts().reset_index().rename(columns={'index': colname, colname: 'frequencies'})
    freq_dataframe = freq_df
    data_type = None
    minimum = 0
    maximum = 0
    if data_types['field']==colname:
        data_type = data_types['type']
        keys = data_types.keys()
        if 'min_value' in keys and 'max_value' in keys:
            minimum = data_types['min_value']
            maximum = data_types['max_value']
    if freq_df.shape[0]>10:
        try:
            if ((data_type is not None) and (data_type in ['decimal'])):
                number_bins = np.linspace(float(minimum),float(maximum),10,dtype=float)
            else:
                number_bins = np.linspace(minimum,maximum,10,dtype=int)
            
            df[colname].replace(['',' '], np.nan, inplace=True)
            df = df[df[colname].notnull()]
            if ((data_type is not None) and (data_type in ['decimal'])):
                df[colname] = df[colname].apply(lambda x: float(x))

            freq_df= pd.cut(df[colname], number_bins).value_counts().reset_index().rename(columns={'index': colname, colname: 'frequencies'})
        except:
            pass
    try:
        if not sort_by_value:
            freq_df = freq_df.sort_values(by=[colname])
        else:
            pass
    except:
        pass
    if top == 0:
        return_json[colname] = {"label": freq_df[colname].tolist(), "value": freq_df['frequencies'].tolist()}
    else:
        freq_df.head(top) 
        return_json[colname] = {"label": freq_df[colname].tolist(), "value": freq_df['frequencies'].tolist()}

    return_json = dumps(return_json, default=str)
    return_json = loads(return_json)

    # transforming labels to tuple
    if freq_dataframe.shape[0]>10 and data_type is not None and data_type in ['decimal','integer']:
        return_json[colname]["label"] = transform_histogram_labels(return_json[colname]["label"])

    return return_json

def transform_histogram_labels(labels):
    result = map(lambda val: val.replace("(","[",1), labels)
    result = list(result)
    temp = []
    for item in result:
        try:
            temp.append(eval(item))
        except Exception as e:
            pass
    return temp

# For Integer and Decimal
def calculate_min_max_value(df, column_name, data_types):
    column_index = df.columns.get_loc(column_name)
    if data_types['original_type'] in ['integer','decimal']:
        df[column_name] = pd.to_numeric(df[column_name], errors='coerce')         
        if data_types['original_type'] in ['integer']:
            data_types['min_value'] = int(df[column_name].min()) or 0
            data_types['max_value'] = int(df[column_name].max()) or 0
        else:
            data_types['min_value'] = float(df[column_name].min()) or 0.0
            data_types['max_value'] = float(df[column_name].max()) or 0.0
    elif data_types['original_type'] in ['date']:
        if data_types['ok'] == 100.0:
            data_frame = copy.deepcopy(df)
            data_frame[column_name] = pd.to_datetime(data_frame[column_name])
            data_frame.sort_values(by=[column_name], inplace=True, ascending=False)
            data_frame.reset_index(drop=True,inplace=True)
            data_types['max_value'] = datetime.strftime(data_frame[column_name][0],"%Y-%m-%d")
            data_types['min_value'] = datetime.strftime(data_frame[column_name][data_frame.shape[0]-1],"%Y-%m-%d")
    return data_types


def d_type(df, cols, object, datatypes, native=False):
    datatypes[cols] = df[cols].apply(typeof, native=native).values
    output = data_type(datatypes)
    return output

def trim_spaces(**kwargs):
    df = kwargs['data_frame']
    df_obj = df.select_dtypes(include=kwargs['include'])
    df[df_obj.columns] = df_obj.apply(lambda x: x.str.strip())
    return df

def predict_types_new(data, _id, cols, top=0, sort_by_value=False):
    datatypes = pd.DataFrame()
    # Triming the begining and ending space from the data frame 
    #response = trim_spaces(data_frame=data, include=['object'])
    #data = response
    object = {
        "column": cols,
        "datatypes": "",
        "histogram": "",
        "ok_notok": "",
    }
    if data[cols].dtype == 'float64' or data[cols].dtype == 'int64':
        object["datatypes"] = d_type(data, cols, object, datatypes, True)[0]
    else:
        object["datatypes"] = d_type(data, cols, object, datatypes)[0]
    object['datatypes'] = calculate_min_max_value(data, cols, object['datatypes'])
    tempDict = specific_col_into_freq_func(data, cols, top,sort_by_value, object['datatypes'])
    object["histogram"] = tempDict[cols]
    if data[cols].is_unique:
        _id[cols] = 'id'
    else:
        _id[cols] = "not_id"
    object["datatypes"]["id"] = _id[cols]
    object["id"] = _id[cols]
    object["ok_notok"] = ok_notok(datatypes)
    return object




