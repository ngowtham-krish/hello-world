import time, re
import pandas as pd
import sqlalchemy as sa
from bson import ObjectId
from json import dumps,loads
#import mysql.connector as mysql_connect
from pyarrow import csv, parquet, Table
import strait.core.helper.metadata as meta_data
from os import path, getcwd, makedirs, environ, rename, remove
import strait.core.helper.transformation_helper as transformation_helper
from strait.core.model.schema import CatalogSchema, DatasetSchema, FileSchema, ColumnInfoSchema, TransformationSchema
import strait.core.tasks as tasks

# Checking user given file extension
def allow_extensions(**kwargs):
    if 'source' in kwargs and kwargs['source'] is not None:
        source = kwargs['source']
    else:
        source = 'upload'
    allowExtension = environ.get('ALLOWED_EXTENSIONS',None)
    if source=='file_path':
        file_path        = path.abspath(kwargs['file_name'])
        temp_file_path   = file_path.split('\\')
        temp_file_name   = temp_file_path[-1].split('.')
        return '.' in temp_file_path[-1] and temp_file_name[1] in allowExtension
    else:
        if 'request_from' in kwargs and kwargs['request_from'] is not None:
            if kwargs['request_from'] in ['update']:
                allowExtension = ['csv']
            else:
                allowExtension = allowExtension.split(',')
        else:
            allowExtension = allowExtension.split(',')
        tempFile = kwargs['file_name'].split('.')
        return '.' in kwargs['file_name'] and tempFile[1] in allowExtension

# Checking whether given ObjectId is valid or not
def validate_object_id(id,module_name):
    if not ObjectId.is_valid(id):
        return ({'status':"error",'message': module_name+" is invalid"})
    else:
        return ({'status':"success"})

#validating catalogId & projectId association and exists or not
def validate_catalog_project_id(catalogId,projectId):
    # Checking catalogId and projectId association exists or not 
    response = CatalogSchema.objects.filter(id=catalogId,deleted=False,projects={'$elemMatch': {'id': projectId,'deleted':False}}).to_json()
    response = list(loads(response))
    if len(response)==0:
        return ({'status':"error",'message':"catalogId or projectId is invalid"})
    else:
        return ({'status':"success"})

#validating dataset exists or not and association with catalogId and projectId
def validate_dataset(catalogKey=None,projectKey=None,datasetKey=None,datasetName=None,datasetId=None):
    if catalogKey!=None and projectKey!=None:
        # Checking dataset by datasetId
        if datasetId!=None:
            response = DatasetSchema.objects(catalog_key=catalogKey,project_key=projectKey,id=datasetId,deleted=False).to_json()
            key = "dataset id"
        elif datasetKey!=None:
            response = DatasetSchema.objects(catalog_key=catalogKey,project_key=projectKey,key=datasetKey,deleted=False).to_json()
            key = "dataset key"
        elif datasetName!=None:
            response = DatasetSchema.objects(catalog_key=catalogKey,project_key=projectKey,name=datasetName,deleted=False).to_json()
            key = "dataset name"
        response = list(loads(response))
        if len(response)==0:
            return ({'status':"error",'message': key+" is invalid or does not exists"})
        else:
            return ({'status':"success"})
    else:
        return ({'status':"error",'message':"catalogKey or projectKey association is invalid"})

# Checking whether dataset name/key already exists or not
def dataset_name_exists(**kwargs):
    if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None:
        if 'dataset_name' in kwargs and kwargs['dataset_name'] is not None:
            dataset_name_like = re.compile('.*'+str(kwargs['dataset_name'])+'.*')
            #dataset_name = kwargs['dataset_name'].strip()
            response = DatasetSchema.objects(catalog_key=kwargs['catalog_key'],project_key=kwargs['project_key'],name=dataset_name_like,deleted=False).to_json()
            response = list(loads(response))
            '''
            if 'request_from' in kwargs and kwargs['request_from'] is not None:
                if kwargs['request_from'] in ['create']:
                    if len(response) > 0 :
                        return ({"status":"error","message":"Dataset name already exists"})
                    else:
                        return ({'status':'success'})
                elif kwargs['request_from'] in ['update']:
                    if len(list(loads(response))) > 0:
                        for item in list(loads(response)):
                            if dataset_name == item['name'].strip() and item['key'] != kwargs['dataset_key']:
                                return ({'status': 'error', 'message': 'dataset name already exists'})
                    return ({'status':'success'})
            '''
            return ({'status':"success",'data':response})
        elif 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
            response = DatasetSchema.objects(catalog_key=kwargs['catalog_key'],project_key=kwargs['project_key'],key=kwargs['dataset_key'],deleted=False).to_json()
            response = list(loads(response))
            if len(response) > 0 :
                return ({"status":"error","message":"Dataset name already exists"})
            else:
                return ({'status':'success'})
    else:
        return ({'status':"error",'message':"catalogKey or projectKey association is invalid"})

# For Fetching dataset details depend on parameters
def get_dataset(**kwargs):
    if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None:
        if 'dataset_id' in kwargs and kwargs['dataset_id'] is not None:
            dataset_resp = DatasetSchema.objects(id=kwargs['dataset_id'],project_key=kwargs['project_key'],catalog_key=kwargs['catalog_key'],deleted=False)
            return ({'status':'success','dataset':dataset_resp[0]})
        elif 'dataset_name' in kwargs and kwargs['dataset_name'] is not None:
            dataset_resp = DatasetSchema.objects(name=kwargs['dataset_name'],project_key=kwargs['project_key'],catalog_key=kwargs['catalog_key'],deleted=False)
            return ({'status': 'success', 'dataset': dataset_resp[0]})
        elif 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
            dataset_resp = DatasetSchema.objects(key=kwargs['dataset_key'],project_key=kwargs['project_key'],catalog_key=kwargs['catalog_key'],deleted=False)
            return ({'status': 'success', 'dataset': dataset_resp[0]})
    else:
        return ({'status': 'error', 'message': "Missing required parameters"})

# JSON Response to UI
def dataset_response(**kwargs):
    if 'dataset' in kwargs and kwargs['dataset'] is not None:
        dataset = kwargs['dataset']
        row_count = None
        if dataset.id is not None:
            if 'file' in kwargs and kwargs['file'] is not None:
                file_obj = kwargs['file']
                if len(file_obj['metadata'])>0:
                    row_count = file_obj['metadata']['row_count'] 
            response = {
                'projectKey' : dataset.project_key,
                'datasetKey' : dataset.key,
                'name' : dataset.name,
                'isBuild': dataset.is_build,
                'description' : dataset.description,
                'tags' : dataset.tags,
                'deleted' : dataset.deleted,
                'updatedAt' : str(dataset.updated_at)
            }
            # checking whether path is empty or not
            if dataset.path!="":
                response['path'] = dataset.path
            
            if row_count is not None:
                response['rowCount'] = row_count 
            return ({'status':'success','data':response})
    else:
        return ({'status':'error','message':'Some error occur while creating dataset'})

def df_column_uniquify(df):
    try:
        df_columns = df.columns
        new_columns = []
        for item in df_columns:
            counter = 0
            newitem = item
            temp = newitem.split('.')
            if temp[0] in new_columns:
                counter += 1
                newitem = "{}_{}".format(temp[0], counter)
                df = df.rename(columns= {item:newitem})
            new_columns.append(newitem)
        return ({'status':'success','data_frame':df})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

def store_whole_meta(arguments):
    try:
        a = tasks.metadata_task.delay(arguments)
        return ({"status": "success", "message": str(a)}) 
    except Exception as e:
        return ({"status": "failed", "message": str(e)})

def store_column_meta(arguments, col):
    try:
        a = tasks.column_level_task.delay(arguments, col)
        return ({"status": "success", "message": str(a)}) 
    except Exception as e:
        return ({"status": "failed", "message": str(e)})  

# Get File Schema Details
def get_file_details(**kwargs):
    if (('catalog_key' in kwargs and kwargs['catalog_key'] is not None) and ('project_key' in kwargs and kwargs['project_key'] is not None) and ('dataset_key' in kwargs and kwargs['dataset_key'] is not None)):
        file_data = FileSchema.objects(dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], deleted=False).to_json()
        file_data = loads(file_data)
        return ({'status':'success','data':file_data})
    elif 'file_id' in kwargs and kwargs['file_id'] is not None:
        file_data = FileSchema.objects(id=ObjectId(kwargs['file_id']), deleted=False).to_json()
        file_data = loads(file_data)
        return ({'status':'success','data':file_data})
    else:
        return ({'status':'error','message':"Required paramter is missing"})

# Pagination
def pagination(data_frame,page_no,sampling={},dataset_key=None,project_key=None,catalog_key=None):
    try:
        page_size = int(environ.get('DEFAULT_PAGE_SIZE',None))
        # Checking the page number is less then zero or not
        if page_no <= 0:
            start = 0
        else:
            start = (page_no-1)*page_size
        limit = (start + page_size)
        # Checking if start is greater then data frame then considering sampling 
        if start > data_frame.shape[0]:
            records = int(environ.get('DEFAULT_RECORD_COUNT',None))
            if len(sampling)==0:
                limit = records
                start = records - page_size
            else:
                if sampling['name'] == '':
                    limit = records
                    start = records - page_size
                else:
                    if sampling['name'] in ['first','last','random_records']:
                        if sampling['records']=='' or sampling['records'] is None:
                            limit = records
                            start = records - page_size
                        else:
                            limit = sampling['records']
                            start = limit - page_size
                    elif sampling['name'] in ['stratified_records','rebalance_records','column_value_subset']:
                        if sampling['records']=='' or sampling['records'] is None:
                            limit = records
                            start = records - page_size
                        else:
                            limit = sampling['records']
                            start = limit - page_size
                        
                        dataframe_rows = data_frame.shape[0]
                        if start > dataframe_rows:
                            limit = int(dataframe_rows)
                            start = limit - page_size
                    elif sampling['name'] in ['random_ratio','stratified_ratio','rebalance_ratio']:
                        ratio = int(environ.get('DEFAULT_SAMPING_RATIO',None))
                        if dataset_key is None and project_key is None:
                            return ({'status':'error','message':'Missing required parameters'})
                        else:
                            file_details = get_file_details(dataset_key=dataset_key,project_key=project_key,catalog_key=catalog_key)
                            if file_details['status'] in ['error']:
                                return file_details
                            file_details = file_details['data']
                            metadata = file_details[0]['metadata']
                            row_count = metadata['row_count']
                            if sampling['ratio']=='' or sampling['ratio'] is None:
                                total_record = (row_count*ratio)/100
                            else:
                                total_record = (row_count*sampling['ratio'])/100
                            limit = int(total_record)
                            start = limit - page_size
                            dataframe_rows = data_frame.shape[0]
                            if start > dataframe_rows:
                                limit = int(dataframe_rows)
                                start = limit - page_size
                    
            if start < 0 :
                start = 0
                
        data_frame = data_frame.iloc[start:limit,:]
        return ({'status':'success','data_frame':data_frame})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Uploading Temporary File
def upload_temp_file(catalog_key,project_key,request):
    try:
        base_path = environ.get('STORAGE',None)
        # Making catalog folder to store respective projects inside that
        catalog_dir = path.join(base_path,catalog_key)
        if not path.exists(catalog_dir):
            makedirs(catalog_dir) 

        # Making project folder to store respective dataset inside that
        project_dir = path.join(base_path,catalog_key,project_key,'datasets')
        if not path.exists(project_dir):
            makedirs(project_dir)
        
        # Making temp folder to store respective dataset inside that
        temp_dir = path.join(base_path,catalog_key,project_key,'datasets','temp')
        if not path.exists(temp_dir):
            makedirs(temp_dir)
        
        file            = request.files['file']
        fileName        = file.filename.split('.')
        timestamp       = int(round(time.time() * 1000))
        sourceFileName  = fileName[0] + "-"+ str(timestamp) + "." + fileName[1]
        file.save(path.join(temp_dir, sourceFileName))
        df = pd.read_csv(path.join(temp_dir, sourceFileName), encoding="utf-8")
        data_frame_to_csv = df.to_csv(index=False)
        targetFileName = fileName[0] + "-"+ str(timestamp) +".csv"
        target_file_path    = path.join(temp_dir, targetFileName)
        fh = open(target_file_path, "w")
        fh.write(data_frame_to_csv)
        fh.close()
        data = {
            'source_file' : sourceFileName,
            'target_file' : targetFileName
        }
        return ({'status':'success','data':data})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

# Previewing Temporary File
def preview_temp_file(catalog_key,project_key,request):
    try:
        base_path = environ.get('STORAGE',None)
        path_dir = path.join(base_path,catalog_key,project_key,'datasets','temp', request.form['fileName'])
        if not path.exists(path_dir):
            raise ValueError("file path is invalid or does not exists")
        pyarrow_table    = parquet.read_table(path_dir)
        data_frame       = pyarrow_table.to_pandas()
        supported_format = ['csv', 'json']
        if 'records' in request.form:
            if not request.form['records'].isnumeric():
                return ({"status":"error","message": "only integer value is allowed in records"})
            records = int(request.form['records'])
        else:
            records = 100
        if 'format' in request.form:
            if request.form['format'] != None and request.form['format'].lower() in supported_format:
                if request.form['format'] == 'json':  # JSON
                    return ({'status': "success", 'data': (data_frame.head(records)).to_json(orient='records')})
                elif request.form['format'] == 'csv':  # CSV
                    return ({'status': "success", 'data': (data_frame.head(records)).to_csv(index=False)})
            else:
                return ({'status': "success", 'data': (data_frame.head(records)).to_csv(index=False)})
        else:  # CSV
            return ({'status': "success", 'data': (data_frame.head(records)).to_csv(index=False)})
    except Exception as e:
        return ({'status':"error",'message':str(e)})

def column_info(**kwargs):
    if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None and 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
        if 'recipe_key' in kwargs and kwargs['recipe_key'] is not None:
            if 'column_name' in kwargs and kwargs['column_name'] is not None:
                column_info_data = ColumnInfoSchema.objects(column_name=kwargs['column_name'], recipe_key=kwargs['recipe_key'], dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], deleted=False).to_json()
                column_info_data = loads(column_info_data)
                if len(column_info_data)==0:
                    column_info_data = ColumnInfoSchema.objects(dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], column_name=kwargs['column_name'], deleted=False).to_json()
                    column_info_data = loads(column_info_data)
            else:
                column_info_data = ColumnInfoSchema.objects( recipe_key=kwargs['recipe_key'], dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], deleted=False).to_json()
                column_info_data = loads(column_info_data)
            # Fetching column info with recipe key is blank/empty that means there is no step then fetching with (catalog_key,project_key and dataset_key)
            if len(column_info_data)==0:
                column_info_data = ColumnInfoSchema.objects(dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], deleted=False).to_json()
                column_info_data = loads(column_info_data)
        else:
            if 'column_name' in kwargs and kwargs['column_name'] is not None:
                column_info_data = ColumnInfoSchema.objects(column_name=kwargs['column_name'],dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], deleted=False).to_json()
                column_info_data = loads(column_info_data)
            else:
                column_info_data = ColumnInfoSchema.objects(dataset_key=kwargs['dataset_key'], project_key= kwargs['project_key'], catalog_key= kwargs['catalog_key'], deleted=False).to_json()
                column_info_data = loads(column_info_data)
        
        column_info = []
        if len(column_info_data)>0:
            for item in column_info_data:
                temp = {
                    'column_name': item['column_name'],
                    'data_types': item['metadata']['datatypes'],
                    'oknotok':item['oknotok']
                }
                column_info.append(temp)
        return ({'status':'success','data':column_info})
    else:
        return ({"status":'error','message':'Missing required paramters'})

# Creating file path for create dataset
def create_file_path(**kwargs):
    storage_type = environ.get('STORAGE_TYPE',None)
    if storage_type in ['docker']:
        base_path = environ.get('STORAGE',None)
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None: 
            # Making catalog folder to store respective projects inside that
            catalog_dir = path.join(base_path,kwargs['catalog_key'])
            if not path.exists(catalog_dir):
                makedirs(catalog_dir) 

            # Making project folder to store respective dataset inside that
            project_dir = path.join(catalog_dir,kwargs['project_key'],'datasets')
            if not path.exists(project_dir):
                makedirs(project_dir)

            # Making dataset folder to store respective dataset inside that
            temp_dir = path.join(project_dir,'temp')
            if not path.exists(temp_dir):
                makedirs(temp_dir)
            
            # Making dataset folder to store respective dataset inside that
            nifi_dir = path.join(project_dir,'nifi')
            if not path.exists(nifi_dir):
                makedirs(nifi_dir)

            if 'return_type' in kwargs and kwargs['return_type'] is not None:
                if kwargs['return_type'] in ['temp','nifi']:
                    pass
                else:
                    if 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
                        # Making dataset folder to store respective dataset inside that
                        dataset_dir = path.join(project_dir,kwargs['dataset_key'])
                        if not path.exists(dataset_dir):
                            makedirs(dataset_dir)
                        
                        # Making history folder to store respective dataset recipe file inside that
                        history_dir = path.join(dataset_dir,'history')
                        if not path.exists(history_dir):
                            makedirs(history_dir)
                    else:
                        return ({'status':'error','message':'Missing required parameters'})
            else:
                if 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
                    # Making dataset folder to store respective dataset inside that
                    dataset_dir = path.join(project_dir,kwargs['dataset_key'])
                    if not path.exists(dataset_dir):
                        makedirs(dataset_dir)
                    
                    # Making history folder to store respective dataset recipe file inside that
                    history_dir = path.join(dataset_dir,'history')
                    if not path.exists(history_dir):
                        makedirs(history_dir)
                else:
                    return ({'status':'error','message':'Missing required parameters'})

            if 'return_type' in kwargs and kwargs['return_type'] is not None: # Retruning temp path
                if kwargs['return_type'] in ['temp']:
                    return ({'status':'success','file_path':temp_dir})
                elif kwargs['return_type'] in ['nifi']:
                    return ({'status':'success','file_path':nifi_dir})
                else:
                    return ({'status':'success','file_path':dataset_dir})
            else: # Retruning dataset path
                return ({'status':'success','file_path':dataset_dir})
        else:
            return ({'status':'error','message':'Missing required parameters'})

def check_connection(**kwargs):
    try:
        #print("--------- Inside check connection ------------")
        request = kwargs['request']
        #print(request.json['databaseType'])
        if 'databaseType' in request.json and request.json['databaseType'] is not None:
            if request.json['databaseType'] in ['mysql']:
                if (('userName' in request.json and request.json['userName'].strip()!='') and ('password' in request.json and request.json['password'].strip()!='') and ('databaseName' in request.json and request.json['databaseName'].strip()!='') and ('hostName' in request.json and request.json['hostName'].strip()!='')):
                    user_name = request.json['userName'].strip()
                    host_name = request.json['hostName'].strip()
                    password  = request.json['password'].strip()
                    port_no   = request.json['portNo']
                    database_name = request.json['databaseName'].strip()
                    #print("user name ",user_name," host name ",host_name," password ",password," database name ",database_name)
                    if 'driverName' in request.json and request.json['driverName'].strip()!='':
                        #print("-------- Inside driverName ",request.json['driverName'])
                        if request.json['driverName'].strip() in ['mysqldb']:
                            engine = sa.create_engine('mysql+mysqldb://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                        elif request.json['driverName'].strip() in ['pymysql']:
                            engine = sa.create_engine('mysql+pymysql://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                        else:
                            engine = sa.create_engine('mysql://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                    else:
                        #print("---------- Inside Else not driver name -------------")
                        engine = sa.create_engine('mysql://'+user_name+':'+password+'@'+host_name+':'+port_no+'/'+database_name)
                    engine.connect()
                    #print("--------- Before return statement ----------")
                    #print(engine)
                    return ({'status':'success','connection_engine':engine})
                else:
                    return ({'status':"error",'message':"Missing required parameters"})     
            elif request.json['databaseType'] in ['sqlite']:
                if 'database_path' in kwargs and kwargs['database_path'].strip()!='':
                    engine = sa.create_engine('sqlite:///'+kwargs['database_path'].strip())
                    engine.connect()
                    return ({'status':'success','connection_engine':engine})    
            elif request.json['databaseType'] in ['postgres']:
                if (('userName' in request.json and request.json['userName'].strip()!='') and ('password' in request.json and request.json['password'].strip()!='') and ('databaseName' in request.json and request.json['databaseName'].strip()!='') and ('hostName' in request.json and request.json['hostName'].strip()!='')):
                    user_name = request.json['userName'].strip()
                    host_name = request.json['hostName'].strip()
                    password  = request.json['password'].strip()
                    database_name = request.json['databaseName'].strip()
                    if 'driver_name' in kwargs and kwargs['driver_name'] is not None:
                        if kwargs['driver_name'] in ['psycopg2']:
                            engine = sa.create_engine('postgresql+psycopg2://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                        elif kwargs['driver_name'] in ['pg8000']:
                            engine = sa.create_engine('postgresql+pg8000://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                        else:
                            engine = sa.create_engine('postgresql://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                    else:
                        engine = sa.create_engine('postgresql://'+user_name+':'+password+'@'+host_name+'/'+database_name)
                    engine.connect()
                    return ({'status':'success','connection_engine':engine})
                else:
                    return ({'status':"error",'message':"Missing required parameters"})    
        else:
            return ({'status':"error",'message':"database type is required"})
    except Exception as e:
            return ({'status':'error','message':"Exception : "+ str(e)})

# For Applying Filters
def apply_filters(**kwargs):
    transformation_data = TransformationSchema.objects(key="filter_rows",transformation_type="predefined",deleted=False).to_json()
    transformation_data = list(loads(transformation_data))
    if len(transformation_data)==0:
        return ({'status':'error','message':'transformation id is invalid'})
    transformation_data = transformation_data[0]
    file_path = transformation_data['path']
    # Executing Code
    schema = {
        'data_frame':kwargs['data_frame'],
        'filters':kwargs['filters']
    }
    resp = transformation_helper.execute_code(file_path=file_path,function_name=transformation_data['function_name'],schema=schema,request_from="api")
    return resp

def ok_not_ok(**kwargs):
    print("----Inside ok_not_ok----")
    if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None and 'dataset_key' in kwargs and kwargs['dataset_key'] is not None and 'recipe_key' in kwargs and 'filter_for' in kwargs and kwargs['filter_for'] is not None and 'data_frame' in kwargs and kwargs['data_frame'] is not None: 
        column_info_data = column_info(recipe_key=kwargs['recipe_key'], dataset_key=kwargs['dataset_key'], project_key=kwargs['project_key'], catalog_key=kwargs['catalog_key'], column_name=kwargs['column_name'])
        if column_info_data['status'] in ['error']:
            return column_info_data
        if len(column_info_data['data'])>0:
            filter_for = kwargs['filter_for']
            print("filter_for "+str(filter_for))
            column_info_data = column_info_data['data'][0]
            ok_not_ok_path = column_info_data['oknotok']
            print("ok_not_ok_path "+str(ok_not_ok_path))
            f = open(ok_not_ok_path, "r")
            ok_not_ok_data = f.read()
            ok_not_ok_data = loads(ok_not_ok_data)
            index = None
            if filter_for in ['ok']:
                print("Inside if of ok")
                if len(ok_not_ok_data['ok'])>0:
                    index = ok_not_ok_data['ok']
            elif filter_for in ['not_ok']:
                print("Inside if of not_ok")
                if len(ok_not_ok_data['not_ok'])>0:
                    index = ok_not_ok_data['not_ok']
            elif filter_for in ['empty']:
                print("Inside if of empty")
                if len(ok_not_ok_data['empty'])>0:
                    index = ok_not_ok_data['empty']
            print("--- Index ----")
            print(index)
            data_frame = kwargs['data_frame']
            if index is not None:
                data_frame = data_frame.iloc[index] 
            else:
                row_count = data_frame.shape[0] + 1
                data_frame = data_frame.iloc[row_count:]
            print("data frame -----")
            print(data_frame.head(10))
            return ({'status':'success','data_frame':data_frame})
    else:
        return ({'status':'error','message':'Missing required parameters'})