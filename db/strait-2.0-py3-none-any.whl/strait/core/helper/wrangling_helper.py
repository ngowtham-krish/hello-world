import pandas as pd
import numpy as np
import time, copy, re
from json import loads
from datetime import datetime
from os import path,getcwd,environ,makedirs
import strait.core.dataset as dataset
import strait.core.recipes.history as history
import strait.core.helper.recipe_helper as recipe_helper
import strait.core.helper.dataset_helper as dataset_helper
import strait.core.helper.transformation_helper as transformation_helper
from strait.core.model.schema import HistorySchema, FileSchema, RecipeSchema, TransformationSchema

def get_dataframe(request,**kwargs):
    try:
        catalog_key = request.headers.get('catalogKey')
        project_key = request.headers.get("projectKey")
        dataset_key = request.headers.get("datasetKey")
        # For analysis API the recipe key will be None
        recipe_key  = None
        if 'recipeKey' in request.headers:
            recipe_key = request.headers.get("recipeKey")
        
        if recipe_key is None:
            # validating catalogKey, projectKey, datasetKey association exists or not
            resp = dataset_helper.validate_dataset(catalog_key, project_key,dataset_key)
            if resp['status'] == 'error':
                return resp
        else:
            # validating catalogKey, projectKey, datasetKey & recipeKey association exists or not
            resp = recipe_helper.validate_recipe(catalog_key, project_key,dataset_key,recipe_key)
            if resp['status'] == 'error':
                return resp
        
        if recipe_key is not None:
            # Fetching Operation Details from Recipe Schema
            recipe_data = RecipeSchema.objects(catalog_key=catalog_key,project_key=project_key, source_key=dataset_key, key=recipe_key, deleted=False).to_json()
            recipe_data = loads(recipe_data)
            sampling    = recipe_data[0]['operation']['sampling'] 
            filters     = recipe_data[0]['operation']['filters']
            sorting     = recipe_data[0]['operation']['sorting']
            hide_column = recipe_data[0]['operation']['hide_column']
            if 'date_format' in recipe_data[0]['operation']:
                specified_date_format = recipe_data[0]['operation']['date_format']
            else:
                specified_date_format = []

            # Checking whether any transformation already exists or not
            history_details = HistorySchema.objects(recipe_key=recipe_key, source_key=dataset_key, project_key=project_key, catalog_key=catalog_key, deleted= False).to_json()
            history_details = list(loads(history_details)) 
            if len(history_details)>0: # If history has the records taking the data frame from the latest active steps
                # Fetching the sampling of active index from history list
                resp = checking_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling,history_details)
                if resp['status']=='error':
                    return resp
                data_frame = resp['data_frame']
            else: # If history schema is empty
                # Fetching Data Frame
                dataset_obj = dataset.Dataset(catalog_key,project_key,dataset_key)
                data_frame  = dataset_obj.get_dataframe(sampling_name=sampling['name'],request_from='api',sampling=sampling)
                if data_frame['status']=='error':
                    return data_frame
                else:
                    data_frame = data_frame['dataFrame']
        else: # If recipe key is None
            # Fetching Operation Details from File Schema
            file_data   = FileSchema.objects(catalog_key=catalog_key, project_key=project_key, dataset_key=dataset_key, deleted=False).to_json()
            file_data   = loads(file_data)
            sampling    = file_data[0]['operation']['sampling'] 
            filters     = file_data[0]['operation']['filters']
            sorting     = file_data[0]['operation']['sorting']
            hide_column = file_data[0]['operation']['hide_column']
            if 'date_format' in file_data[0]['operation']:
                specified_date_format = file_data[0]['operation']['date_format']
            else:
                specified_date_format = []

            # Fetching Data Frame
            dataset_obj = dataset.Dataset(catalog_key,project_key,dataset_key)
            data_frame  = dataset_obj.get_dataframe(sampling_name=sampling['name'],request_from='api',sampling=sampling)
            if data_frame['status']=='error':
                return data_frame
            else:
                data_frame = data_frame['dataFrame']

        # Applying Filter Logic if exists (Have to think how to implement filters)
        if len(filters)>0:
            response = dataset_helper.apply_filters(data_frame=data_frame, filters=filters)
            if response['status'] == 'error':
                return response
            data_frame = response['data_frame']
        
        # Applying Sorting Logic if exists
        if len(sorting)>0:
            column_names = []
            order_by = []
            for item in sorting:
                if item['column_name'] not in list(data_frame.columns):
                    return ({'status':'error','message':'column name is invalid'})
                else:
                    column_names.append(item['column_name'])
                    if item['order_by'].lower() == 'desc': # In Descending Order
                        order_by.append(False)
                    else: # In Ascending Order
                        order_by.append(True)
            
            if len(column_names) == len(order_by): # Both should be equal
                data_frame = copy.deepcopy(data_frame)
                data_frame.sort_values(by=column_names, ascending=order_by, inplace=True)

        # Applying Hide column logic if exists
        if len(hide_column)>0:
            column_names = data_frame.columns.values[hide_column]
            data_frame.drop(column_names, axis = 1, inplace = True)

        # Passing Data Frame to Prepare 
        data = {
            'data_frame' : data_frame,
            'sampling': sampling
        }

        is_filter = False
        # Checking whether transformation is filters or not
        if 'transformation_details' in kwargs and kwargs['transformation_details'] is not None:
            transformation_details = kwargs['transformation_details']
            if transformation_details['key'] in ['filter_rows']:
                is_filter = True
        
        if is_filter in [True]:
            pass
        else:
            # Preparing Schema
            schema = {}
            if 'schema' in request.form:
                schema_req = eval(request.form['schema'])
                for i in schema_req:
                    schema[i["name"]] = i["value"]
            
            if 'transformation_details' in kwargs and kwargs['transformation_details'] is not None:
                transformation_details = kwargs['transformation_details']
                if transformation_details['transformation_level'] in ['column']:
                    # Checking whether request column name is valid or not
                    if 'columnName' in request.form and request.form['columnName'] is not None:
                        if 'transformation_details' in kwargs and kwargs['transformation_details'] is not None:
                            transformation_details = kwargs['transformation_details']
                            if transformation_details['key']=='math_operation':
                                # Checking whether multi column name is valid or not
                                if request.form['operation'] in ['addition','difference']:
                                    column_names = request.form['columnName'].split(',')
                                    for item in column_names:
                                        if item not in list(data_frame.columns):
                                            return ({"status":"error","message":"Column name is invalid"})
                                else: # Checking for rest of the column
                                    if request.form['columnName'] not in list(data_frame.columns):
                                        return ({"status":"error","message":"Column name is invalid"})
                            elif transformation_details['key']=='date_range': # Checking whether multi column name is valid or not
                                column_names = request.form['columnName'].split(',')
                                for item in column_names:
                                    if item not in list(data_frame.columns):
                                        return ({"status":"error","message":"column name is invalid"})
                            else:
                                if request.form['columnName'] not in list(data_frame.columns):
                                    return ({"status":"error","message":"Column name is invalid"})
                        else:
                            if request.form['columnName'] not in list(data_frame.columns):
                                return ({"status":"error","message":"column name is invalid"})

        if 'transformation_details' in kwargs and kwargs['transformation_details'] is not None:
            transformation_details = kwargs['transformation_details']
            if transformation_details['key'] in ['date_range']:
                file_data = dataset_helper.column_info(dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key,recipe_key=recipe_key)
                if column_info_data['status']=='error':
                    return column_info_data
                column_info_data = column_info_data['data']
                column_names = request.form['columnName'].split(',')
                for item in column_info_data:
                    for column_name in column_names:
                        if item['column_name']==column_name:
                            if item['data_types']['type'] not in ['date','timestamp']:
                                return ({"status":"error","message":"column should have date as data type"})
                            elif item['data_types']['type'] in ['date','timestamp']:
                                if item['data_types']['ok']!=100.0:
                                    return ({"status":"error","message":"column should have numerical data only"})
    
            if transformation_details['key'] in ['to_date','to_datetime']:
                column_info_data = dataset_helper.column_info(dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key, recipe_key=recipe_key, column_name=request.form['columnName'])
                if column_info_data['status']=='error':
                    return column_info_data
                if len(column_info_data['data'])>0:
                    column_info_data = column_info_data['data'][0]
                    data_types = column_info_data['data_types']
                    if data_types['type'] not in ['date']:
                        return ({"status": "error", "message": "column cannot be converted to date"})
                    elif data_types['type'] in ['date']:
                        if data_types['ok'] != 100.0:
                            return ({"status": "error", "message": "encountered with empty cells"})
                    
                    if transformation_details['key'] in ['to_date']:
                        if 'date_format' not in schema:
                            return ({'status':"error",'message':"Format is required"})
                        if schema['date_format'] not in ["dd*mm*yyyy", "dd*shortMon*yyyy", "dd*month*yyyy", "dd*mm*yy", "dd*shortMon*yy", "dd*month*yy", "mm*dd*yyyy", "shortMon*dd*yyyy", "month*dd*yyyy", "mm*dd*yy", "shortMon*dd*yy", "month*dd*yy", "yyyy*mm*dd", "yyyy*shortMon*dd", "yyyy*month*dd", "yy*mm*dd", "yy*shortMon*dd", "yy*month*dd", "yyyy", "yy", "mm*yyyy", "shortMon*yyyy", "month*yyyy", "mm*yy", "shortMon*yy", "month*yy", "mm*dd", "shortMon*dd", "month*dd", "dd*mm", "dd*shortMon", "dd*month"]:
                            return ({'status':"error",'message':"Format is invalid"})
                        if len(specified_date_format)==0:
                            return ({'status':'error','message':'Date format is required'})
                        else:
                            try:
                                pd.to_datetime(data_frame[request.form['columnName']],format=specified_date_format[0]['format'])
                                support_format_hypen = specified_date_format[0]['format'].split("-")
                                if len(support_format_hypen)>1:
                                    support_format = "-"
                                support_format_hypen = specified_date_format[0]['format'].split("/")
                                if len(support_format_hypen)>1:
                                    support_format = "/"
                                support_format_hypen = specified_date_format[0]['format'].split(".")
                                if len(support_format_hypen)>1:
                                    support_format = "."
                                schema['format'] = support_format
                            except:
                                return ({'status':'error','message': str(request.form['columnName'])+" column does not support date format"})
                    '''
                    elif transformation_details['key'] in ['to_datetime']:
                        if len(specified_date_format)==0:
                            return ({'status':'error','message':'Date format is required'})
                        else:
                            try:
                                pd.to_datetime(data_frame[request.form['columnName']],format=specified_date_format[0]['format'])
                            except:
                                return ({'status':'error','message': str(request.form['columnName'])+" column does not support date format"})
                    '''
                else:
                    return ({'status':'error','message':'column name is invalid'})
        
            if transformation_details['key'] in ['remove_rows']:
                if 'operator' not in schema or schema['operator'] is None:
                    return ({'status':'error','message':"Operator is required"})

                if 'operator' in schema and schema['operator'] not in ['greater_then_equal','greater_then','less_then','less_then_equal','equal','not_equal','starts_with','ends_with','contains','in_between','remove_empty_rows']:
                    return ({'status':'error','message':"Operator is invalid"})

                if schema['operator'] in ['greater_then_equal','greater_then','less_then','less_then_equal','equal','not_equal','starts_with','ends_with','contains']:
                    if 'value' not in schema or schema['value'] is None:
                        return ({'status':'error','message':"Value is required"})
                    else:
                        if type(schema['value']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(schema['value']))):
                                schema['value'] = int(schema['value'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['value']))):
                                schema['value'] = float(schema['value'])     
                    
                    filter_data = [{
                        'column_name': request.form['columnName'],
                        'operator': schema['operator'],
                        'value':schema['value']
                    }]
                elif schema['operator'] in ['in_between']:   
                    if 'start' not in schema or schema['start'] is None:
                        return ({'status':'error','message':"Start value is required"})
                    else:
                        if type(schema['start']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(schema['start']))):
                                schema['start'] = int(schema['start'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['start']))):
                                schema['start'] = float(schema['start'])
                    
                    if 'end' not in schema or schema['end'] is None:
                        return ({'status':'error','message':"End value is required"})
                    else:
                        if type(schema['end']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(schema['end']))):
                                schema['end'] = int(schema['end'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['end']))):
                                schema['end'] = float(schema['end'])
                      
                    if 'start' in schema and schema['start'] is not None:
                        start = schema['start']
                    if 'end' in schema and schema['end'] is not None:
                        end = schema['end']
                    filter_data = [{
                        'column_name': request.form['columnName'],
                        'operator': schema['operator'],
                        'start':start,
                        'end':end
                    }]
                elif schema['operator'] in ['remove_empty_rows']:
                    filter_data = [{
                        'column_name': request.form['columnName'],
                        'operator': schema['operator']
                    }]
                response = validate_filter_data(filters=filter_data, data_frame=data_frame, recipe_key=recipe_key, dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key)
                if response['status'] == 'error':
                    return response
            
            if transformation_details['key'] in ['mass_edit']:
                response = validate_cluster_data(request,data_frame)
                if response['status']=='error':
                    return response

            if transformation_details['key'] in ['fill_empty_cells']:
                if 'operation_type' not in schema or schema['operation_type'] is None:
                    return ({'status':'error','message':'operation type is required'})

                if 'operation_type' in schema and schema['operation_type'] not in ['mean','median','mode','replace']:
                    return  ({'status':'error','message':'operation type is invalid'})
                
                if schema['operation_type'] in ['replace']:
                    if 'fill_with' not in schema or schema['fill_with'] is None:
                        return ({'status':'error','message':'fill with is required'})

                column_info_data = dataset_helper.column_info(dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key,recipe_key=recipe_key,column_name=request.form['columnName'])
                if column_info_data['status']=='error':
                    return column_info_data
                
                if len(column_info_data['data'])>0:
                    column_info_data = column_info_data['data'][0]
                    data_types = column_info_data['data_types']
                    if 'operation_type' in schema and schema['operation_type'] is not None:
                        if schema['operation_type'] in ['mean','median']:
                            if data_types['type'] not in ['integer','decimal']:
                                return ({"status": "error", "message": "column fields should have numeric datatype only"})
                            #if int(data_types['not_ok']) != 0:
                            #    return ({"status":"error","message":"some values are not in proper datatype"})

                        if schema['operation_type'] in ['mean', 'median','mode']:
                            if data_types['empty']==100.0:
                                return ({"status": "error", "message": "column fields cannot have all empty values"})
                            if int(data_types['not_ok']) != 0:
                                return ({"status": "error", "message": "some values are not in proper datatype"})
                else:
                    return ({'status':'error','message':'column name is invalid'})

            if transformation_details['key'] in ['lowercase','titlecase','uppercase']:
                column_info_data = dataset_helper.column_info(dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key,recipe_key=recipe_key,column_name=request.form['columnName'])
                if column_info_data['status']=='error':
                    return column_info_data
                if len(column_info_data['data'])>0:
                    column_info_data = column_info_data['data'][0]
                    data_types = column_info_data['data_types']
                    if data_types['type'] not in ['string']:
                        return ({"status": "error", "message": "column fields should be string datatype only"})
                    if data_types['empty']==100.0:
                        return ({"status": "error", "message": "column fields cannot have all empty values"})
                else:
                    return ({'status':'error','message':'column name is invalid'})

            if transformation_details['key'] in ['to_float','to_integer','to_boolean']:
                column_info_data = dataset_helper.column_info(dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key,recipe_key=recipe_key,column_name=request.form['columnName'])
                if column_info_data['status']=='error':
                    return column_info_data
                
                if len(column_info_data['data'])>0:
                    column_info_data = column_info_data['data'][0]
                    data_types = column_info_data['data_types']
                
                    # Checking the data types
                    if data_types['type'] in ['string','date','timestamp']:
                        return ({"status": "error", "message": "column cannot be converted "+str(transformation_details['key'].replace("_"," "))})

                    if data_types['empty']==100.0:
                        return ({"status": "error", "message": "column fields cannot have all empty values"})
                else:
                    return ({'status':'error','message':'column name is invalid'})

            if transformation_details['key'] in ['move_column']:
                if 'index' not in schema or schema['index'] is None:
                    return ({'status':'error','message':'position is required'})

                if 'index' in schema and schema['index'] not in ['left','right','end','begining']:
                    return ({'status':'error','message':'position is invalid'})   

            if transformation_details['key'] in ['rolling_mean','rolling_standard','rolling_sum']:
                if 'window' not in schema or schema['window'] is None or schema['window']=="":
                    return ({'status':'error','message':'window is required'})
                else:
                    if type(schema['window']) == str:
                        if bool(re.match('^(\+|-)?[0-9]*$', str(schema['window']))):
                            schema['window'] = int(schema['window'])
                        elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['window']))):
                            schema['window'] = float(schema['window'])
                        else:
                            return ({'status':'error','message':'only numerical value is allowed in window'})
                
                column_info_data = dataset_helper.column_info(dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key, recipe_key=recipe_key, column_name=request.form['columnName'])
                if column_info_data['status']=='error':
                    return column_info_data
                
                if len(column_info_data['data'])>0:
                    column_info_data = column_info_data['data'][0]
                    data_types = column_info_data['data_types']

                    if data_types['empty']==100.0:
                        return ({"status": "error", "message": "column fields cannot have all empty values"})

                    if data_types['type'] not in ['integer','decimal']:
                        return ({"status": "error", "message": str(transformation_details['key'].replace("_"," "))+" can only be perfrom on numerical column"})
                        
            if transformation_details['key'] in ['rename_column','create_duplicate_column','rolling_mean','rolling_standard','rolling_sum']:
                if 'new_column_name' not in schema or schema['new_column_name'] is None:
                    return ({'status':'error','message':'new column name is required'})
                
                if 'new_column_name' in schema and schema['new_column_name'] in list(data_frame.columns):
                    return ({'status':'error','message':'column name already exists'})
            
            if transformation_details['key'] in ['find__replace']:
                if 'find' not in schema or schema['find'] is None or schema['find']=='':
                    return ({'status':'error','message':'find value is required'})
                else:
                    if type(schema['find']) == str:
                        if bool(re.match('^(\+|-)?[0-9]*$', str(schema['find']))):
                            schema['find'] = int(schema['find'])
                        elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['find']))):
                            schema['find'] = float(schema['find'])
                
                if 'replace' not in schema or schema['replace'] is None or schema['replace']=='':
                    return ({'status':'error','message':'replace value is required'})
                else:
                    if type(schema['replace']) == str:
                        if bool(re.match('^(\+|-)?[0-9]*$', str(schema['replace']))):
                            schema['replace'] = int(schema['replace'])
                        elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['replace']))):
                            schema['replace'] = float(schema['replace'])
                
            if transformation_details['key'] in ['normalize']:
                if 'value' not in schema or schema['value'] is None:
                    return ({'status':'error','message':'normalize value is required'})
            
            if transformation_details['key'] in ['split_column']:
                if 'mode' not in schema or schema['mode'] is None:
                    return ({'status':'error','message':'mode is required'})

                if 'mode' in schema and schema['mode'] not in ['separator','length']:
                    return ({'status':'error','message':'mode is invalid'})

                if schema['mode'] in ['separator']:
                    if 'delimiter' not in schema or schema['delimiter'] is None:
                        return ({'status':'error','message':'delimiter is required'})
                
                if schema['mode'] in ['length']:
                    if 'length' not in schema or schema['length'] is None or schema['length']=="":
                        return ({'status':'error','message':'length is required'})
                    if 'length' in schema or schema['length'] is not None:
                        if type(schema['length']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(schema['length']))):
                                schema['length'] = int(schema['length'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['length']))):
                                schema['length'] = int(schema['length'])
                            else:
                                return ({'status':'error','message':'only integer value is allowed in length'})

                if 'max_split' in schema and schema['max_split'] is not None and schema['max_split']!="":
                    if type(schema['max_split']) == str:
                        if bool(re.match('^(\+|-)?[0-9]*$', str(schema['max_split']))):
                            schema['max_split'] = int(schema['max_split'])
                        elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(schema['max_split']))):
                            schema['max_split'] = int(schema['max_split'])
                        else:
                            return ({'status':'error','message':'only integer value is allowed in max split'})
                
                # If max split is empty then removing it from split column schema
                if 'max_split' in schema and schema['max_split']=="":
                    # Removing max_split from schema 
                    schema.pop('max_split', None)
                
            if transformation_details['key'] in ['fillna']:
                if 'value' not in schema or schema['value'] is None:
                    return ({'status':'error','message':'value is required'})
            
        data['schema'] = schema

        if 'format' in kwargs:
            data['format'] = kwargs['format']
        else: # Default Format
            data['format'] = 'json'
        
        return ({'status':'success','data':data})
    except Exception as e:
        return ({'status': 'error', 'message': str(e)})

# Checking whether sampling is same or not 
def checking_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling,history_details):
    if catalog_key!='' and project_key != '' and dataset_key != '' and recipe_key != '':
        if len(history_details)>0:
            target_name = None
            history_sampling = None
            # Fetching the active index from history list
            for item in history_details:
                if item['active']:
                    history_sampling = item['sampling']
                    target_name = item['target_name']
                    break
            
            if target_name is not None and history_sampling is not None:
                is_sampling_same = True # Initializing a flag to checking whether sampling is same or not
                if len(sampling)!=0: # and sampling['name'] != ''
                    if history_sampling['name']!=sampling['name']:
                        is_sampling_same = False
                        response = update_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling)
                        if response['status']=='error':
                            return response
                        data_frame = response['data_frame']
                    else: # Sampling name is same but checking other parameters of sampling
                        if sampling['name'] in ['first','last','random_records']:
                            if sampling['records']!=history_sampling['records']: # Checking whether records number are same
                                is_sampling_same = False
                                response = update_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling)
                                if response['status']=='error':
                                    return response
                                data_frame = response['data_frame']
                        elif sampling['name'] in ['random_ratio']:
                            if sampling['ratio']!=history_sampling['ratio']:
                                is_sampling_same = False
                                response = update_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling)
                                if response['status']=='error':
                                    return response
                                data_frame = response['data_frame']
                        elif sampling['name'] in ['stratified_records','rebalance_records','column_value_subset']:
                            if sampling['records']!=history_sampling['records'] or sampling['column_name']!=history_sampling['column_name']: # Checking whether records number are same
                                is_sampling_same = False
                                response = update_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling)
                                if response['status']=='error':
                                    return response
                                data_frame = response['data_frame']  
                        elif sampling['name'] in ['stratified_ratio','rebalance_ratio']:
                            if sampling['ratio']!=history_sampling['ratio']  or sampling['column_name']!=history_sampling['column_name']: # Checking whether ratio are same
                                is_sampling_same = False
                                response = update_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling)
                                if response['status']=='error':
                                    return response
                                data_frame = response['data_frame']
                # If sampling name and other parameters are same then below condition will execute
                if is_sampling_same: 
                    if target_name is not None:
                        base_path = environ.get('STORAGE',None)
                        path_dir = path.join(base_path,catalog_key,project_key,'datasets',dataset_key, "history", target_name)
                        if not path.exists(path_dir):
                            return ({"status":"error","message":"file path is invalid or does not exists"})
                        data_frame = pd.read_csv(path_dir,encoding = "ISO-8859-1")
            else:
                # Passing source dataFrame
                dataset_obj = dataset.Dataset(catalog_key,project_key,dataset_key)
                if len(sampling)==0:
                    resp = dataset_obj.get_dataframe(sampling_name='first',request_from='api')
                else:
                    if sampling['name'] == '':
                        resp = dataset_obj.get_dataframe(sampling_name='first',request_from='api')
                    else:       
                        resp = dataset_obj.get_dataframe(sampling_name=sampling['name'],request_from='api',sampling=sampling)
                if resp['status']=='error':
                    return resp
                data_frame = resp['dataFrame']
            return ({'status':'success','data_frame':data_frame})
        else:
            return ({'status':'success','messsage':'history list is empty'})
    else:
        return ({'status':'error','message':'Missing required parameters'})
  
# Updating Sampling
def update_sampling(catalog_key, project_key,dataset_key,recipe_key,sampling):
    if catalog_key!=None and project_key!=None and dataset_key!=None and recipe_key!=None:
        # Fetching Data Frame from the soruce dataset
        dataset_obj = dataset.Dataset(catalog_key,project_key,dataset_key)
        data_frame  = dataset_obj.get_dataframe(sampling_name=sampling['name'],request_from='api',sampling=sampling)
        if data_frame['status']=='error':
            return data_frame
        else:
            data_frame = data_frame['dataFrame']

        # Fetching history lists by recipe key
        historyObj = history.History(catalog_key=catalog_key, project_key=project_key, dataset_key=dataset_key, recipe_key=recipe_key)
        response = historyObj.lists()
        if response['status']=='error':
            return response
        
        # Only till active history it should run for that first we have to know what is opration count before active and run the history based on sampling
        history_lists = response['history_lists']
        
        # Storing history list length
        history_len = len(history_lists)
        
        if history_len>0: # If it has the records
            history_details = []
            operation_name = "source_dataset" # Default name If history all steps active is False
            temp_history_len = 0
            # Fetching the active index from history list
            for item in history_lists:
                history_details.append(item) 
                if item['active']:
                    operation_name = item['transformationKey']
                    break
                else:
                    temp_history_len += 1

            # Making history folder to store respective dataset file operation
            base_path = environ.get('STORAGE',None)
            history_dir = path.join(base_path,catalog_key,project_key,'datasets',dataset_key,'history')
            column_name = None
            if history_len != temp_history_len:
                # Running the history
                for item in history_details:
                    transformation_data = TransformationSchema.objects(key=item['transformationKey'],deleted=False).to_json()
                    transformation_data = list(loads(transformation_data)) 
                    if len(transformation_data)==0:
                        return ({'status':'error','message':'Transformation key is invalid'})
                    else:
                        transformation_data = transformation_data[0]
                        schema = item['schema']
                        if 'column_name' in schema:
                            column_name = schema['column_name']
                        schema['data_frame'] = data_frame 
                        # Executing Code
                        exec_resp = transformation_helper.execute_code(file_path=transformation_data['path'],function_name=transformation_data['function_name'],schema=schema,request_from='api')
                        if exec_resp['status'] == 'error':
                            return exec_resp
                        data_frame = exec_resp['data_frame']    
            else: # Fetching data frame from source dataset
                pass

            # Storing target File
            timestamp = int(round(time.time() * 1000))
            file_name = operation_name + "_" + str(timestamp) + ".csv"
            # Converting the data frame to CSV
            data_frame_to_csv = data_frame.to_csv(index=False)
            history_path = path.join(history_dir, file_name)
            
            # Generating the target file
            fh = open(history_path, "w")
            fh.write(data_frame_to_csv)
            fh.close()
            
            # Checking sampling name 
            if sampling['name']=='':
                sampling['name'] = 'first'
                sampling['records'] = int(environ.get('DEFAULT_RECORD_COUNT',None))
            
            # Update file name of active state in History scehema
            history_resp = HistorySchema.objects(recipe_key=recipe_key, project_key=project_key, catalog_key=catalog_key, source_key=dataset_key, deleted= False, active=True).modify(
                            new=True,
                            set__target_name = file_name,
                            set__sampling = sampling,
                            set__updated_at = datetime.now()
                        )
            
        return ({'status':'success','data_frame':data_frame})
    else:
        return ({"status":"error","message":"Missing required parameters"})

# Validating Filter Incoming Data (request,data_frame)
def validate_filter_data(**kwargs):
    if 'data_frame' not in kwargs:
        return ({'status':"error",'message':"data is required"})
    else:
        data_frame = kwargs['data_frame']
    
    if 'filters' in kwargs and kwargs['filters'] is not None:
        if len(kwargs['filters'])>0:
            filters = []
            operator_lists = ['greater_then_equal','greater_then','less_then','less_then_equal','not_equal','equal','starts_with','ends_with','in_between','remove_empty_rows','ok','not_ok','empty']
            for item in kwargs['filters']:
                temp = {}
                # Checking whether column name exists or not
                if 'column_name' not in item:
                    return ({'status':"error",'message':"column name is required"})
                
                # Checking whether request column name is valid or not
                if type(item["column_name"])==list:
                    result = set(item['column_name']) <= set(list(data_frame.columns))
                    if not result:
                        return ({"status": "error", "message": "column name is invalid"})
                elif item["column_name"] not in list(data_frame.columns):
                    return ({"status": "error", "message": "Column name is invalid"})
                else:
                    temp['column_name'] = item["column_name"]

                # Checking whether operator exists or not
                if 'operator' not in item:
                    return ({'status':"error",'message':"filter operator is required"})
                
                # Checking whether request operator exists in the operator list or not
                if item['operator'] not in operator_lists:
                    return ({'status':"error",'message':"operator is invalid"})
                else:
                    temp['operator'] = item["operator"]

                # Validating the required parameters
                if item['operator'] in ['greater_then_equal','greater_then','less_then','less_then_equal','equal','not_equal','starts_with','ends_with']:
                    if 'value' not in item:
                        return ({'status':"error",'message': item['operator']+" missing value parameter"})
                    else:
                        if type(item['value']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(item['value']))):
                                temp['value'] = int(item['value'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(item['value']))):
                                temp['value'] = float(item['value'])
                            else:
                                temp['value'] = item['value']
                        else:
                            temp['value'] = item['value']
                
                # Checking whether operator is in_between
                if item['operator'] in ['in_between']:
                    if 'start' not in item:
                        return ({'status':"error",'message':item['operator']+" missing start parameter"})
                    else:
                        if type(item['start']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(item['start']))):
                                temp['start'] = int(item['start'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(item['start']))):
                                temp['start'] = float(item['start'])
                            else:
                                temp['start'] = item['start']
                        else:
                            temp['start'] = item['start']

                    if 'end' not in item:
                        return ({'status':"error",'message':item['operator']+" missing end parameter"})
                    else:
                        if type(item['end']) == str:
                            if bool(re.match('^(\+|-)?[0-9]*$', str(item['end']))):
                                temp['end'] = int(item['end'])
                            elif bool(re.match("^(\+|-)?\d+?\.\d+?$", str(item['end']))):
                                temp['end'] = float(item['end'])
                            else:
                                temp['end'] = item['end']
                        else:
                            temp['end'] = item['end']
                
                if 'dataset_key' in kwargs and kwargs['dataset_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None and 'catalog_key' in kwargs and kwargs['catalog_key'] is not None:
                    date_format = []
                    if 'recipe_key' in kwargs and kwargs['recipe_key'] is not None:
                        column_info_data = dataset_helper.column_info(dataset_key=kwargs['dataset_key'], project_key=kwargs['project_key'], catalog_key=kwargs['catalog_key'], recipe_key=kwargs['recipe_key'], column_name=item["column_name"])
                        # Fetching date format from Recipe Schema
                        recipe_data = RecipeSchema.objects(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'], source_key=kwargs['dataset_key'], key=kwargs['recipe_key'], deleted=False).to_json()
                        recipe_data = loads(recipe_data)
                        if len(recipe_data)>0:
                            if 'date_format' in recipe_data[0]['operation']:
                                date_format = recipe_data[0]['operation']['date_format'] 
                    else:
                        column_info_data = dataset_helper.column_info(dataset_key=kwargs['dataset_key'], project_key=kwargs['project_key'], catalog_key=kwargs['catalog_key'], column_name=item["column_name"])
                        # Fetching date format from File Schema
                        file_data  = FileSchema.objects(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'], dataset_key=kwargs['dataset_key'], deleted=False).to_json()
                        file_data  = loads(file_data)
                        if len(file_data)>0:
                            if 'date_format' in file_data[0]['operation']:
                                date_format = file_data[0]['operation']['date_format'] 
                    
                    if column_info_data['status']=='error':
                        return column_info_data
                    if len(column_info_data['data'])>0:
                        column_info_data = column_info_data['data'][0]
                        data_types = column_info_data['data_types']
                    
                        if item['operator'] in ['ok','not_ok','empty']:
                            pass
                        else:
                            # Checking whether all the value is empty or not
                            if data_types['empty']==100.0:
                                return ({"status": "error", "message": str(item["column_name"])+ " column fields cannot have all empty values"})
                        
                        # Checking whether start with and end with is applied on any other data type except string
                        if item['operator'] in ['starts_with','ends_with']:
                            if data_types['type'] not in ['string']:
                                return ({"status": "error", "message": str(item['operator'].replace("_"," "))+" can only be applied on string datatype"})

                        # Validating for string data type
                        if data_types['type'] in ['string','boolean']:
                            if item['operator'] in ['greater_then_equal','greater_then','less_then','less_then_equal','in_between']:
                                return ({"status": "error", "message": "cannot apply "+str(item['operator'].replace("_"," "))+" on "+str(data_types['type'])+" datatype"})
                        
                        # Validating for integer and float data type
                        if data_types['type'] in ['integer','decimal']:
                            if item['operator'] in ['greater_then_equal','greater_then','less_then','less_then_equal','in_between']:
                                if data_types['not_ok']!=0.0:
                                    return ({"status": "error", "message": "There are few values not in proper datatype. Please clean the data and then apply "+str(item['operator'].replace("_"," ")) + " operator on "+str(item["column_name"])+" column"})

                        # Validating for date data type
                        if data_types['type'] in ['date']:
                            if len(date_format)==0:
                                return ({'status':'error','message':'Date format is required'})
                            else:
                                date_format = date_format[0]
                            
                            try:
                                pd.to_datetime(data_frame[item["column_name"]],format=date_format['format'])
                            except:
                                return ({'status':'error','message': str(item["column_name"])+" column does not support date format"})
                            
                            if item['operator'] in ['greater_then_equal','greater_then','less_then','less_then_equal','equal','not_equal']:
                                try:
                                    pd.to_datetime(item['value'],format=date_format['format'])
                                except:
                                    return ({'status':'error','message': "supply "+str(item['value'])+" value is invalid"})
                            
                            if item['operator'] in ['in_between']:
                                # For Date format validation
                                try:
                                    pd.to_datetime(item['start'],format=date_format['format'])
                                except:
                                    return ({'status':'error','message': "supply "+str(item['start'])+" value does not support date format"})
                                
                                try:
                                    pd.to_datetime(item['end'],format=date_format['format'])
                                except:
                                    return ({'status':'error','message': "supply "+str(item['end'])+" value does not support date format"})

                        filters.append(temp)
                    else:
                        return ({'status':'error','message':'column name is invalid'})
            return ({'status':"success",'filters':filters})
        else:
            return ({'status':"error",'message':"filter data is required"})

# Validating Mass Edit Incoming Data
def validate_cluster_data(request,data_frame):
    data = request.get_json()

    # Checking whether column name exists or not
    if 'columnName' not in data:
        return ({'status':"error",'message':"column name is required"})

    # Checking whether request column name is valid or not
    if data['columnName'] not in list(data_frame.columns):
        return ({"status":"error","message":"column name is invalid"})

    if data['edit']!=None and len(data['edit'])>0:
        for item in data['edit']:
            if 'find' not in item:
                return ({'status':"error",'message':"Required parameter is missing"})
            
            if 'replace' not in item:
                return ({'status':"error",'message':"Required parameter is missing"})
        return ({'status':"success"})
    else:
        return ({'status':"error",'message':"Required parameter is missing"})

# Wrangling response for UI
def wrangling_response(**kwargs):
    if 'catalog_key' not in kwargs or 'project_key' not in kwargs or 'dataset_key' not in kwargs:
        return ({'status':'error','message':'Missing required parameter'})
    else:
        if kwargs['catalog_key'] is None or kwargs['project_key'] is None or kwargs['dataset_key'] is None: 
            return ({'status':'error','message':'Missing required parameter'})
        else:
            if 'data_frame' not in kwargs:
                return ({'status':'error','message':'Missing required parameter'})
            else:
                data_frame = kwargs['data_frame']
                row_count = data_frame.shape[0]
                if data_frame.empty:
                    if 'format' in kwargs and kwargs['format'] is not None:
                        if kwargs['format']=='json':
                            return ({'status':"success",'data':data_frame.to_dict(orient="records"),'row_count':row_count,'columns':list(data_frame.columns)})
                        elif kwargs['format']=='csv':
                            return ({'status':"success",'data':data_frame.to_csv(index_label="index"),'row_count':row_count,'columns':list(data_frame.columns)})
                        else:
                            return ({'status':"success",'data':data_frame.to_dict(orient="records"),'row_count':row_count,'columns':list(data_frame.columns)})
                    else: # Default Format JSON
                        return ({'status':"success",'data':data_frame.to_dict(orient="records"),'row_count':row_count,'columns':list(data_frame.columns)})
                
                data_frame_copy = copy.deepcopy(data_frame)
                # For freeze column
                data_frame_new = copy.deepcopy(data_frame)
            
            # Fetching Freeze column index
            if 'recipe_key' in kwargs and kwargs['recipe_key'] is not None:
                recipe_details = RecipeSchema.objects(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'], source_key=kwargs['dataset_key'], key=kwargs['recipe_key'], deleted=False).to_json()
                recipe_details = list(loads(recipe_details))
                freeze_column_index = recipe_details[0]['operation']['freeze_column_index']
            else:
                file_details = FileSchema.objects(catalog_key=kwargs['catalog_key'], project_key=kwargs['project_key'], dataset_key=kwargs['dataset_key'], deleted=False).to_json()
                file_details = list(loads(file_details))
                freeze_column_index = file_details[0]['operation']['freeze_column_index']
            
            # Applying Freeze column logic if exists
            if len(freeze_column_index)>0:
                freeze_col_name = data_frame.columns[freeze_column_index]
                if len(freeze_col_name)>0: 
                    i = 0
                    for col_name in freeze_col_name:
                        df_col_data = data_frame_new[col_name]
                        if col_name not in data_frame.columns: # If column does not exists in current data frame
                            data_frame.insert(i, col_name,  df_col_data)
                        else: # If column exists in current data frame
                            df_col_data = data_frame[col_name]
                            data_frame.drop([col_name], axis = 1, inplace = True)
                            data_frame.insert(i, col_name,  df_col_data)
                        i += 1
            
            # Pagination
            page_size = int(environ.get('DEFAULT_PAGE_SIZE',None))
            start = 0
            limit = (start + page_size)-1
            data_frame = data_frame.iloc[start:limit,:]

            # Replacing any NaN/None Value to Empty String
            data_frame.replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN',""], value=np.nan, inplace=True)
            data_frame.fillna("", inplace = True)
            
            if 'format' in kwargs and kwargs['format'] is not None:
                if kwargs['format']=='json':
                    return ({'status':"success",'data':data_frame.to_dict(orient="records"),'row_count':row_count,'columns':list(data_frame.columns)})
                elif kwargs['format']=='csv':
                    return ({'status':"success",'data':data_frame.to_csv(index_label="index"),'row_count':row_count,'columns':list(data_frame.columns)})
                else:
                    return ({'status':"success",'data':data_frame.to_dict(orient="records"),'row_count':row_count,'columns':list(data_frame.columns)})
            else: # Default Format JSON
                return ({'status':"success",'data':data_frame.to_dict(orient="records"),'row_count':row_count,'columns':list(data_frame.columns)})
                
# Sampling Schema
def sampling_schema():
    records     = int(environ.get('DEFAULT_RECORD_COUNT',None))
    ratio       = int(environ.get('DEFAULT_SAMPING_RATIO',None))  
    sampling    = [{
            'name': "First records",
            'label': "first",
            'description':"Takes the first N rows of the dataset. Very fast (only reads N rows) but may result in a very biased view of the dataset.",
            'type':'number',
            'value': records
        },{
            'name': "Last records",
            'label': "last",
            'description':"Takes the last N rows of the dataset. Very fast (only reads N rows) but may result in a very biased view of the dataset.",
            'type':'number',
            'value': records
        },{
            'name': "Random (nb. records)",
            'label': "random_records",
            'type':'number',
            'description':"Randomly selects N rows.",
            'value': records
        },{
            'name': "Random (approx. ratio)",
            'label': "random_ratio",
            'type':'percentage', 
            'description':"Randomly selects approximately X% of the rows.",
            'value': ratio
        },{
            'name': "Stratified (records)",
            'label': "stratified_records",
            'type':'number',
            'description':"Randomly selects N rows, ensuring that the repartition of values in a column is respected in the sampling. Ensures that all modalities of the column appear in the output. May return a few more than N rows.",
            'value': records
        },{
            'name': "Stratified (ratio)",
            'label': "stratified_ratio",
            'type':'percentage',
            'description':"Randomly selects X% of the rows, ensuring that the repartition of values in a column is respected in the sampling. Ensures that all modalities of the column appear in the output. May return a bit more than X% rows.",
            'value': ratio
        },{
            'name': " Class rebalance (approx. nb. records)",
            'label': "rebalance_records",
            'type':'number',
            'description':"Randomly selects approximately N rows, trying to rebalance equally all modalities of a column. Does not oversample, only undersample (so some rare modalities may remain under-represented). Rebalancing is not exact.",
            'value': records
        },{
            'name': "Class rebalance (approx. ratio)",
            'label': "rebalance_ratio",
            'type':'percentage',
            'description':"Randomly selects approximately X% of the rows, trying to rebalance equally all modalities of a column. Does not oversample, only undersample  (so some rare modalities may remain under-represented). Rebalancing is not exact.",
            'value': ratio
        },{
            'name': "Column value subset (approx. nb. records)",
            'label': "column_value_subset",
            'type':'number',
            'description':"Randomly selects a subset of values and chooses all rows with these values, in order to obtain approximately N rows.",
            'value': records
        },{
            'name': "All records",
            'label': "all",
            'type':'',
            'description':"Fetch all the rows of the dataset",
            'value':''
        }
    ]

    return ({'status':'success','sampling':sampling})

# Validating set filter
def set_filters_validation(request):
    try:
        catalog_key = request.headers.get('catalogKey')
        project_key = request.headers.get("projectKey")
        dataset_key = request.headers.get("datasetKey")
        
        # For analysis API the recipe key will be None
        recipe_key  = None
        sampling    = {}
        if 'recipeKey' in request.headers:
            recipe_key = request.headers.get("recipeKey")
        
        if recipe_key is None:
            # validating catalogKey, projectKey, datasetKey association exists or not
            resp = dataset_helper.validate_dataset(catalog_key, project_key,dataset_key)
            if resp['status'] == 'error':
                return resp
            
            # Default Sampling
            file_data = FileSchema.objects(dataset_key=dataset_key,project_key=project_key,catalog_key=catalog_key, deleted=False).to_json()
            file_data = loads(file_data)
            if len(file_data)>0:
                sampling = file_data[0]['operation']['sampling']
        else:
            # validating catalogKey, projectKey, datasetKey & recipeKey association exists or not
            resp = recipe_helper.validate_recipe(catalog_key, project_key,dataset_key,recipe_key)
            if resp['status'] == 'error':
                return resp

            # Default Sampling
            recipe_data = RecipeSchema.objects(source_key=dataset_key, project_key=project_key, catalog_key=catalog_key, key=recipe_key, deleted=False).to_json()
            recipe_data = loads(recipe_data)
            if len(recipe_data)>0:
                sampling = recipe_data[0]['operation']['sampling']
        
        is_sampling_change = False
        # Validating Sampling    
        if 'sampling' in request.json:
            is_sampling_change = True
            sampling_data = request.json['sampling']
            if 'name' in sampling_data:
                if sampling_data['name'] not in ['first','last','all','random_records','random_ratio','stratified_records','stratified_ratio','rebalance_records','rebalance_ratio','column_value_subset']:
                    return ({"status":"error","message": "sampling name is invalid"})
                else:
                    sampling['name'] = sampling_data['name']
                    sampling['ratio'] = ""
                    sampling['records'] = ""
                    sampling['column_name'] = ""

                if sampling_data['name'] in ['first','last','random_records','stratified_records','rebalance_records','column_value_subset']: 
                    if 'records' in sampling_data:
                        if type(sampling_data['records']) != int:
                            return ({"status":"error","message": "only integer value is allowed in records"})
                        else:
                            sampling['records'] = int(sampling_data['records'])
                            sampling['ratio'] = ""
                            sampling['column_name'] = ""
                
                if sampling_data['name'] in ['random_ratio','stratified_ratio','rebalance_ratio']:  
                    if 'ratio' in sampling_data:
                        if type(sampling_data['ratio']) != int:
                            return ({"status":"error","message": "only integer value is allowed in ratio"})
                        else:
                            sampling['ratio']   = int(sampling_data['ratio'])
                            sampling['records'] = ""
                            sampling['column_name'] = ""

                if sampling_data['name'] in ['stratified_records','stratified_ratio','rebalance_records','rebalance_ratio','column_value_subset']:
                    if 'column_name' not in sampling_data:
                        return ({"status":"error","message": "column name is required"})
                    else:
                        sampling['column_name'] = sampling_data['column_name']
        
        if recipe_key is not None:
            # Checking whether any transformation already exists or not
            history_details = HistorySchema.objects(recipe_key = recipe_key,source_key = dataset_key,project_key=project_key,catalog_key=catalog_key,deleted= False).to_json()
            history_details = list(loads(history_details)) 
            if len(history_details)>0: # If history has the records taking the data frame from the latest active steps
                # Fetching the sampling of active index from history list
                resp = checking_sampling(catalog_key,project_key,dataset_key,recipe_key,sampling,history_details)
                if resp['status']=='error':
                    return resp
                data_frame = resp['data_frame']
            else: # If history schema is empty
                # Fetching Data Frame
                dataset_obj = dataset.Dataset(catalog_key,project_key,dataset_key)
                data_frame  = dataset_obj.get_dataframe(sampling_name=sampling['name'],request_from='api',sampling=sampling)
                if data_frame['status']=='error':
                    return data_frame
                else:
                    data_frame = data_frame['dataFrame']
        else: # If recipe key is None
            # Fetching Data Frame
            dataset_obj = dataset.Dataset(catalog_key,project_key,dataset_key)
            data_frame  = dataset_obj.get_dataframe(sampling_name=sampling['name'],request_from='api',sampling=sampling)
            if data_frame['status']=='error':
                return data_frame
            else:
                data_frame = data_frame['dataFrame']

        # Passing Data Frame to Prepare 
        data = {
            'data_frame' : data_frame,
            'catalog_key': catalog_key,
            'project_key': project_key,
            'dataset_key': dataset_key
        }

        # If sampling is change then adding it to data
        if is_sampling_change:
            data['sampling'] = sampling

        if recipe_key is not None:
            data['recipe_key'] = recipe_key
        
        # Validating Freeze column index
        if 'freeze_column_index' in request.json:
            if len(request.json['freeze_column_index'])>0:
                for item in request.json['freeze_column_index']:
                    if item > data_frame.shape[1] or item < 0:
                        return ({'status':'error','message':'freeze column index is invalid/does not exists'})    
            data['freeze_column_index'] = request.json['freeze_column_index']
        
        # Validating Filters
        if 'filters' in request.json:
            if len(request.json['filters'])>0:
                response = validate_filter_data(filters=request.json['filters'], data_frame=data_frame, recipe_key=recipe_key, dataset_key=dataset_key, project_key=project_key, catalog_key=catalog_key)
                if response['status'] == 'error':
                    return response
                data['filters'] = response['filters']
            else:
                data['filters'] = request.json['filters']
            
        # Validating Sorting
        if 'sorting' in request.json:
            if len(request.json['sorting'])>0:
                columns = data_frame.columns
                for item in request.json['sorting']:
                    if item['column_name'] not in columns:
                        return ({'status':'error','messsage':'column name is invalid'})

                    if item['order_by'].lower() not in ['asc','desc']:
                        return ({'status':'error','messsage':'invalid value passed in order by'})
            data['sorting'] = request.json['sorting']
        
        # Validating column index
        if 'column_index' in request.json:
            if len(request.json['column_index'])>0:
                column_count = data_frame.shape[1]
                col_index = request.json['column_index']
                if col_index[0] < 0:
                    col_index[0] = 0
                elif col_index[1] > column_count:
                    col_index[1] = column_count
                data['column_index'] = col_index
            else:    
                data['column_index'] = request.json['column_index']
        
        # Validating Hide column
        if 'hide_column' in request.json:
            if len(request.json['hide_column'])>0:
                for item in request.json['hide_column']:
                    if item > data_frame.shape[1] or item < 0:
                        return ({'status':'error','message':'hide column index is invalid/does not exists'})    
            data['hide_column'] = request.json['hide_column']
        
        # Date Format
        if 'date_format' in request.json:
            if len(request.json['date_format'])>0:
                for item in request.json['date_format']:
                    if item['format'] not in ["%d-%m-%Y","%m-%d-%Y","%Y-%m-%d","%d/%m/%Y","%m/%d/%Y","%Y/%m/%d","%d.%m.%Y","%m.%d.%Y","%Y.%m.%d"]:
                        return ({'status':'error','message':"Date format is invalid"})
                    if item['column_name'] not in list(data_frame.columns):
                        return ({'status':'error','message':'column name is invalid'})
                    try:
                        pd.to_datetime(data_frame[item["column_name"]],format=item['format'])
                    except:
                        return ({'status':'error','message': str(item["column_name"])+" column does not support date format"})
            data['date_format'] = request.json['date_format']
        return ({'status':'success','data':data})
    except Exception as e:
        return ({'status': 'error', 'message': str(e)})

def preview_path(**kwargs):
    if 'catalog_key' in kwargs and kwargs['catalog_key'] is not None and 'project_key' in kwargs and kwargs['project_key'] is not None and 'dataset_key' in kwargs and kwargs['dataset_key'] is not None:
        base_path = environ.get('STORAGE',None)
        # Making catalog folder to store respective projects inside that
        catalog_dir = path.join(base_path,kwargs['catalog_key'])
        if not path.exists(catalog_dir):
            makedirs(catalog_dir) 
    
        # Making project folder to store respective dataset inside that
        project_dir = path.join(catalog_dir,kwargs['project_key'],'datasets')
        if not path.exists(project_dir):
            makedirs(project_dir)
        
        # Making dataset folder to store respective dataset inside that
        dataset_dir = path.join(project_dir,kwargs['dataset_key'])
        if not path.exists(dataset_dir):
            makedirs(dataset_dir)
        
        # Making project folder to store respective dataset inside that
        temp_dir = path.join(dataset_dir,'temp')
        if not path.exists(temp_dir):
            makedirs(temp_dir)
        
        timestamp       = int(round(time.time() * 1000))
        if 'file_name' in kwargs and kwargs['file_name'] is not None:
            source_file_name  = kwargs['file_name'] + "-"+ str(timestamp) + ".csv"
        else:
            source_file_name  = str(timestamp) + ".csv"
        # Storing data in the source file path
        source_file_path = path.join(temp_dir, source_file_name)
        fh = open(source_file_path, "w")
        fh.write(kwargs['data'])
        fh.close()
        return ({'status':'success','file_path':source_file_path})
    else:
        return ({'status':'error','message':'Missing required parameters'})

def validate_history(**kwargs):
    try:
        if kwargs["historyId"]:
            history_obj = HistorySchema(id=kwargs["historyId"]).to_json()
            if len(history_obj) > 0:
                return ({"status": "success","data": list(loads(history_obj))})
            else:
                return ({"status": "error","message": "history_id is invalid"})
        else:
            return ({"status": "error","message": "history_id is invalid"})
    except Exception as e:
        return ({"status": "error","message": str(e) })