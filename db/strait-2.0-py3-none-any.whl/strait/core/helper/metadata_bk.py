import re
import json
import pandas as pd
import numpy as np
from dask import delayed
from datetime import datetime

__gender__ = ["male", "female", 'm', 'f']
__bool__ = ["yes", "no", '0', '1']
__type__ = ["gender", "phone", "email", "url"]
url = "^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$"
email = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
phone = "^(?:(?:\+?1\s*(?:[.-]\s*)?)?(?:\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?:[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?:[.-]\s*)?([0-9]{4})(?:\s*(?:#|x\.?|ext\.?|extension)\s*(\d+))?$"
pattern1 = "(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$"
#pattern4 = "(\d{1,2})[/.-](\d{1,2})$"
#pattern5 = "(\d{2,4})[/.-](\d{1,2})$"
#pattern6 = "(\d{1,2})[/.-](\d{2,4})$"
pattern2 = '(\d{2,4})[/.-](\d{1,2})[/.-](\d{1,2})$'
pattern3 = 'jan|feb|apr|mar|may|jun|jul|aug|sep|nov|dec'
pattern = '([0-9]{2}:[0-9]{2}:[0-9]{2})'


def typeof(value):
    if value is np.nan or value != value or value in [None,'none'] or value == '':
        return 'empty'
    elif type(value) == int or bool(re.match('^(\+|-)?[0-9]*$', str(value))):
        return 'integer'
    elif (type(value) == float and value == value) or bool(re.match("^(\+|-)?\d+?\.\d+?$", str(value))):
        return 'decimal'
    elif type(value) == bool or str(value).lower() in __bool__:
        return 'boolean'
    elif str(value).lower() in __gender__:
        return 'gender'
    elif re.match(url, str(value)) != None:
        return 'url'
    elif re.search(phone, str(value)) != None:
        return 'phone'
    elif re.match(email, str(value)) != None:
        return 'email'
    elif re.search(pattern, str(value)) != None:
        return 'timestamp'
    elif re.match(pattern1, str(value)) != None or re.match(pattern2, str(value)) != None or re.search(pattern3, str(
            value)) != None:
        return 'date'
    elif type(value) == str:
        return 'string'
    else:
        return 'string'

def data_type(datatypes):
    __type__ = ["gender", "phone", "email", "url", "string","boolean"]
    data_types = []

    for cols in datatypes.columns:
        data_type = {}
        data_type['field'] = cols
        data_type['predicted_type'] = datatypes[cols].value_counts().idxmax()
        if data_type['predicted_type'] == 'empty':
            try:
                data_type['predicted_type'] = datatypes[cols].value_counts().keys()[1]
            except:
                data_type['predicted_type'] = 'string'
        if data_type['predicted_type'] == 'boolean' and datatypes[cols].nunique() != 1 and \
                datatypes[cols].value_counts().keys()[1] != 'empty':
            data_type['predicted_type'] = datatypes[cols].value_counts().keys()[1]

        if data_type['predicted_type'] in __type__:
            data_type['original_type'] = 'string'
        else:
            data_type['original_type'] = data_type['predicted_type']
        data_type['type'] = data_type['original_type']

        if data_type['original_type'] == 'string':
            data_type['identified'] = "categorical"
        else:
            data_type['identified'] = "non-categorical"
        data_type['empty'] = round(
            (datatypes[cols][datatypes[cols] == 'empty'].shape[0] / datatypes[cols].shape[0]) * 100, 2)
        if datatypes[cols].value_counts().idxmax() != 'empty':
            data_type['ok'] = round((datatypes[cols][datatypes[cols] == datatypes[cols].value_counts().idxmax()].shape[
                                         0] / datatypes[cols].shape[0]) * 100, 2)
        elif int(data_type['empty']) == 50:
            data_type['ok'] = round((datatypes[cols][datatypes[cols] == datatypes[cols].value_counts().keys()[1]].shape[
                                         0] / datatypes[cols].shape[0]) * 100, 2)
        else:
            data_type['ok'] = 0.0
        data_type['not_ok'] = round(100 - abs((data_type['empty'] + data_type['ok'])), 2)
        data_type['id'] = ''
        if data_type['original_type'] == 'integer' or data_type['original_type']== 'decimal':
            data_type['min_value'] = ""
            data_type['max_value'] = ""
        data_types.append(data_type)
    return data_types

def ok_notok(datatypes):
    ok_notok = {}
    for cols in datatypes.columns:
        empty = datatypes[cols].index[datatypes[cols] == 'empty'].tolist()
        notok = datatypes[cols].index[
            (datatypes[cols] != 'empty') & (datatypes[cols] != datatypes[cols].value_counts().keys()[0])].tolist()
        ok = datatypes[cols].index[
            (datatypes[cols] == datatypes[cols].value_counts().keys()[0]) & (datatypes[cols] != 'empty')].tolist()
        ok_notok[cols] = {'empty': empty, 'not_ok': notok,'ok':ok}
    return ok_notok

def specific_col_into_freq_func(df, colname, top=0,sort_by_value=False,data_types=None):
    data_frame = df
    return_json = {}
    freq_df = data_frame[colname].value_counts().reset_index().rename(columns={'index': colname, colname: 'frequencies'})
    column_index = data_frame.columns.get_loc(colname)
    data_type = None
    minimum = 0
    maximum = 0
    if data_types[column_index]['field']==colname:
        data_type = data_types[column_index]['type']
        keys = data_types[column_index].keys()
        if 'min_value' in keys and 'max_value' in keys:
            minimum = data_types[column_index]['min_value']
            maximum = data_types[column_index]['max_value']
    if freq_df.shape[0]>10:
        try:
            if ((data_type is not None) and (data_type in ['decimal'])):
                number_bins = np.linspace(float(minimum),float(maximum),10,dtype=float)
            else:
                number_bins = np.linspace(minimum,maximum,10,dtype=int)
            
            df[colname].replace(['',' '], np.nan, inplace=True)
            df = df[df[colname].notnull()]
            if ((data_type is not None) and (data_type in ['decimal'])):
                df[colname] = df[colname].apply(lambda x: float(x))
            
            freq_df= pd.cut(df[colname], number_bins).value_counts().reset_index().rename(columns={'index': colname, colname: 'frequencies'})
        except:
            pass
    try:
        if not sort_by_value:
            freq_df = freq_df.sort_values(by=[colname])
        else:
            pass
    except:
        pass
    if top == 0:
        return_json[colname] = {"label": freq_df[colname].tolist(), "value": freq_df['frequencies'].tolist()}
    else:
        freq_df.head(top) 
        return_json[colname] = {"label": freq_df[colname].tolist(), "value": freq_df['frequencies'].tolist()}
    return return_json

# For Integer and Decimal
def calculate_min_max_value(df,data_types):
    for column_name in df.columns:
        column_index = df.columns.get_loc(column_name)
        if data_types[column_index]['original_type'] in ['integer','decimal']:
            df[column_name] = pd.to_numeric(df[column_name], errors='coerce')         
            if data_types[column_index]['original_type'] in ['integer']:
                data_types[column_index]['min_value'] = int(df[column_name].min()) or 0
                data_types[column_index]['max_value'] = int(df[column_name].max()) or 0
            else:
                data_types[column_index]['min_value'] = float(df[column_name].min()) or 0.0
                data_types[column_index]['max_value'] = float(df[column_name].max()) or 0.0
           # print("minimum-->",data_types[column_index]['min_value'],"maximum-->",data_types[column_index]['max_value'],"column-->",column_name)
    return data_types

def predict_types(data,top=0,sort_by_value=False):
    metadata = {}
    frequency = {}
    _id = {}
    datatypes = pd.DataFrame()
    for cols in data.columns:
        datatypes[cols] = data[cols].apply(typeof).values
    metadata['data_types'] = data_type(datatypes)
    metadata['data_types'] = calculate_min_max_value(data,metadata['data_types'])
    for cols in data.columns:
        tempDict = specific_col_into_freq_func(data, cols, top,sort_by_value,metadata['data_types'])
        frequency[cols] = tempDict[cols]
        if data[cols].is_unique:
            _id[cols] = 'id'
        else:
            _id[cols] = "not_id"
    
    metadata['id'] = [_id]
    metadata['columns'] = data.columns.tolist()
    metadata['histogram'] = frequency
    metadata['ok_not_ok'] = ok_notok(datatypes)
    return json.dumps(metadata, default=str)