import re
from json import loads
from strait.core.model.schema import RecipeSchema

# Checking whether recipe name/key already exists or not
def recipe_name_exists(catalogKey=None,projectKey=None,datasetKey=None,key=None,name=None):
    if catalogKey!=None and projectKey!=None and datasetKey!=None:
        if name!=None:
            response = RecipeSchema.objects(catalog_key=catalogKey,project_key=projectKey,source_key=datasetKey,name=name,deleted=False).to_json()
            response = list(loads(response))
            if len(response) > 0 :
                return ({"status":"error","message":"Recipe name already exists"})
        elif key!=None:
            response = RecipeSchema.objects(catalog_key=catalogKey,project_key=projectKey,source_key=datasetKey,key=key,deleted=False).to_json()
            response = list(loads(response))
            if len(response) > 0 :
                return ({"status":"error","message":"Recipe name already exists"})
        return ({"status":"success"})
    else:
        return ({'status':"error",'message':"catalogKey, projectKey and datasetKey is required"})

# Generating key by Name
def generate_key(name):
    if name!=None and name!="":
        # Only allowing alphanumeric characters
        name = re.sub('[^a-zA-Z0-9 ]','', name)
        # Replacing space with underscore
        key = name.replace(" ", "_")
        return ({"status":"success",'key':key.lower()}) 
    else:
        return ({'status':"error",'message':"name is required"})

# Validate Recipe 
def validate_recipe(catalogKey=None,projectKey=None,datasetKey=None,recipeKey=None):
    response = []
    if catalogKey!=None and projectKey!=None and recipeKey!=None and datasetKey!=None:
        response = RecipeSchema.objects(catalog_key=catalogKey,project_key=projectKey,source_key=datasetKey,key=recipeKey,deleted=False).to_json()
        response = list(loads(response))
    elif catalogKey!=None and projectKey!=None and recipeKey!=None:
        response = RecipeSchema.objects(catalog_key=catalogKey,project_key=projectKey,key=recipeKey,deleted=False).to_json()
        response = list(loads(response))
    elif catalogKey!=None and projectKey!=None and datasetKey!=None:
        response = RecipeSchema.objects(catalog_key=catalogKey,project_key=projectKey,source_key=datasetKey,deleted=False).to_json()
        response = list(loads(response))
    if len(response) == 0 :
        return ({"status":"error","message":"Recipe key is invalid or does not exists"})
    return ({"status":"success"})
    
# Sending Response to UI
def recipe_response(recipe):
    if(recipe.id!=None):
        response = {
            'recipeKey': recipe.key,
            'name' : recipe.name,
            'deleted' : recipe.deleted,
            'isbuild' : recipe.is_build,
            'updatedAt' : str(recipe.updated_at)
        }

        return ({'status':'success','data':response})
    else:
        return ({'status':'error','message':'Some error occur while creating catalog'})
