from os import environ
from json import loads,dumps 
from strait.environment import load_env
from strait.core.model.schema import ColumnMenuSchema, TransformationSchema

# Calling Enviroment Function
load_env()

def validate_incoming_data(**kwargs):
    try:
        # Fetching Predefined Trasnformation Name
        system_admin = environ.get('SYSTEM_ADMIN',None) 
        predefined_names = []
        predefined_keys  = []
        custom_names     = []
        custom_keys      = []
        predefined_lists = TransformationSchema.objects(transformation_type='predefined', deleted=False).to_json()
        predefined_lists = list(loads(predefined_lists))
        if len(predefined_lists)>0: 
            for item in predefined_lists:
                predefined_names.append(item['name'])
                predefined_keys.append(item['key'])
        if kwargs['catalog_key'] in [system_admin]:
            pass
        else: # Custom Transformation by Catalog Key
            custom_lists = TransformationSchema.objects(transformation_type='custom', owners=kwargs['catalog_key'], deleted=False).to_json()
            custom_lists = list(loads(custom_lists))
            if len(custom_lists)>0: 
                for item in custom_lists:
                    custom_names.append(item['name'])
                    custom_keys.append(item['key'])

        if 'schema' in kwargs and kwargs['schema'] is not None:
            if len(kwargs['schema'])==0:
                return ({'status':'error','message':'schema is invalid'})
            else:
                schema = kwargs['schema']
                if 'name' not in schema and schema['name'] is None:
                    return ({'status':'error','message':'category name is required'})
                
                if 'hasSubmenu' not in schema and schema['hasSubmenu'] is None:
                    return ({'status':'error','message':'hasSubmenu is required'})
                
                if schema['hasSubmenu'] not in ['yes','no']:
                    return ({'status':'error','message':'hasSubmenu is invalid'})
                
                if schema['hasSubmenu'] in ['no']:
                    response = sub_menu_does_not_exists(category=schema,
                                                        catalog_key=kwargs['catalog_key'], 
                                                        predefined_keys=predefined_keys, 
                                                        predefined_names=predefined_names, 
                                                        custom_keys=custom_keys, 
                                                        custom_names=custom_names,
                                                        request_from=kwargs['request_from'],
                                                        system_admin=system_admin)
                    
                    if response['status'] in ['error']:
                        return response
                else:
                    if 'submenu' in schema and schema['submenu'] is not None:
                        response = sub_menu_exists(category=schema['submenu'],
                                                    catalog_key=kwargs['catalog_key'], 
                                                    predefined_keys=predefined_keys, 
                                                    predefined_names=predefined_names, 
                                                    custom_keys=custom_keys, 
                                                    custom_names=custom_names,
                                                    request_from=kwargs['request_from'],
                                                    system_admin=system_admin)
                    
                        if response['status'] in ['error']:
                            return response
                    else:
                        return ({'status':'error','message':'Submenu is required'})
                return ({'status':'success'})
        else:
            return ({'status':'error','message':'schema is required'})    
    except Exception as e:
        return ({'status': 'error', 'message': str(e)})

def sub_menu_does_not_exists(**kwargs):
    category = kwargs['category']
    predefined_names= kwargs['predefined_names']
    system_admin = kwargs['system_admin']
    predefined_keys = kwargs['predefined_keys']
    custom_keys = kwargs['custom_keys']
    custom_names = kwargs['custom_names']
    if 'key' not in category and category['key'] is None:
        return ({'status':'error','message': 'key is required'})

    if kwargs['catalog_key'] in [system_admin]: # For predefined
        if 'has_sub_menu' in kwargs and kwargs['has_sub_menu'] is not None: # For submenu skipping name check
            pass
        else: # For Category name check
            if category['name'] not in predefined_names:
                return ({'status':'error','message': str(category['name'])+' is invalid'})
        
        if category['key'] not in predefined_keys:
            return ({'status':'error','message': str(category['key'])+' is invalid'})
    else: # For custom
        # Checking whether category name is same as predefined tranformation names 
        if category['name'] in predefined_names:
            return ({'status':'error','message': str(category['name'])+' already exists'})
        
        if category['key'] not in custom_keys:
            return ({'status':'error','message': str(category['key'])+' key is invalid'})
        
        if 'has_sub_menu' in kwargs and kwargs['has_sub_menu'] is not None: # For submenu skipping name check
            pass
        else: # For Category name check
            if category['name'] not in custom_names:
                return ({'status':'error','message': str(category['name'])+' is invalid'})

            # Checking whether category name already exists or not
            #response = ColumnMenuSchema.objects(name=category['name'], owners=kwargs['catalog_key'], deleted=False).to_json()
            response = ColumnMenuSchema.objects.filter(owners=kwargs['catalog_key'],schema__name=category['name'], deleted=False).to_json() #.fields(schema={'$elemMatch': {'name': category['name']}})
            response = list(loads(response))
            if len(response)>0: 
                if 'request_from' in kwargs and kwargs['request_from'] is not None:
                    if kwargs['request_from'] in ['update']:
                        if response[0]['_id']['$oid'] != kwargs['column_id']:
                            return ({'status':'error','message':'Category name already exists'})
                    else:
                        return ({'status':'error','message':'Category name already exists'})
    return ({'status':'success'})

def sub_menu_exists(**kwargs):
    category = kwargs['category']
    predefined_names= kwargs['predefined_names']
    system_admin = kwargs['system_admin']
    predefined_keys = kwargs['predefined_keys']
    custom_keys = kwargs['custom_keys']
    custom_names = kwargs['custom_names']
    if len(category)>0:
        for sub_category in category:
            if 'name' not in sub_category and sub_category['name'] is None:
                return ({'status':'error','message':'category name is required'})
            
            if 'hasSubmenu' not in sub_category and sub_category['hasSubmenu'] is None:
                return ({'status':'error','message':'hasSubmenu is required'})
            
            if sub_category['hasSubmenu'] not in ['yes','no']:
                return ({'status':'error','message':'hasSubmenu is invalid'})
            
            if sub_category['hasSubmenu'] in ['no']:
                response = sub_menu_does_not_exists(category=sub_category,
                                                    catalog_key=kwargs['catalog_key'], 
                                                    predefined_keys=predefined_keys, 
                                                    predefined_names=predefined_names, 
                                                    custom_keys=custom_keys, 
                                                    custom_names=custom_names,
                                                    request_from=kwargs['request_from'],
                                                    system_admin=system_admin,
                                                    has_sub_menu="yes")
                if response['status'] in ['error']:
                    return response
            else:
                if 'submenu' in sub_category and sub_category['submenu'] is not None:
                    response = sub_menu_exists(category=sub_category['submenu'],
                                               catalog_key=kwargs['catalog_key'], 
                                               predefined_keys=predefined_keys, 
                                               predefined_names=predefined_names, 
                                               custom_keys=custom_keys, 
                                               custom_names=custom_names,
                                               request_from=kwargs['request_from'],
                                               system_admin=system_admin)
                    if response['status'] in ['error']:
                        return response
                else:
                    return ({'status':'error','message':'Submenu is required'})
        return ({'status':"success"})
    else:
        return ({'status':'error','message':'Submenu is invalid'})

def validate_column_menu(**kwargs):
    try:
        if 'column_id' in kwargs and kwargs['column_id'] is not None:
            response = ColumnMenuSchema.objects(id=kwargs['column_id'],deleted=False).to_json()
            response = list(loads(response))
            if len(response)==0:
                return ({'status':"error",'message':"Column id is invalid"})
            else:
                return ({'status':"success",'data':response[0]})
    except Exception as e:
        return ({'status': 'error', 'message': str(e)})