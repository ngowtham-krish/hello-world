import time
from json import loads
from bson import ObjectId
from datetime import datetime
from os import path, getcwd, environ
from strait.core.model.schema import HistorySchema
import strait.core.helper.dataset_helper as dataset_helper

class History:
    def __init__(self, catalog_key=None,project_key=None,dataset_key=None,recipe_key=None):
        if catalog_key is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API    
            self.catalog_key = catalog_key
        
        if project_key is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API    
            self.project_key = project_key
        
        if dataset_key is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API    
            self.dataset_key = dataset_key

        if recipe_key is None: # For Notebook or Custom Recipe
            self.recipe_key = environ.get('RECIPE_KEY',None) 
        else: # For API   
            self.recipe_key = recipe_key
        
        self.history_schema = HistorySchema
    
    def create(self, **kwargs):
        try:
            print("------------inside history create -------------------------")
            if 'data_frame' not in kwargs['parameters']['schema']:
                return ({'status':'error','message':'Missing required parameters'})

            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None:
                print("------- Inside catalog_key project_key ---------------------------")
                # First checking whether history is empty or not based on recipe_key & dataset_key
                history_details = self.history_schema.objects(recipe_key = self.recipe_key, source_key = self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted= False).to_json()
                history_details = list(loads(history_details)) 
                # Storing history list length
                history_len = len(history_details)
                print("----------------- history_len-------------------")
                print(history_len)
                if history_len>0: # If it has the records
                    history_ids = []
                    active_count= 0
                    temp = 1
                    temp_history_len = 0
                    # Fetching the active index from history list
                    for item in history_details:
                        active_count = active_count + 1
                        if item['active']:
                            break
                        else:
                            temp_history_len += 1
                    
                    if temp_history_len != history_len:
                        # Storing historyId after active index if any records is there in history lists
                        for item in history_details:
                            if (temp > active_count):
                                history_ids.append(item['_id']['$oid']) 
                            temp = temp + 1
                    else:
                        # Storing historyId after active index if any records is there in history lists
                        for item in history_details:
                            history_ids.append(item['_id']['$oid']) 
                        
                    # Deleting historyId after active index to store new active index
                    if len(history_ids)>0:
                        for ids in history_ids:
                            # Updating deleted status as True based on historyId
                            history_obj = self.history_schema.objects(id=ObjectId(ids),deleted=False).modify(
                                new=True,
                                set__deleted = True,
                                set__updated_at = datetime.now()
                            )
                        
                    update_history = self.history_schema.objects(recipe_key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted= False).update(set__active=False)
                
                print("--------------------------------- after if of history len ---------------------------")
                timestamp    = int(round(time.time() * 1000))
                base_path = environ.get('STORAGE',None)
                file_name = kwargs['parameters']['transformation_key'] + "_" + str(timestamp) + ".csv"
                print("--------------------------------- target file_name ---------------------------")
                print(file_name)
                dataset_dir = path.join(base_path,self.catalog_key,self.project_key,'datasets',self.dataset_key, "history", file_name)
                transform_dataframe = kwargs['parameters']['schema']['data_frame']
                
                # Removing data frame from schema 
                kwargs['parameters']['schema'].pop('data_frame', None)
                
                # Removing preview column name from schema
                if 'preview_column_name' in kwargs['parameters']['schema'] and kwargs['parameters']['schema']['preview_column_name'] is not None:
                    kwargs['parameters']['schema'].pop('preview_column_name', None)
                print("------------------------------ parameters ----------------------")
                print(kwargs['parameters'])
                # Converting the data frame to CSV
                data_frame_to_csv   = transform_dataframe.to_csv(index=False)
                
                # Generating the target file
                fh = open(dataset_dir, "w")
                fh.write(data_frame_to_csv)
                fh.close()
                print("---------------CSV File write successfully --------------------------")

                history     = self.history_schema(recipe_key = self.recipe_key, operation = kwargs["parameters"], source_key = [self.dataset_key], target_name = file_name, active=True,sampling=kwargs['sampling'],project_key=self.project_key,catalog_key=self.catalog_key).save()
                print("------------------ history id ----------------")
                print(str(history.id))
                print("--------- Preparing Metadata ---------------------")
                # Preparing Metadata
                arguments = {
                    'catalog_key': self.catalog_key,
                    'project_key': self.project_key,
                    'dataset_key': self.dataset_key,
                    'recipe_key': self.recipe_key
                }
                print("--------- arguments for Metadata ---------------------")
                print(arguments)
                if kwargs['parameters']['transformation_level'] in ['entire_dataset']:
                    resp = dataset_helper.store_whole_meta(arguments)  
                else:
                    if kwargs['parameters']['transformation_key'] in ['remove_column','trim_consecutive_whitespace','move_column']:
                        pass
                    else:
                        if 'original_df_columns' in kwargs['parameters'] and kwargs['parameters']['original_df_columns'] is not None:
                            transform_df_columns = list(transform_dataframe.columns)
                            print("--- original_df_columns ------")
                            print(kwargs['parameters']['original_df_columns'])
                            print("---- transform_df_columns ------")
                            print(transform_df_columns)
                            if len(kwargs['parameters']['original_df_columns'])!=len(transform_df_columns):
                                print("Inside if of original_df_columns")
                                temp = []
                                for item in transform_df_columns:
                                    print("item ",item)
                                    if item not in kwargs['parameters']['original_df_columns']:
                                        temp.append(item)
                                        print("--- After append transform_df_columns")
                                        print(temp)
                                print("---- Filter transform_df_columns ----")
                                print(temp)
                                for item in temp:
                                    resp = dataset_helper.store_column_meta(arguments,item)
                            else:
                                print("Inside else of original_df_columns ",kwargs['parameters']['schema']['column_name'])
                                if kwargs['parameters']['transformation_key'] in ['rename_column']:
                                    resp = dataset_helper.store_column_meta(arguments,kwargs['parameters']['schema']['new_column_name'])
                                else:
                                    resp = dataset_helper.store_column_meta(arguments,kwargs['parameters']['schema']['column_name'])  
                print("--------- After Preparing Metadata ---------------------")
                return ({"status": "success", "historyId": str(history.id),'data_frame':transform_dataframe})
            else:
                return ({"status":"error","message":"Required parameter is missing"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    def lists(self):
        try:
            if self.recipe_key is not None and self.dataset_key is not None and self.project_key is not None and self.catalog_key is not None:       
                history_details = self.history_schema.objects(recipe_key = self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key,deleted= False).to_json()
                history_details = loads(history_details) 
                if len(history_details)>0:
                    history_lists = []
                    column_name_not_req = ['remove_rows','edit_cell']
                    for item in history_details:
                        temp_history = {
                            "historyId" : str(item['_id']['$oid']),
                            "catalogKey": item['catalog_key'],
                            "projectKey": item['project_key'],
                            "datasetKey": item['source_key'],
                            "recipeKey" : item['recipe_key'],
                            "schema": None,
                            "transformationId": None,
                            "transformationKey": None,
                            "message":"",
                            "updatedAt" : datetime.utcfromtimestamp(int(item['updated_at']['$date'])/1000).strftime('%Y-%m-%d %H:%M:%S'),
                            "active" : item['active']
                        }
                        if 'schema' in item['operation']:
                            temp_history['schema'] = item['operation']['schema']
                        else:
                            temp_history['schema'] = item['operation']
                        
                        if 'transformation_id' in item['operation']:
                            temp_history['transformationId'] = item['operation']['transformation_id']
                        
                        if 'transformation_key' in item['operation']:
                            temp_history['transformationKey'] = item['operation']['transformation_key']
                        
                        if 'message' in item['operation']:
                            temp_history['message'] = item['operation']['message'],
                        
                        history_lists.append(temp_history)
                    return ({"status":"success","history_lists":history_lists})
                else:
                    return ({"status":"success","history_lists":[]})
            else:
                return ({"status":"error","message":"Missing required parameters"})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    def undo_redo(self,**kwargs):
        try:
            if kwargs['history_id'] is not None and kwargs['history_id']!='':
                print("history_id ",kwargs['history_id']," recipe_key ",self.recipe_key," project_key ",self.project_key," catalog_key ",self.catalog_key)
                history_id = kwargs['history_id']
                # Checking whether historyId exists or not
                history_resp = self.history_schema.objects(id=ObjectId(history_id), recipe_key=self.recipe_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).to_json()
                history_resp = list(loads(history_resp))
                print("------------- history_resp --------------")
                print(history_resp)
                if len(history_resp)>0:
                    history_list = self.history_schema.objects(recipe_key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).to_json()
                    history_list = list(loads(history_list))
                    history_len  = len(history_list)
                    if (history_len > 0):
                        # Updating active as false
                        history_obj  = self.history_schema.objects(recipe_key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).update(
                            set__active = False,
                            set__updated_at = datetime.now()
                        )
                        
                        # Updating active status as True based on historyId
                        history_obj = self.history_schema.objects(id=ObjectId(history_id), source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).modify(
                            new=True,
                            set__active = True,
                            set__updated_at = datetime.now()
                        )
                        arguments = {
                            'catalog_key': self.catalog_key,
                            'project_key': self.project_key,
                            'dataset_key': self.dataset_key,
                            'recipe_key': self.recipe_key
                        }
                        print("----------------- Metadata arguments -----------------")
                        print(arguments)
                        resp = dataset_helper.store_whole_meta(arguments)
                        return ({'status':"success",'message':'Updated successfully'})
                    else:
                        return ({'status':'error','message':'no step to perform undo/redo operation'})
                else:
                    return ({'status':'error','message':'history id is invalid or does not exists'})
            else:
                print("Else of undo redo --------------")
                history_list = self.history_schema.objects(recipe_key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key,deleted=False).to_json()
                history_list = list(loads(history_list))
                history_len  = len(history_list)
                print("------------- history_resp --------------")
                print(history_list)
                if history_len > 0:
                    # Updating active as false
                    history_obj  = self.history_schema.objects(recipe_key=self.recipe_key, source_key=self.dataset_key, project_key=self.project_key, catalog_key=self.catalog_key, deleted=False).update(
                        set__active = False,
                        set__updated_at = datetime.now()
                    )
                arguments = {
                    'catalog_key': self.catalog_key,
                    'project_key': self.project_key,
                    'dataset_key': self.dataset_key,
                    'recipe_key': self.recipe_key
                }
                print("----------------- Metadata arguments -----------------")
                print(arguments)
                resp = dataset_helper.store_whole_meta(arguments)
                return ({'status':"success",'message':'Updated successfully'})
        except Exception as e:
            return ({'status':"error",'message':str(e)})
    
    def delete(self,history_id, remove_all_below=False):
        try:
            # Checking whether historyId exists or not
            history_resp = self.history_schema.objects(id=ObjectId(history_id),recipe_key=self.recipe_key,project_key=self.project_key,deleted=False).to_json()
            history_resp = list(loads(history_resp))
            if len(history_resp)>0:
                # Checking whether deleting historyId is active or not
                if history_resp[0]['active']:
                    lists_resp = self.lists()
                    history_lists = lists_resp['history_lists']
                    history_ids = []
                    prev_hist_id= None 
                    for item in history_lists:
                        history_ids.append(item['historyId'])
                    list_index = history_ids.index(history_id)
                    if list_index!=0:
                        list_index_new = list_index - 1
                        prev_hist_id = history_ids[list_index_new]
                    
                    if prev_hist_id is not None:
                        # Updating active status as True
                        history_obj = self.history_schema.objects(id=ObjectId(prev_hist_id),project_key=self.project_key,deleted=False).modify(
                            new=True,
                            set__active = True,
                            set__updated_at = datetime.now()
                        )
                        # Removing all history below active
                        if remove_all_below:
                            removed_list = history_ids[0: list_index]
                            if len(removed_list) > 0:
                                for remove_history_id in removed_list:
                                    history_obj = self.history_schema.objects(id=ObjectId(remove_history_id),project_key=self.project_key,deleted=False).modify(
                                        new=True,
                                        set__deleted = True,
                                        set__updated_at = datetime.now()
                                    )
                    
                # Updating active status as True based on historyId
                history_obj = self.history_schema.objects(id=ObjectId(history_id),project_key=self.project_key,deleted=False).modify(
                    new=True,
                    set__deleted = True,
                    set__updated_at = datetime.now()
                )
                arguments = {
                    'catalog_key': self.catalog_key,
                    'project_key': self.project_key,
                    'dataset_key': self.dataset_key,
                    'recipe_key': self.recipe_key
                }
                print("----------------- Metadata arguments -----------------")
                print(arguments)
                resp = dataset_helper.store_whole_meta(arguments)
                return self.lists()
            else:
                return ({'status':'error','message':'historyId is invalid'})
        except Exception as e:
            return ({'status':"error",'message':str(e)})  
