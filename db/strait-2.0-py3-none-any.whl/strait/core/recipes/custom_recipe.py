import os
import shutil
import json
from flask import request, jsonify
import pandas as pd, numpy as np
from os import path,getcwd,makedirs,environ
from strait.core.model.config import *
import strait.core.dataset as dataset
import warnings
warnings.simplefilter(action = "ignore", category = FutureWarning)

class CustomRecipe:
    def __init__(self,source_ds_key=None,target_ds_key=None,recipe_key=None,project_key=None,catalog_key=None,token=None):
                self.target_ds_key = target_ds_key
                self.source_ds_key = source_ds_key
                self.recipe_key = recipe_key
                self.project_key = project_key
                self.catalog_key = catalog_key
                self.token = token
                self.base_path = environ.get('STORAGE',None)

    def recipe_content(self):
        target_ds_df = self.target_ds_key +"_df"
        source_ds_df = self.source_ds_key +"_df"
        pre_content = '\nimport strait.core.recipes.custom_recipe as recipeobj\n\n #Get dataframe from source dataset \nstraitobj = recipeobj.CustomRecipe(project_key="{}",catalog_key="{}", source_ds_key="{}",recipe_key="{}")\n\n{} = straitobj.get_dataframe()\n\n' .format(self.project_key, self.catalog_key, self.source_ds_key, self.recipe_key,source_ds_df)
        mid_content = "\n # Compute recipe outputs from inputs \n # TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe \n #Computes source dataframe into target dataframe \n{} = {} \n".format(target_ds_df,source_ds_df)
        post_content = '\n\n# Writes recipe outputs\nstraitobj.write_with_schema({})'.format(target_ds_df)
        return pre_content + mid_content + post_content 
     
    #create a json Env file and custom recipe with the pre existing content 
    def get_output(self):
        # base_path = environ.get('STORAGE',None)
        dir_path = path.join(self.base_path,self.catalog_key,self.project_key,"customrecipe",self.recipe_key)
        recipe_file_path = dir_path +"/"+ self.recipe_key +".py"
        json_env = dir_path +"/env.json"

        #create a custom recipe directory if not exists
        if not os.path.exists(dir_path):
                os.makedirs(dir_path)

        #create a json Env file if not exists
        if not os.path.exists(json_env):
            try: 
                with open(json_env, "w") as f:
                        json_data = '{"source_ds_key":"%s","target_ds_key":"%s","project_key": "%s","catalog_key": "%s","token" : "%s","recipe_key":"%s"}' %(self.source_ds_key,self.target_ds_key,self.project_key,self.catalog_key,self.token,self.recipe_key)
                        f.write(json_data)         
                       # print("ENV.json file created succesfully") 
            except Exception as e:
                print ("Unable to create file",e)   

        #create a custom recipe file if not exists
        if not os.path.exists(recipe_file_path):
            try: 
                #with open(custom_path) as f:
                with open(recipe_file_path, "w") as f1: 
                        #for line in f:
                            #f1.write(line)
                        if self.source_ds_key != None:
                            reciepe_content = self.recipe_content()
                            f1.write(reciepe_content)
                            print ("Recipe file created successfully")
                with open(recipe_file_path) as f2:       
                    contents =f2.read()
                    return contents
            except Exception as e:
                return jsonify({"status": "error", "message": "unable to create custom recipefile"})      
        else:
             return jsonify({"status": "error", "message": "file already available"})

    #Get the entire content available in the custom recipe file
    def get_preview_content(self):
        try:
            pyfile = self.recipe_key +".py"
            dir_path = path.join(self.base_path,self.catalog_key,self.project_key,"customrecipe",self.recipe_key)
            file_path = dir_path + "/" + pyfile
            if os.path.exists(dir_path):
                try:
                    with open(file_path, 'r') as file:
                        data = file.read()#.replace('\n', '')
                        return data
                except Exception as e:
                    print ("Exception found in get_preview_content function ",e)
            else:
                 return jsonify({"status": "error", "message": "file not found"})       

        except Exception as e:
            print ("Exception found in get_preview_content function",e)
            return jsonify({"status": "error", "message": "Unable to Preview file check exception"})

    #Update the entire content in the custom recipe file
    def updt_recipe_content(self,recipecontent):
        try:
            pyfile = self.recipe_key +".py"
            dir_path = path.join(self.base_path,self.catalog_key,self.project_key,"customrecipe",self.recipe_key)
            file_path = dir_path + "/" + pyfile
            if os.path.exists(dir_path):
                try:
                    with open(file_path, "w+")as output:
                        output.write(recipecontent)
                        return jsonify({"status": "updated", "message": "Recipe updated successfully"})
                except Exception as e:
                    print ("exception found in updt_recipe_content",e)
                    return jsonify({"status": "error", "message": "file not found"})

        except Exception as e:
            print ("exception2 found in updt_recipe_content",e)
            return jsonify({"status": "error", "message": "Unable to update file check exception"})       

    #get_dataframe function will use as a background functionalities will not visible on the custom recipe file
    def get_dataframe(self):
        try:
            from strait.core.recipe import Recipe
            data = {
            "reqest_from": "api"
           }
            
            recipeObj = Recipe(self.catalog_key, self.project_key ,self.recipe_key,self.source_ds_key)
            recipeinfo = recipeObj.get_recipe_info(data)
            catalog_key = recipeinfo["catalogKey"]
            project_Key = recipeinfo["projectKey"]
            source_ds_key=recipeinfo["sourceKey"]
            dir_path = path.join(self.base_path,catalog_key,project_Key,"customrecipe",self.recipe_key)        
            json_env = dir_path +"/env.json"
            print("DDDD ", recipeinfo)
            with open(json_env, 'r') as data_env:
                keys = json.load(data_env)
                env_catalogKey = keys["catalog_key"]
                env_projectKey = keys["project_key"]
                #env_token = keys["token"]
                if (env_catalogKey == catalog_key and project_Key == env_projectKey):
                    try:
                        df = dataset.Dataset(catalog_key,project_Key,source_ds_key)
                        data_frame = df.get_dataframe()
                        print(data_frame)
                        # Checking whether it is data frame or not
                        try:
                            if data_frame.columns.tolist():
                                pass
                        except Exception as e:
                            print("in dataframe",e)
                            return jsonify({'status': 'error', 'message': "data frame is invalid"})
                        return data_frame
                    except Exception as e:
                        print("in dataframe issue",e)
                        return jsonify({"status": "error", "message": "dataframe issue"})
                else:
                     return jsonify({"status": "error", "message": "keys are mismatch"})            
                         
        except: 
            return jsonify({"status": "error", "message": "Unable to generate dataframe"})         
        
    
    #write_with_schema function will use as a background functionalities will not visible on the custom recipe file
    def write_with_schema(self,df_data):
        ## print("Dataframe Write ")
        print("Write with Schema", df_data)
        try:
            from strait.core.recipe import Recipe
            data = {
            "reqest_from": "api"
           }
               
            recipeObj = Recipe(self.catalog_key, self.project_key ,self.recipe_key,self.source_ds_key)
            recipeinfo = recipeObj.get_recipe_info(data)
            catalog_key = recipeinfo["catalogKey"]
            project_Key = recipeinfo["projectKey"]
           
            #sourcedataset_key=recipeinfo["sourceKey"]
            
            dir_path = path.join(self.base_path,catalog_key,project_Key,"customrecipe",self.recipe_key)
            #dir_path = getcwd()
            json_env = dir_path + "/env.json"
            with open(json_env, 'r') as data_env:
                keys = json.load(data_env)
                env_catalogKey = keys["catalog_key"]
                env_projectKey = keys["project_key"]
                env_target_ds_key = keys["target_ds_key"]
                env_token = keys["token"]
                
                if (env_catalogKey == catalog_key and project_Key == env_projectKey):
                    dataframe_Data = df_data
                    datasetObj = dataset.Dataset(env_catalogKey, env_projectKey, env_target_ds_key)
                    try: 
                        source = {
                                        "file": dataframe_Data,
                                        "token": env_token,
                                        "source_type":"custom"
                                }
                        
                        datasetResponse = datasetObj.update(source=source)
                        print(datasetResponse)
                        return "Successfully Built, Check your dataset lists"
                    except Exception as e:
                        print(e)
                        return str(e) 
                else:
                    print("key not match")
                    return "key doest not match"         
        except Exception as e:
            print ("exception found",e)
            return str(e)


#v8