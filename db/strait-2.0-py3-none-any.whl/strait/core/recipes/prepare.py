import numpy as np
import pandas as pd
import re, copy, dateutil
from datetime import datetime 
from operator import itemgetter
from difflib import get_close_matches
from strait.core.recipes.filter import remove_filter
import strait.core.helper.wrangling_helper as wrangling_helper
from strait.core.helper.metadata import typeof
pd.set_option('display.max_columns', 500)

class Prepare:
    
    #done
    def uppercase(self,data_frame=None,col=None,request_from='notebook'):
        """ This method perform uppercase operation which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='uppercase',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']

            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: str(x).upper()).tolist()
                data_frame[col].replace([None,'Nan','nan','none','NONE','None','NAN','NaN'], '', regex=True, inplace=True)
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: str(x).upper()).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=new_col)
                data_frame['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    #done
    def lowercase(self,data_frame=None,col=None,request_from='notebook'):
        """ This method perform lowercase operation which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='lowercase',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']

            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: str(x).lower()).tolist()
                data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: str(x).lower()).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=new_col)
                data_frame['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def titlecase(self,data_frame=None,col=None,request_from='notebook'):    
        """ This method perform titlecase operation which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='titlecase',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']

            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: str(x).title()).tolist()
                data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: str(x).title()).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=new_col)
                data_frame['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def to_null(self,data_frame=None,col=None,request_from='notebook'):  
        """ This method perform to_null operation which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_null',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']

            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: None).tolist()
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: None).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=new_col)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def to_empty(self,data_frame=None,col=None,request_from='notebook'):
        """ This method perform to_empty operation which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_empty',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']

            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: "").tolist()
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: "").tolist()
                data_frame.insert(loc=idx+1, column= '__preview__', value=new_col)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def to_trim(self,data_frame=None,col=None,request_from='notebook'):    
        """ This method perform to_trim operation which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_trim',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: str(x).lstrip()).tolist()
                data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: str(x).lstrip()).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=new_col)
                data_frame['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def fill_empty_cells(self,data_frame=None,col=None,replace_with=None,operation_type=None,fill_with=None,request_from='notebook'):
        """ This method perform fill empty cells operation which require data_frame and column_name as a required parameters and operation_type can be mean,median,mode and replace. If replace is passed as operation_type then fill_with will be required parameters"""
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='fill_empty_cells',operation_type=operation_type,fill_with=fill_with,column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            data = data_frame
            idx  = data.columns.get_loc(col)
            if operation_type == "replace": 
                if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                    if replace_with == 'null':
                        data[col].fillna(fill_with,inplace=True).tolist()
                    elif replace_with == 'empty':
                        data[col].replace(r'^\s*$', fill_with, regex=True, inplace=True)
                    elif replace_with == 'both':
                        # print("Replace with Both ", data)
                        # print("Column Name ", col)
                        data[col].replace(r'^\s*$', np.nan, regex=True, inplace=True)
                        data[col].fillna(fill_with,inplace=True)
                else: # For Wrangling/UI
                    try:
                        if replace_with == 'null':
                            new_col = data[col].fillna(fill_with,inplace=False)
                        elif replace_with == 'empty':
                            new_col = data[col].replace(r'^\s*$', fill_with, regex=True, inplace=False)
                        elif replace_with == 'both':
                            data[col].replace(r'^\s*$', np.nan, regex=True,inplace =True)
                            new_col = data[col].fillna(fill_with,inplace=False)
                        data.insert(loc=idx+1, column='__preview__', value=new_col)
                    except Exception as e:
                        return ({'status': 'error', 'message': str(e)})
            elif operation_type == "mean":
                data[col].replace(r'^\s*$', np.nan, regex=True)
                data[col] = pd.to_numeric(data[col])
                if request_from in ['notebook', 'run_recipe']:  # For Run Recipe and Notebook
                    data[col] = data[col].fillna(round(data[col].mean(),2), inplace=False).tolist()
                else:  # For Wrangling/UI
                    try:
                        new_col = data[col].fillna(round(data[col].mean(),2), inplace=False).tolist()
                        data.insert(loc=idx + 1, column='__preview__', value=new_col)
                    except Exception as e:
                        return ({'status': 'error', 'message': str(e)})
            elif operation_type == "mode":
                print("Inside ",operation_type)
                data[col].replace(r'^\s*$', np.nan, regex=True)
                try:
                    data[col] = pd.to_numeric(data[col])
                except:
                    pass
                if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                    data[col]=data[col].fillna(data[col].mode()[0],inplace=False).tolist()
                else: # For Wrangling/UI 
                    try:
                        print("Inside mode ",col)
                        print(data)
                        new_col = data[col].fillna(data[col].mode()[0],inplace=False).tolist()
                        print(new_col)
                        data.insert(loc=idx+1, column='__preview__', value=new_col)
                    except Exception as e:
                        return ({'status': 'error', 'message': str(e)})                                
            elif operation_type == "median":
                data[col].replace(r'^\s*$', np.nan, regex=True)
                data[col] = pd.to_numeric(data[col])
                if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                    data[col] = data[col].fillna(data[col].median(),inplace=False).tolist()
                else: # For Wrangling/UI 
                    try:
                        new_col = data[col].fillna(data[col].median(),inplace=False).tolist()
                        data.insert(loc=idx+1, column='__preview__', value=new_col)
                    except Exception as e:
                        return ({'status': 'error', 'message': str(e)}) 

            if request_from in ['notebook','run_recipe']:
                # Replacing any none and nan with blank
                data[col].replace([None,'Nan','nan','none','NONE','NAN','NaN'], '', regex=True, inplace=True)
                return data
            else:
                # Replacing any none and nan with blank
                data['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN'], '', regex=True, inplace=True)
                return ({'status':'success','data_frame':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def rename_column(self,data_frame=None,old_col_name=None, new_col_name=None,request_from='notebook'):    
        """ This method perform renaming a column which require data_frame, column_name and new_column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=old_col_name,new_col_name=new_col_name,request_from='rename_column',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            data = data_frame.rename(columns = {old_col_name:new_col_name})
            if request_from in ['notebook','run_recipe']:
                return data
            else:
                return ({'status': 'success', 'data_frame': data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def remove_column(self,data_frame=None,col=None,request_from='notebook'):    
        """ This method perform remove column which require data_frame and column_name as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='remove_column',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            print(data_frame[col], col, request_from)
            data_frame = data_frame.drop(col, axis=1, inplace=False)
            print("Final ", data_frame)
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            print("Error ",e)
            return ({'status': 'error', 'message': str(e)})

    #done
    def trim_consecutive_whitespace(self,data_frame=None,col=None,delimiter = ' ',request_from='notebook'): # by default delimiter should be space
        """ This method perform triming consecutive whitespace which require data_frame and column_name as a required parameters and along with delimiter. If delimiter is not specified then space will be default delimiter"""
        try: 
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='trim_consecutive_whitespace',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col] = data_frame[col].apply(lambda x: delimiter.join(str(x).split())).tolist()
                # Replacing any none and nan with blank
                data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return data_frame
            else: # For Wrangling/UI 
                idx = data_frame.columns.get_loc(col)    
                new_col = data_frame[col].apply(lambda x: delimiter.join(str(x).split())).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=new_col)
                # Replacing any none and nan with blank
                data_frame['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return ({'status': 'success', 'data_frame': data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def split_column(self,data_frame=None,col=None,mode=None,max_split=None,delimiter=None,length=None,remove=False,request_from='notebook'):
        """ This method perform split column which require data_frame, column_name, mode as a required parameters, mode can be separator or field_length. mode can be separator and field_length. If separator is passed as mode then delimiter is required. If field_length is passed as mode then length is required. max split and remove orignal column (default is false) is optional"""
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,mode=mode,max_split=max_split,delimiter=delimiter,length=length,remove=remove,request_from='split_column',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']

            data= data_frame
            idx = data.columns.get_loc(col)
            if mode!=None and mode == 'separator': # Split by Separator
                if delimiter == ".":
                    delimiter = "\."
                if delimiter == " ":
                    delimiter = "\s"
                new_col = data[col].apply(lambda x: re.split(delimiter, str(x)))
                max_splits = max(map(len, new_col))
            else: # Split by Length
                length = int(length)
                new_col = data[col].apply(lambda x:[str(x)[i:i+length] for i in range(0,len(str(x)),length) if str(x)!="nan"])
                max_splits = max(map(len, new_col))
            index = ["{}_{}".format(col,i+1) for i in range(0,int(max_splits))]
            data_frame = pd.DataFrame(new_col.values.tolist(), index= data.index)
            data_frame.columns = index
            data_frame = data_frame.replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True)
            if max_split is None:
                split_max_count = len(data_frame.columns)
            else:
                max_split = int(max_split)
                # Checking if max split which user supplied is greater then actual split or not
                if (max_split >= len(data_frame.columns)):
                    split_max_count = len(data_frame.columns)
                else:
                    split_dataframe = data_frame.loc[ :,"{}_{}".format(col,str(max_split+1)):]
                    data_frame=data_frame.loc[:,:"{}_{}".format(col,str(max_split))]
                    data_frame = data_frame.astype(str)
                    split_dataframe = split_dataframe.astype(str)
                    data_frame["{}_{}".format(col,max_split)] = data_frame["{}_{}".format(col,str(max_split))].str.cat(split_dataframe, sep="")
                    split_max_count = max_split
            for i in range(0,split_max_count):
                # Index means split column name and data_frame means respective column value
                data.insert(idx+i+1, index[i], data_frame[index[i]])
            if remove==True:
                data.drop(col,axis=1,inplace = True)
            print("new", data)
            if request_from in ['notebook','run_recipe']:
                return data
            else:
                return ({'status':'success','data_frame':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def find_replace(self, data_frame=None,col=None, find=None, replace=None,request_from='notebook'):
        """ This method perform find replace which require data_frame, column_name, find and replace as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,find=find, replace=replace,request_from='find_replace',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            try:
                replace = eval(replace)
            except:
                pass
            try:
                find = eval(find) 
            except:
                pass

            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                data_frame[col].replace(r'^\s*$', np.nan, regex=True)
                data_frame[col] = data_frame[col].apply(lambda x: replace if  find == x or str(find) == x else x)
                # Replacing any none and nan with blank
                data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return data_frame
            else: # For Wrangling/UI
                data_frame[col].replace(r'^\s*$', np.nan, regex=True)
                idx = data_frame.columns.get_loc(col)
                new_col = data_frame[col].apply(lambda x: replace if  find == x or str(find) == x else x)
                data_frame.insert(loc=idx+1, column="__preview__", value=new_col)
                # Replacing any none and nan with blank
                data_frame['__preview__'].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
   
    #later
    def clustering(self,data_frame=None,col=None,request_from='notebook'):
        try: 
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='clustering',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
               
            clustering_data = []
            prepare_data = []
            data = data_frame
            patterns = data[col].unique().tolist()
            patterns = [x for x in patterns if str(x) != 'nan']        
            pattern_count = data[col].value_counts().to_dict()
            while True:           
                word = patterns[0]            
                get_close_matches(word, patterns)
                if not get_close_matches(word, patterns):
                    patterns=patterns.pop(0)
                else:
                    prepare_data.append(get_close_matches(word, patterns))    
                    patterns=list(set(patterns) - set(get_close_matches(word, patterns)))
                if not patterns:
                    break
            
            for i in range(len(prepare_data)):
                dictionary = {}
                words=[]
                value = []
                for i in prepare_data[i]:
                    words.append(i)
                    value.append(pattern_count[i])            
                appropiate_value = words[value.index(max(value))]
                #values = list(zip(words,value))            
                rows = sum(value)
                if len(value)>1:
                    dictionary['row_count']=rows
                    dictionary['cluster_size'] = len(words)
                    dictionary['words'] = words
                    dictionary['values'] = value
                    dictionary['appropiate_value']=appropiate_value
                    clustering_data.append(dictionary)            
            return clustering_data
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #later
    def mass_edit(self,data_frame=None,col=None, data=None, request_from='notebook'):
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,data=data,request_from='mass_edit',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            if request_from in ['notebook','run_recipe']: # For Run Recipe and Notebook
                for item in data:
                    data_frame[col] = data_frame[col].apply(lambda x: item['replace'] if x in item['find'] else x)
                return data_frame
            else: # For Wrangling/UI
                idx = data_frame.columns.get_loc(col)
                temp_frame = copy.deepcopy(data_frame)
                for item in data:
                    temp_frame[col] = temp_frame[col].apply(lambda x: item['replace'] if x in item['find'] else x).tolist()
                data_frame.insert(loc=idx+1, column='__preview__', value=temp_frame[col])
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def move_column(self,data_frame=None,col=None,index=None,request_from='notebook'):
        """ This method perform move column which require data_frame, column_name and index as a required parameters. index should be either of this 'left','right','begining','end' """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,index=index,request_from='move_column',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            data = data_frame
            idx = data.columns.get_loc(col)
            if index == 'left':
                if idx==0:
                    if request_from=='notebook':
                        return ('cannot move '+str(col)+' column to left')
                    else:    
                        return ({'status':'error','message':'cannot move '+str(col)+' column to left'})
                source_column=data[col].tolist()
                data.drop(col, axis=1, inplace=True)
                data.insert(loc=idx-1, column= col, value=source_column)
            elif index == 'right':
                column_index = data.shape[1]-1
                if idx==column_index:
                    if request_from=='notebook':
                        return ('cannot move '+str(col)+' column to right')
                    else:
                        return ({'status':'error','message':'cannot move '+str(col)+' column to right'})
                source_column =data[col].tolist()
                data.drop(col, axis=1, inplace=True)
                data.insert(loc=idx+1, column= col, value=source_column)
            elif index == 'begining':
                if idx==0:
                    if request_from=='notebook':
                        return (str(col)+' column is already at the begining')
                    else:    
                        return ({'status':'error','message':str(col)+' column is already at the begining'})
                source_column=data[col].tolist()
                data.drop(col, axis=1, inplace=True)
                data.insert(loc=0, column= col, value=source_column)
            elif index == 'end':
                column_index = data.shape[1]-1
                if idx==column_index:
                    if request_from=='notebook':
                        return (str(col)+' column is already at the end')
                    else:
                        return ({'status':'error','message': str(col)+' column is already at the end'})
                source_column=data[col].tolist()
                data.drop(col, axis=1, inplace=True)
                data.insert(loc=data.shape[1],column= col, value=source_column)
            
            if request_from in ['notebook','run_recipe']:
                return data
            else:
                return ({'status':'success','data_frame':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    #done
    def edit_cell(self,data_frame=None,row_index=None,column_index=None,value=None,request_from='notebook'):
        """ This method perform edit cell which require data_frame, row index, column index and value as a required parameters """
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,row_index=row_index,column_index=column_index,request_from='edit_cell',column_name_required=False)
                if validate_data['status']=='error':
                    return validate_data['message']
            
            data_frame.iloc[[row_index],[column_index]] = value
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})   

    #done
    def to_string(self,data_frame=None,col=None,request_from='notebook'):    
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_string',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            data_frame[col] = data_frame[col].apply(lambda x: '{}  '.format(str(x)))
            #data_frame[col] = data_frame[col].apply(lambda x: str(x))
            data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','None','NaN','None'], '', regex=True, inplace=True)
            data_frame[col].replace(r'^\s*$', "", regex=True, inplace=True)
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})   
        
    #done
    def to_int(self,data_frame=None,col=None,request_from='notebook'):    
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_int',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            try:
                data_frame[col] = data_frame[col].apply(
                    lambda x: x.strip())
            except:
                pass
            if data_frame[col].isnull().values.any():
                data_frame[col] = data_frame[col].fillna("str")
                data_frame[col] = data_frame[col].apply(lambda x: round(int(float(x))) if typeof(x) in ['integer','decimal'] else x)
            else:
                data_frame[col] = data_frame[col].apply(
                    lambda x: round(int(float(x))) if typeof(x) in ['integer', 'decimal'] else x)
            data_frame[col] = data_frame[col].astype(str)
            data_frame[col] = data_frame[col].replace('str', np.nan)
            data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})   
    
    #done
    def to_float(self,data_frame=None,col=None,request_from='notebook'):    
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_float',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            try:
                data_frame[col] = data_frame[col].apply(
                    lambda x: x.strip())
            except:
                pass
            data_frame[col] = data_frame[col].apply(lambda x: float(x) if typeof(x) in ['integer','decimal'] else x)
            data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN','None'], '', regex=True, inplace=True)
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})      
        
    #done
    def to_date(self,data_frame=None,col=None,date_format = None,request_from='notebook'):
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,request_from='to_date',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            data_frame[col] = data_frame[col].apply(lambda x:str(x))
            data_frame[col] = data_frame[col].apply(dateutil.parser.parse)
            if date_format == "dd-mm-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%m-%Y"))
            elif date_format == "dd-shortMon-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%b-%Y"))
            elif date_format == "dd-month-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%B-%Y"))
            elif date_format == "dd-mm-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%m-%y"))
            elif date_format == "dd-shortMon-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%b-%y"))
            elif date_format == "dd-month-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%B-%y"))
            elif date_format == "mm-dd-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%m-%d-%Y"))
            elif date_format == "shortMon-dd-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%b-%d-%Y"))
            elif date_format == "month-dd-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%B-%d-%Y"))
            elif date_format == "mm-dd-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%m-%d-%y"))
            elif date_format == "shortMon-dd-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%b-%d-%y"))
            elif date_format == "month-dd-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%B-%d-%y"))
            elif date_format == "yyyy-mm-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%Y-%m-%d"))
            elif date_format == "yyyy-shortMon-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%Y-%b-%d"))
            elif date_format == "yyyy-month-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%Y-%B-%d"))
            elif date_format == "yy-mm-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%y-%m-%d"))
            elif date_format == "yy-shortMon-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%y-%b-%d"))
            elif date_format == "yy-month-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%y-%B-%d"))
            elif date_format == "yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%Y"))
            elif date_format == "yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%y"))
            elif date_format == "mm-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%m-%Y"))
            elif date_format == "shortMon-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%b-%Y"))
            elif date_format == "month-yyyy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%B-%Y"))
            elif date_format == "mm-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%m-%y"))
            elif date_format == "shortMon-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%b-%y"))
            elif date_format == "month-yy":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%B-%y"))
            elif date_format == "mm-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%m-%d"))
            elif date_format == "shortMon-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%b-%d"))
            elif date_format == "month-dd":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%B-%d"))
            elif date_format == "dd-mm":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%m"))
            elif date_format == "dd-shortMon":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%b"))
            elif date_format == "dd-month":
                data_frame[col] = data_frame[col].apply(
                    lambda d: datetime.strftime(d, "%d-%B"))
            data_frame[col].replace([None,'Nan','nan','none','NONE','NAN','NaN'], '', regex=True, inplace=True)
            print(data_frame)
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def filter_rows(self, data_frame=None, filter_parameters=None, request_from='notebook'):
        try:
            if request_from == 'notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,
                                                                       parameters=filter_parameters,
                                                                       request_from='filter_rows',
                                                                       column_name_required=False)
                if validate_data['status'] == 'error':
                    return validate_data['message']
            data = remove_filter(data_frame, filter_parameters)
            if request_from in ['notebook','run_recipe']:
                return data
            else:
                if data.empty:
                    return ({'status': 'error', 'message': "Output dataframe is empty"})
                return ({'status':'success','data_frame':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})
    
    #done
    def normalize(self,data_frame=None,col=None,value=None,request_from='notebook'):
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=col,value=value,request_from='normalize',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
             
            data = data_frame
            if request_from=='notebook' or request_from=='run_recipe': # For Run Recipe and Notebook
                if value is not None:
                    data[col]=((data[col]-data[col].min())/(data[col].max()-data[col].min()))*value
                else:
                    data[col]=((data[col]-data[col].min())/(data[col].max()-data[col].min()))
            else:
                idx = data.columns.get_loc(col)   
                if value is not None:
                    new_col = ((data[col]-data[col].min())/(data[col].max()-data[col].min()))*value
                else:
                    new_col = ((data[col]-data[col].min())/(data[col].max()-data[col].min()))
                data.insert(loc=idx+1, column='__preview__', value=new_col)
            if request_from in ['notebook','run_recipe']:
                return data
            else:
                return ({'status':'success','data_frame':data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def remove_rows(self, data_frame=None, remove_parameters=None, request_from='notebook'):
        try:
            data_frame_copy = copy.deepcopy(data_frame)
            #print(data_frame['parents_temp'].head(30))
            if request_from == 'notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame_copy,parameters=remove_parameters,request_from='remove_rows',column_name_required=False)
                if validate_data['status'] == 'error':
                    return validate_data['message']
            data = remove_filter(data_frame_copy, remove_parameters)
            #print("-------------- response from remove filter ---------------------------")
            #print(data['parents_temp'].head(30))
            removed_dataframe = data_frame[~data_frame.index.isin(data.index)]
            #print(removed_dataframe.empty)
            if removed_dataframe.empty:
                return ({'status': 'error', 'message': "Output dataframe is empty"})

            if request_from in ['notebook','run_recipe']:
                return removed_dataframe
            else:
                return ({'status':'success','data_frame':removed_dataframe})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def math_operation(self,data_frame=None, column_name=None, operation=None, value=None, request_from='notebook'):
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=column_name, operation=operation,value=value,request_from='math_operation',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            col = column_name
            lists = ['addition','difference']
            if operation not in lists:
                idx = data_frame.columns.get_loc(col)
            else:
                idx = data_frame.columns.get_loc(col[-1])
            
            if operation == 'exponential':
                new_col = np.exp(data_frame[col]).tolist()
                data_frame.insert(loc=idx + 1, column=col+'_exp_value', value=new_col)
            elif operation == 'natural_logarithmic':
                new_col = np.log(data_frame[col]).tolist()
                data_frame.insert(loc=idx + 1, column=col + '_logarithmic', value=new_col)
            elif operation == 'quantile_rank':
                new_col = pd.qcut(data_frame[col],4,labels=False).tolist()
                data_frame.insert(loc=idx + 1, column=col + '_quantile', value=new_col)
            elif operation == 'decile_rank':
                new_col = pd.qcut(data_frame[col],10,labels=False).tolist()
                data_frame.insert(loc=idx + 1, column=col + '_decile', value=new_col)
            elif operation == 'raised_power':
                try:
                    new_col = np.power(data_frame[col], eval(value)).tolist()
                    data_frame.insert(loc=idx + 1, column=col + '_raised_power', value=new_col)
                except Exception as e:
                    if request_from=='notebook':
                        return (col+" column should have only numerical value")
                    else:
                        return ({'status': 'error', 'message': col+" column should have only numerical value"})
            elif operation == 'percentile ':
                new_col = data_frame[col].rank(pct=True).tolist()
                data_frame.insert(loc=idx + 1, column=col + '_percentile', value=new_col)
            elif operation == 'percentage':
                new_col = data_frame[col]/data_frame[col].sum().tolist()
                data_frame.insert(loc=idx + 1, column=col + '_percentage', value=new_col)
            elif operation == 'cumulative_sum':
                new_col = data_frame[col].cumsum().tolist()
                data_frame.insert(loc=idx + 1, column=col + '_cumsum', value=new_col)
            elif operation == 'difference':
                try:
                    sub_col = col
                    new_col = data_frame[sub_col[0]] - data_frame[sub_col[1]]
                    data_frame.insert(loc=idx + 1, column=col[-1] + '_difference', value=new_col)
                except Exception as e:
                    if request_from=='notebook':
                        return (" column should have only numerical value")
                    else:
                        return ({'status': 'error', 'message': " column should have only numerical value"})
            elif operation == 'addition':
                try:
                    sub_col = col
                    new_col = data_frame[sub_col[0]] + data_frame[sub_col[1]]
                    data_frame.insert(loc=idx + 1, column=col[-1] + '_addition', value=new_col)
                except Exception as e:
                    if request_from=='notebook':
                        return (" column should have only numerical value")
                    else:
                        return ({'status': 'error', 'message': " column should have only numerical value"})
            elif operation == 'absolute_value':
                new_col = abs(data_frame[col]).tolist()
                data_frame.insert(loc=idx + 1, column=col + '_absolute_value', value=new_col)

            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def date_range(self, data_frame=None, column_name=None, operation=None, request_from='notebook'):
        try:
            if request_from=='notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame,column_name=column_name, operation=operation,request_from='date_range',column_name_required=True)
                if validate_data['status']=='error':
                    return validate_data['message']
            cols = column_name
            try:
                idx = data_frame.columns.get_loc(cols[-1])
            except Exception as e:
                if request_from=='notebook':
                    return (str(e))
                else:    
                    return ({'status': 'error', 'message': str(e)})
            
            for col in cols:
                try:
                    data_frame[col] = data_frame[col].apply(dateutil.parser.parse)
                except Exception as e:
                   if request_from=='notebook':
                       return (str(e))
                   else:
                       return ({'status': 'error', 'message': str(e)})

            if operation == 'days':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_days', value=new_col)
                data_frame['diff_days'] = data_frame['diff_days'] / np.timedelta64(1, 'D')

            elif operation == 'weeks':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_weeks', value=new_col)
                data_frame['diff_weeks'] = data_frame['diff_weeks'] / np.timedelta64(1, 'W')

            elif operation == 'months':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_months', value=new_col)
                data_frame['diff_months'] = data_frame['diff_months'] / np.timedelta64(1, 'M')

            elif operation == 'years':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_years', value=new_col)
                data_frame['diff_years'] = data_frame['diff_years'] / np.timedelta64(1, 'Y')

            elif operation == 'timestamp_seconds':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_seconds', value=new_col)
                data_frame['diff_seconds'] = data_frame['diff_seconds'] / np.timedelta64(1, 's')

            elif operation == 'timestamp_minutes':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_minutes', value=new_col)
                data_frame['diff_minutes'] = data_frame['diff_minutes'] / np.timedelta64(1, 'm')

            elif operation == 'timestamp_hours':
                new_col = (data_frame[cols[0]] - data_frame[cols[1]]).tolist()
                data_frame.insert(loc=idx + 1, column='diff_hours', value=new_col)
                data_frame['diff_hours'] = data_frame['diff_hours'] / np.timedelta64(1, 'h')
            if request_from in ['notebook','run_recipe']:
                return data_frame
            else:
                return ({'status':'success','data_frame':data_frame})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def pivot_dataframe(self, data_frame=None, index=None, columns=None, values = None, request_from='notebook'):
        try:
            if request_from == 'notebook':
                validate_data = wrangling_helper.validate_prepare_data(data_frame=data_frame, column_name=columns,request_from='pivot_dataframe', column_name_required=True)
                if validate_data['status'] == 'error':
                    return validate_data['message']

            data = data_frame
            pivot_data = data.pivot(index=index, columns=columns, values=values)
            if request_from in ['notebook','run_recipe']:  # For Run Recipe and Notebook
                return pivot_data
            else:
                return ({'status':'success','data_frame':pivot_data})
        except Exception as e:
            return ({'status': 'error', 'message': str(e)})

    #done
    def column_imputation(self, data_frame, variables, request_from='notebook'):
        """
            params:        
                data - Data frame            
                variables - a dictionary conatining the corresponding variables as key and type of imputation (Mean / Meadian / Mode) 
                format - function(df,{'col':'Mean/Median/Mode'})
        """
        for variable in variables.keys():
            if (data_frame[variable].dtype == np.float64 or data_frame[variable].dtype == np.int64):
                method = variables.get(variable)
                if method =="Deep Learning":
                    data_frame[variable] = prepare_helper.deeplearning(data_frame,variable)
                else:
                    if request_from in ['notebook','run_recipe']:
                        return ("Type is invalid")
                    else:
                        return ({'status':'error','message':"Type is invalid"})
            elif (data_frame[variable].dtype == 'object'):
                data_frame[variable] = data_frame[variable].fillna(data_frame[variable].mode()[0])
        
        if request_from in ['notebook','run_recipe']:  # For Run Recipe and Notebook
            return data_frame
        else:
            return ({'status':'success','data_frame':data_frame})
    
    #done
    def data_imputation(self, data_frame, operation_type,dependent_variable=None,date_variable=None, request_from='notebook'):
        # Removing Dependent Variable & date variable from data frame
        #data_frame = data_frame.drop([dependent_variable,date_variable], axis=1, inplace=False)
            
        if operation_type=='Mean':
            #data_frame[variable] = data_frame[variable].fillna(data_frame[variable].mean())
            data_frame = prepare_helper.mean(data_frame,dependent_variable)
        elif operation_type=='Median':
            #data_frame[variable] = data_frame[variable].fillna(data_frame[variable].median())
            data_frame = prepare_helper.median(data_frame,dependent_variable)
        elif operation_type=='Mode':
            #data_frame[variable] = data_frame[variable].fillna(data_frame[variable].mode()[0])
            data_frame = prepare_helper.mode(data_frame,dependent_variable)
        elif operation_type =="KNN":
            #data_frame[variable] = data_frame[variable]
            data_frame = prepare_helper.knn(data_frame,dependent_variable)
        elif operation_type =="Stochastic Regression":
            #data_frame[variable] = data_frame[variable]
            data_frame = prepare_helper.stochastic(data_frame,dependent_variable)
        elif operation_type =="MICE":
            #data_frame[variable] = data_frame[variable]
            data_frame = prepare_helper.mice_trans(data_frame,dependent_variable)
        else:
            if request_from in ['notebook','run_recipe']:
                return ("Type is invalid")
            else:
                return ({'status':'error','message':"Type is invalid"})
    
        if request_from in ['notebook','run_recipe']:  # For Run Recipe and Notebook
            return data_frame
        else:
            return ({'status':'success','data_frame':data_frame})

