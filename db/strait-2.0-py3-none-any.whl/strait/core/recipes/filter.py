import copy
import pandas as pd
import numpy as np
from json import loads, dumps
import strait.core.helper.dataset_helper as dataset_helper

class Filter:

    def __init__(self, data):
        self.data = data
        self.current_history = []

    def greater_then_equal(self, col, value,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value = pd.to_datetime(value, format=date_format)
                self.current_history.append((data[col] >= value))
                data_frame = data[(data[col] >= value)]
            else: # Default
                self.current_history.append((data[col] >= value).all(axis=1))
                data_frame = data[(data[col] >= value).all(axis=1)]
        else:
            self.current_history.append((data[col] >= value).all(axis=1))
            data_frame = data[(data[col] >= value).all(axis=1)]
        self.data = data_frame
        return data_frame

    def greater_then(self, col, value,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value = pd.to_datetime(value, format=date_format)
                self.current_history.append((data[col] > value))
                data_frame = data[(data[col] > value)]
            else:
                self.current_history.append((data[col] > value).all(axis=1))
                data_frame = data[(data[col] > value).all(axis=1)]
        else:
            self.current_history.append((data[col] > value).all(axis=1))
            data_frame = data[(data[col] > value).all(axis=1)]
        self.data = data_frame
        return data_frame

    def less_then(self, col, value,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value = pd.to_datetime(value, format=date_format)
                data_frame = data[(data[col] < value)]
                self.current_history.append((data[col] < value))
            else:
                data_frame = data[(data[col] < value).all(axis=1)]
                self.current_history.append((data[col] < value).all(axis=1))
        else:
            data_frame = data[(data[col] < value).all(axis=1)]
            self.current_history.append((data[col] < value).all(axis=1))
        self.data = data_frame
        return data_frame

    def less_then_equal(self, col, value,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value = pd.to_datetime(value, format=date_format)
                data_frame = data[(data[col] <= value)]
                self.current_history.append((data[col] <= value))
            else:
                data_frame = data[(data[col] <= value).all(axis=1)]
                self.current_history.append((data[col] <= value).all(axis=1))
        else:
            data_frame = data[(data[col] <= value).all(axis=1)]
            self.current_history.append((data[col] <= value).all(axis=1))
        self.data = data_frame
        return data_frame

    def not_equal(self, col, value,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value = pd.to_datetime(value, format=date_format)
                data_frame = data[(data[col] != value)]
                self.current_history.append((data[col] != value))
            else:
                data_frame = data[(data[col] != value).all(axis=1)]
                self.current_history.append((data[col] != value).all(axis=1))
        else:
            data_frame = data[(data[col] != value).all(axis=1)]
            self.current_history.append((data[col] != value).all(axis=1))
        self.data = data_frame
        return data_frame

    def equal(self, col, value,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value = pd.to_datetime(value, format=date_format)
                data_frame = data[(data[col] == value)]
                self.current_history.append((data[col] == value))
            else:
                data_frame = data[(data[col] == value).all(axis=1)]
                self.current_history.append((data[col] == value).all(axis=1))
        else:
            data_frame = data[(data[col] == value).all(axis=1)]
            self.current_history.append((data[col] == value).all(axis=1))
        self.data = data_frame
        return data_frame

    def starts_with(self, col, string):
        data = copy.deepcopy(self.data)
        self.current_history.append(data[col].str.startswith(string, na=False))
        data_frame = data[data[col].str.startswith(string, na=False)]
        self.data = data_frame
        return data_frame

    def ends_with(self, col, string):
        data = copy.deepcopy(self.data)
        self.current_history.append(data[col].str.endswith(string, na=False))
        data_frame = data[data[col].str.endswith(string, na=False)]
        self.data = data_frame
        return data_frame

    def in_between(self, col, value1, value2,data_type=None,date_format=None):
        if data_type is not None and data_type in ['date','timestamp']:
            pass
        else:
            if type(col) != list:
                col = [col]
        data = copy.deepcopy(self.data)
        if data_type is not None and data_type in ['date','timestamp']:
            if date_format is not None:
                data[col] = pd.to_datetime(data[col], format=date_format)
                value1 = pd.to_datetime(value1, format=date_format)
                value2 = pd.to_datetime(value2, format=date_format)
                self.current_history.append((data[col] >= value1) & (data[col] <= value2))
                data_frame = data[(data[col] >= value1) & (data[col] <= value2)]
            else:
                self.current_history.append((data[col] > value1).all(axis=1) & (data[col] < value2).all(axis=1))
                data_frame = data[(data[col] > value1).all(axis=1) & (data[col] < value2).all(axis=1)]
        else:
            self.current_history.append((data[col] > value1).all(axis=1) & (data[col] < value2).all(axis=1))
            data_frame = data[(data[col] > value1).all(axis=1) & (data[col] < value2).all(axis=1)]
        self.data = data_frame
        return data_frame

    def empty_values(self, col):
        data = copy.deepcopy(self.data)
        self.current_history.append(data[col].isnull())
        data_frame = data[data[col].isnull()]
        if data_frame.empty:
            data_frame = pd.DataFrame(np.nan, index=range(0, data_frame.shape[0]), columns=data_frame.columns.tolist())
        self.data = data_frame
        return data_frame

    def remove_empty_rows(self,col):
        data_frame = copy.deepcopy(self.data)
        #data_frame[col].replace('', np.nan, inplace=True)
        data_frame[col].replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN',""], value=np.nan, inplace=True)
        data_frame.dropna(subset=[col], inplace=True)
        self.data = data_frame
        return data_frame

    # Ok values
    def ok(self, col, catalog_key, project_key, dataset_key, recipe_key=None):
        data_frame = copy.deepcopy(self.data)
        resp = dataset_helper.ok_not_ok(catalog_key=catalog_key, project_key=project_key, dataset_key=dataset_key,recipe_key=recipe_key,column_name=col,filter_for='ok',data_frame=data_frame)
        if resp['status'] in ['error']:
            return resp
        return resp['data_frame']

    
    # Not ok values
    def not_ok(self, col, catalog_key, project_key, dataset_key, recipe_key=None):
        data_frame = copy.deepcopy(self.data)
        resp = dataset_helper.ok_not_ok(catalog_key=catalog_key, project_key=project_key, dataset_key=dataset_key,recipe_key=recipe_key,column_name=col,filter_for='not_ok',data_frame=data_frame)
        if resp['status'] in ['error']:
            return resp
        return resp['data_frame']

    # Empty values
    def empty(self, col, catalog_key, project_key, dataset_key, recipe_key=None):
        data_frame = copy.deepcopy(self.data)
        resp = dataset_helper.ok_not_ok(catalog_key=catalog_key, project_key=project_key, dataset_key=dataset_key,recipe_key=recipe_key,column_name=col,filter_for='empty',data_frame=data_frame)
        if resp['status'] in ['error']:
            return resp
        return resp['data_frame']

def remove_filter(data_frame, para):
    objects = Filter(data_frame)
    for i in range(len(para)):
        operation = para[i].get('operator')
        value = [v for k, v in para[i].items() if k not in ('operator', 'condition')]
        data = getattr(objects, operation)(*value)

    if sum([x.get('condition') is not None for x in para]) > 0:
        x = [x.get('condition') for x in para]
        i = 0
        for x in x:
            if x is None:
                break
            else:
                if x == 'and':
                    if i == 0:
                        data = data_frame[(objects.current_history[i]) & (objects.current_history[i + 1])]
                        i += 2
                    else:
                        data = data[objects.current_history[i]]
                        i += 1
                else:
                    if i == 0:
                        data = data_frame[(objects.current_history[i]) | (objects.current_history[i + 1])]
                        i += 2
                    else:
                        data = data_frame[objects.current_history[i]]
                        i += 1
    return data