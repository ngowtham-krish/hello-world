import time,shutil
import pandas as pd
from sys import exc_info
from json import loads, dumps
from datetime import datetime
from strait.environment import load_env
import strait.core.dataset as dataset
import strait.pipeline.dataset as pipelineDataset
from os import path, getcwd, makedirs, environ
import strait.core.helper.dataset_helper as dataset_helper
from strait.core.model.schema import DatasetSchema, FileSchema, RecipeSchema, HistorySchema

# Calling Enviroment Function
load_env()

class Join:

    def __init__(self, **kwargs):
        if 'catalog_key' in kwargs and kwargs['catalog_key'] is None: # For Notebook or Custom Recipe
            self.catalog_key = environ.get('CATALOG_KEY',None) 
        else: # For API   
            self.catalog_key = kwargs['catalog_key']
        
        if 'project_key' in kwargs and kwargs['project_key'] is None: # For Notebook or Custom Recipe
            self.project_key = environ.get('PROJECT_KEY',None) 
        else: # For API   
            self.project_key = kwargs['project_key']
        
        if 'dataset_key' in kwargs and kwargs['dataset_key'] is None: # For Notebook or Custom Recipe
            self.dataset_key = environ.get('DATASET_KEY',None) 
        else: # For API   
            self.dataset_key = kwargs['dataset_key']
        
        if 'recipe_key' in kwargs and kwargs['recipe_key'] is None: # For Notebook or Custom Recipe
            self.recipe_key = environ.get('RECIPE_KEY',None) 
        else: # For API   
            self.recipe_key = kwargs['recipe_key']
        
        self.dataset_schema = DatasetSchema
        self.file_schema    = FileSchema
        self.recipe_schema  = RecipeSchema
        self.history_schema = HistorySchema
        
    # Join Operation    
    def run(self,**kwargs):
        try:
            print("---------------- Inside Run -------------------------")
            if self.catalog_key is not None and self.project_key is not None and self.dataset_key is not None and self.recipe_key is not None:
                print("catalog_key=   ",self.catalog_key, "    project_key= ",self.project_key, "   source_key= ",self.dataset_key, "    key= ",self.recipe_key)
                recipe_data = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key=self.recipe_key,deleted=False).to_json()
                recipe_data = list(loads(recipe_data))
                print("------------ recipe_data -------------------")
                print(recipe_data)
                if len(recipe_data)==0:
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        return ({'status':'error','message':'key is invalid'})
                    else: # For Notebook
                        return "key is invalid"
                else:
                    recipe_data = recipe_data[0]
                    dataset_key = recipe_data['source_key']
                    target_key  = recipe_data['target_key']
                    print("---------------- source_key -----------------")
                    print(dataset_key)
                    print("---------------- target_key -----------------")
                    print(target_key)
                    # Fetching First Dataset Details
                    source_dataset_data = self.dataset_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, key=dataset_key[0], deleted=False).to_json()
                    source_dataset_data = loads(source_dataset_data)
                    if len(source_dataset_data)==0:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status':'error','message':"dataset key is invalid"})
                        else: # For Notebook
                            return "dataset key is invalid"
                    source_dataset_data = source_dataset_data[0]
                    print("---------------- source_dataset_data -----------------")
                    print(source_dataset_data)
                    
                    # Fetching Second Dataset Details
                    target_dataset_data = self.dataset_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, key=dataset_key[1], deleted=False).to_json()
                    target_dataset_data = loads(target_dataset_data)
                    if len(target_dataset_data)==0:
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return ({'status':'error','message':"dataset key is invalid"})
                        else: # For Notebook
                            return "dataset key is invalid"
                    target_dataset_data = target_dataset_data[0]
                    print("---------------- target_dataset_data -----------------")
                    print(target_dataset_data)
                    # Fetching First Dataset Data Frame
                    dataset_obj = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=dataset_key[0])
                    data_frame  = dataset_obj.get_dataframe(sampling_name='all',request_from='api')
                    if data_frame['status']=='error':
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return data_frame
                        else: # For Notebook
                            return data_frame['message']
                    else:
                        source_data_frame = data_frame['dataFrame']
                    print("---------------- source_data_frame -----------------")
                    print(source_data_frame.head(10))
                    # Fetching Second Dataset Data Frame
                    dataset_obj = dataset.Dataset(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=dataset_key[1])
                    data_frame  = dataset_obj.get_dataframe(sampling_name='all',request_from='api')
                    if data_frame['status']=='error':
                        if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                            return data_frame
                        else: # For Notebook
                            return data_frame['message']
                    else:
                        target_data_frame = data_frame['dataFrame']
                    print("---------------- target_data_frame -----------------")
                    print(target_data_frame.head(10))
                    # Checking user provided column name for first dataset is valid or not
                    if 'left_on' in kwargs and kwargs['left_on'] is not None:
                        for item in kwargs['left_on']:
                            if item not in list(source_data_frame.columns):
                                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                    return ({"status":"error","message": "provided column name is invalid of "+str(source_dataset_data['name']).lower()+" dataset"}) 
                                else: # For Notebook
                                    return "provided column name is invalid of "+str(source_dataset_data['name']).lower()+" dataset"
                    
                    # Checking user provided column name for second dataset is valid or not
                    if 'right_on' in kwargs and kwargs['right_on'] is not None:
                        for item in kwargs['right_on']:
                            if item not in list(target_data_frame.columns):
                                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                    return ({"status":"error","message": "provided column name is invalid of "+str(target_dataset_data['name']).lower()+" dataset"})    
                                else: # For Notebook
                                    return "provided column name is invalid of "+str(target_dataset_data['name']).lower()+" dataset"
                    
                    # Checking user provided column name for first dataset is valid or not
                    if 'left_by' in kwargs and kwargs['left_by'] is not None:
                        for item in kwargs['left_by']:
                            if item not in list(source_data_frame.columns):
                                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                    return ({"status":"error","message": "provided column name is invalid of "+str(source_dataset_data['name']).lower()+" dataset"}) 
                                else: # For Notebook
                                    return "provided column name is invalid of "+str(source_dataset_data['name']).lower()+" dataset"
                    
                    # Checking user provided column name for second dataset is valid or not
                    if 'right_by' in kwargs and kwargs['right_by'] is not None:
                        for item in kwargs['right_by']:
                            if item not in list(target_data_frame.columns):
                                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                    return ({"status":"error","message": "provided column name is invalid of "+str(target_dataset_data['name']).lower()+" dataset"})    
                                else: # For Notebook
                                    return "provided column name is invalid of "+str(target_dataset_data['name']).lower()+" dataset"
                    
                    if 'direction' in kwargs and kwargs['direction'] is not None:
                        if kwargs['direction'] not in ['backward','forward','nearest']:
                            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                return ({"status":"error","message": "direction is invalid"})    
                            else: # For Notebook
                                return "direction is invalid"
                    
                    if 'allow_exact_matches' in kwargs and kwargs['allow_exact_matches'] is not None:
                        if kwargs['allow_exact_matches'] not in [True,False,'true','false']:
                            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                                return ({"status":"error","message": "allow exact match is invalid"})    
                            else: # For Notebook
                                return "allow exact match is invalid"

                    if ((('left_by' in kwargs and kwargs['left_by'] is not None) and ('right_by' in kwargs and kwargs['right_by'] is not None)) or ('direction' in kwargs and kwargs['direction'] is not None) or ('allow_exact_matchs' in kwargs and kwargs['allow_exact_matchs'] is not None)):
                        if 'left_by' in kwargs and kwargs['left_by'] is not None:
                            left_by = kwargs['left_by']
                        else: # Default
                            left_by = None
                        
                        if 'right_by' in kwargs and kwargs['right_by'] is not None:
                            right_by = kwargs['right_by']
                        else: # Default
                            right_by = None
                        
                        if 'allow_exact_matches' in kwargs and kwargs['allow_exact_matches'] is not None:
                            if kwargs['allow_exact_matches'] in [False,'false']:
                                allow_exact_matches = False
                            else:
                                allow_exact_matches = True
                        else: # Default  Value
                            allow_exact_matches = True
                        
                        if 'direction' in kwargs and kwargs['direction'] is not None:
                            direction = kwargs['direction']
                        else: # Default  Value
                            direction = 'backward'
                        
                        final_data_frame = pd.merge_asof(source_data_frame, target_data_frame, left_on=kwargs['left_on'], right_on=kwargs['right_on'], left_by=left_by, right_by=right_by, allow_exact_matches=allow_exact_matches, direction=direction)
                    else:
                        print("---------------- joining_type -----------------")
                        print(kwargs['joining_type'])
                        print("---------------- left_on -----------------")
                        print(kwargs['left_on'])
                        print("---------------- right_on -----------------")
                        print(kwargs['right_on'])
                    
                        final_data_frame = pd.merge(source_data_frame, target_data_frame, how=kwargs['joining_type'], left_on=kwargs['left_on'], right_on=kwargs['right_on'],left_index=False, right_index=False, sort=True)
                    # Replacing any NaN/None Value to Empty String
                    final_data_frame.replace(to_replace=[None,'None','NONE','none','Nan','nan','NAN','NaN'], value="", inplace=True)
                    print("-------- final_data_frame --------------")
                    print(final_data_frame.head(10))

                    # Storing target File
                    timestamp = int(round(time.time() * 1000))
                    file_name = target_key + "_" + str(timestamp) + ".csv"
                    print(" file_name -----------------",file_name)
                    base_path = environ.get('STORAGE',None)
                    # Making dataset folder to store respective dataset inside that
                    dataset_dir = path.join(base_path,self.catalog_key,self.project_key,'datasets',target_key)

                    print("---------------- dataset_dir ----------------------",dataset_dir)

                    if not path.exists(dataset_dir):
                        makedirs(dataset_dir)
                    
                    # Making history folder to store respective dataset recipe file inside that
                    history_dir = path.join(base_path,self.catalog_key,self.project_key,'datasets',target_key,'history')
                    if not path.exists(history_dir):
                        makedirs(history_dir)
                    
                    version = environ.get('APIVERSION',None)
                    # Preparing preview path
                    preview_path = '/api/'+version+'/dataset/'+target_key+'/preview?token='+kwargs['token']

                    # Converting the data frame to CSV
                    file_path = path.join(dataset_dir, file_name)
                    print("-------------- file_path -------",file_path)
                    print("-------- final_data_frame --------------")
                    print(final_data_frame.head(10))
                    data_frame_to_csv = final_data_frame.to_csv(index=False)
                    
                    # Generating the target file
                    fh = open(file_path, "w")
                    fh.write(data_frame_to_csv)
                    fh.close()
                    print("---------------CSV File write successfully --------------------------")

                    # Copying first dataset source file and moving it to target location
                    source_file_path = path.join(base_path,self.catalog_key,self.project_key,'datasets',dataset_key[0],source_dataset_data['datasource']['source'][0]['filename'])
                    shutil.copy2(source_file_path, dataset_dir)  
                    print("Copy first dataset file ---------------------")
                    # Copying second dataset source file and moving it to target location
                    source_file_path = path.join(base_path,self.catalog_key,self.project_key,'datasets',dataset_key[1],target_dataset_data['datasource']['source'][0]['filename'])
                    shutil.copy2(source_file_path, dataset_dir)  
                    print("Copy second dataset file ---------------------")
                    
                    datasource = {
                        "type" : "file",
                        "source" : [{
                            "from" : "recipe",
                            "filename" : source_dataset_data['datasource']['source'][0]['filename'],
                            "format" : source_dataset_data['datasource']['source'][0]['format']
                        },{
                            "from" : "recipe",
                            "filename" : target_dataset_data['datasource']['source'][0]['filename'],
                            "format" : target_dataset_data['datasource']['source'][0]['format']
                        }],
                        "target" : {
                            "to" : path.join(dataset_dir, file_name),
                            "filename" : file_name
                        }
                    }
                    print("--------------------- datasource --------------------")
                    print(datasource)
                    
                    # Updating data into dataset
                    datasetObj  = self.dataset_schema.objects(key=target_key,catalog_key=self.catalog_key,project_key=self.project_key,deleted=False).modify(
                        new=True,
                        set__datasource = datasource,
                        set__path = preview_path,
                        set__is_build = True,
                        set__updated_at = datetime.now()
                    )
                    print("----------- After Dataset updated successfully")

                    # Updating recipe is_build to True
                    recipeObj  = self.recipe_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, key=self.recipe_key, deleted=False).modify(
                        new=True,
                        set__is_build = True,
                        set__updated_at = datetime.now()
                    )
                    print("----------- After Recipe updated successfully")


                    # Updating Recipe History Schema
                    operation = {
                        'joining_type': kwargs['joining_type'],
                        'left_on': kwargs['left_on'],
                        'right_on': kwargs['right_on']
                    }
                    print(" --------------------- operation -----------------")
                    print(operation)
                    history_data = self.history_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, recipe_key=self.recipe_key, deleted=False).to_json()
                    history_data = loads(history_data)
                    if len(history_data)==0:
                        sampling = {
                            'name': 'all',
                            'records': '',
                            'ratio': '',
                            'column_name':''
                        }
                        history_obj = self.history_schema(catalog_key=self.catalog_key, project_key=self.project_key, source_key=dataset_key, recipe_key=self.recipe_key, operation=operation, active=True, sampling=sampling, target_name=file_name)
                        history_obj.save()
                    else:
                        # Updating history schema
                        fileObj = self.history_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, source_key=self.dataset_key, recipe_key=self.recipe_key, deleted=False).modify(
                            new=True,
                            set__operation = operation,
                            set__updated_at = datetime.now()
                        )

                    # Data for Metadata
                    meta = {}
                    meta['source_name']     = [source_dataset_data['datasource']['source'][0]['filename'],target_dataset_data['datasource']['source'][0]['filename']]
                    meta['source_format']   = [source_dataset_data['datasource']['source'][0]['format'],target_dataset_data['datasource']['source'][0]['format']]
                    meta['target_name']     = file_name
                    meta['path']            = preview_path
                    meta['columns']         = final_data_frame.columns.tolist()
                    meta['row_count']       = final_data_frame.shape[0]
                    print(meta)
                    # Fetching dataset_key and target_key from recipe by recipe key
                    file_data = self.file_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=target_key,deleted=False).to_json()
                    file_data = loads(file_data)
                    print("-------------- length of file_data --------------")
                    print(len(file_data))
                    
                    if len(file_data)==0:
                        # Default Sampling
                        default_records = environ.get('DEFAULT_RECORD_COUNT',None)
                        operation = {
                            'sampling': {
                                "name":"first",
                                "column_name":"",
                                "records": int(default_records),
                                "ratio":""
                            },
                            'freeze_column_index': [],
                            'filters': [],
                            'sorting': [],
                            'column_index': [],
                            'hide_column': []
                        }
                        print(" ----------------- operation -------------------")
                        print(operation)
                        fileObj = self.file_schema(dataset_key=target_key,metadata=meta,catalog_key=self.catalog_key,project_key=self.project_key,operation=operation)
                        fileObj.save()
                    else:
                        # Updating data into dataset
                        fileObj = self.file_schema.objects(catalog_key=self.catalog_key, project_key=self.project_key, dataset_key=target_key, deleted=False).modify(
                            new=True,
                            set__metadata = meta,
                            set__updated_at = datetime.now()
                        )

                    arguments = {
                        "catalog_key": self.catalog_key,
                        "project_key": self.project_key,
                        "dataset_key": target_key
                        #"recipe_key": self.recipe_key # Recipe key is of source dataset we are passing which it should not be
                    }
                    print(arguments)
                    result = dataset_helper.store_whole_meta(arguments)
                    print(" ----------------- after store_whole_meta -------------------")
                    
                    print("------------ before update pipeline delete --------------------")
                    # Pipeline Update Target Dataset
                    pipelineObj = pipelineDataset.Dataset(self.catalog_key,self.project_key,target_key)
                    pipeline_resp = pipelineObj.update()
                    print("------------ after update pipeline delete --------------------")
                    if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                        print("------------ datasetObj --------------")
                        print(datasetObj)
                        return dataset_helper.dataset_response(dataset=datasetObj)
                    else: # For Notebook
                        return final_data_frame
            else:
                if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                    return ({'status':'error','message':'Missing required paramters'})
                else: # NoteBook
                    return "Missing required paramters"
        except NameError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            #fname = path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            #print(exc_type, fname, exc_tb.tb_lineno)
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "NameError: " + str(e) + " at line "+ str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("NameError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except KeyError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "KeyError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("KeyError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except ValueError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "ValueError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("ValueError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except IndexError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "IndexError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("IndexError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except TypeError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "TypeError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("TypeError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except OverflowError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "OverflowError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("OverflowError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except IndentationError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "IndentationError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("IndentationError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except ZeroDivisionError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "ZeroDivisionError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("ZeroDivisionError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except ImportError as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "ImportError: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("ImportError: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
        except Exception as e:
            exc_type, exc_obj, exc_tb = exc_info()
            if 'request_from' in kwargs and kwargs['request_from']=='api': # For API
                return ({'status': 'error', 'message': "Exception: " + str(e)+ " at line "+str(exc_tb.tb_lineno)})
            else: # NoteBook
                return  ("Exception: " + str(e)+ " at line "+str(exc_tb.tb_lineno))
    