from os import environ, path, getcwd
from json import loads

constants = {
    "PORT_NO": "8000",
    "DEV_HOST_NAME": "http://localhost:8000",
    "PROD_HOST_NAME": "http://192.168.125.45:9075",  # To be decided
    # Strait Core
    "STRAIT_LOCAL_MONGODB": "mongodb://strait-master-db:27017/strait-ai", #"mongodb://localhost:27017/strait-ai",
    "STRAIT_PROD_MONGODB": "mongodb://strait-master-db:27017/strait-ai",
    "STRAIT_DS_STORAGE": "local/hdfs",
    "STORAGE_TYPE": "docker",
    "STRAIT_PROD_STORAGE_PATH": "/data/storage/",
    "STRAIT_LOCAL_STORAGE_PATH": path.join(getcwd(), "storage"),
    "ENVIRONMENT": "PROD",
    "ALLOWED_EXTENSIONS": "csv,xlsx,xls",
    "DEFAULT_RECORD_COUNT": "2000",
    "DEFAULT_SAMPING_RATIO": "2",
    "DEFAULT_PAGE_SIZE": "500",
    # Strait Auth
    "PASSWORD_SECRET_KEY": "secrect_key",
    "EXPIRY_TIME_MIN": "30",
    "SMTP_SERVER": "smtp.gmail.com",
    "SMTP_PORT_NO": "465",
    "SENDER_NAME": "Strait.ai",
    "SENDER_EMAIL": "testperformance007@gmail.com",  # Sender Email
    "SENDER_PASSWORD": "Admintest@12345",  # Sender Password
    "RANDOM_LENGTH": "40",
    "SYSTEM_ADMIN": "system",
    "VERSION": environ.get("APIVERSION", "v2"),
    "DEV_BROKER_URL": "amqp://guest:guest@localhost:5672/",
    "PROD_BROKER_URL": "amqp://rabbitmq:rabbitmq@strait-rabbitmq:5672/",
    "MODELDB_PATH": "/data/storage/models/",
    # NiFi
    "REDIS_LOCAL_URL": "redis://strait-redis:6379",
    "REDIS_PROD_URL": "redis://strait-redis:6379", # To be decided
    "SESSION_SECRET_KEY": "nPN_mpj1Imt~N4rxc_y7^*5zOse@lnin6~cf7NVd",
    "CONTROL_SERVICE_NAME": "mysql,postgres,sqlite,avro_reader,json_record_set_writer,parquet_record_set_writer,csv_record_set_writer",
    "PROCESSOR_GROUP_NAME": "fetch_table_details_from_mysql,fetch_table_lists_from_mysql,fetch_table_details_from_postgres,fetch_table_lists_from_postgres,fetch_table_details_from_sqlite,fetch_table_lists_from_sqlite,fetch_table_schema_from_mysql,fetch_table_schema_from_postgres,fetch_table_schema_from_sqlite,fetch_database_name_from_mysql,fetch_database_name_from_postgres,fetch_table_row_count_from_mysql,fetch_table_row_count_from_postgres",
    "PROCESSOR_NAME": "execute_sql,convert_avro_to_json,convert_avro_to_parquet,update_attribute,put_file,get_file,query_database_table,merge_records",
    "NIFI_LOCAL_URL": "http://strait-nifi:6500/nifi-api",
    "NIFI_PROD_URL": "http://strait-nifi:6500/nifi-api", # To be decided
    "NIFI_MAX_ROWS_PER_FLOW_FILE":"1000", # The maximum number of result rows that will be included in a single FlowFile. This will allow you to break up very large result sets into multiple FlowFiles. If the value specified is zero, then all rows are returned in a single FlowFile.
    "NIFI_OUTPUT_BATCH_SIZE":"1000", # The number of output FlowFiles to queue before committing the process session. When set to zero, the session will be committed when all result set rows have been processed and the output FlowFiles are ready for transfer to the downstream relationship. For large result sets, this can cause a large burst of FlowFiles to be transferred at the end of processor execution. If this property is set, then when the specified number of FlowFiles are ready for transfer, then the session will be committed, thus releasing the FlowFiles to the downstream relationship.
    "NIFI_FETCH_SIZE":"500", #The number of result rows to be fetched from the result set at a time. This is a hint to the database driver and may not be honored and/or exact. If the value specified is zero, then the hint is ignored.
    "NIFI_AVRO_TO": "parquet",
    "NIFI_MERGE_RECORDS": "csv"
}

# Loading Enviroment Variables


def load_env():
    for key, value in constants.items():
        environ[key] = value
    if constants["ENVIRONMENT"] == "DEV":
        environ["STORAGE"] = constants["STRAIT_LOCAL_STORAGE_PATH"]
        environ["HOST_NAME"] = constants["DEV_HOST_NAME"]
        environ["BROKER_URL"] = constants["DEV_BROKER_URL"]
        environ["REDIS_URL"] = constants["REDIS_LOCAL_URL"]
        environ["NIFI_URL"]  = constants["NIFI_LOCAL_URL"]
    else:
        environ["STORAGE"] = constants["STRAIT_PROD_STORAGE_PATH"]
        environ["HOST_NAME"] = constants["PROD_HOST_NAME"]
        environ["BROKER_URL"] = constants["PROD_BROKER_URL"]
        environ["REDIS_URL"] = constants["REDIS_PROD_URL"]
        environ["NIFI_URL"]  = constants["NIFI_PROD_URL"]
